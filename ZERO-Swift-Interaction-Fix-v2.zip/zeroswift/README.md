# ZERO (native SwiftUI) for Xcode 15.2

A native rebuild of ZERO that keeps the glass look of your project and carries over the HTML app's features.

## Open and run
1. Unzip and open `ZERO.xcodeproj` in Xcode 15.2.
2. Select the ZERO target > Signing & Capabilities: choose your Team and change the Bundle Identifier from `com.yourname.zero`.
3. Pick an iPhone (iOS 16.1 or newer) and press Run. Product > Archive makes the IPA.

This project replaces your old one. It uses one store (`ZEROStore`) and one set of views, so the duplicate files in your old project (`DesignSystem`, `Models_1`, `ZEROProjectStore`, the second `MusicView`/`SettingsView`) are gone. Your `OnboardingView.swift` is included unchanged.

## What is in it
- Studio: preview canvas with move, pinch and twist gestures, dynamic layers (main, overlays above or below), snapping, trimming, split, duplicate, delete, undo and redo, text, fit/fill, fades, speed and volume.
- Keyframes on position, scale, rotation and opacity (diamond buttons and the Key tool), shown as diamonds on the clip.
- Graph editor: edits only the segment the playhead is in, 28 curve presets, draggable Bezier handles, special graphs with a yellow handle (steps, bouncy, spring, wiggle, repeat, ping-pong), copy and paste curves, saved presets.
- 140 effects, each with its own controls: amount (with its own label), colour where it makes sense, speed only for time-based effects, and start/end times. Effect layers affect everything below them, and you can exclude clips.
- 24 transitions between touching clips.
- Export: frames are rendered one by one with AVAssetWriter (not real time), audio from all clips is mixed in, then shared with the share sheet.
- Music: import audio or video, rename, cover images, playlists, public playlists on your profile, "listening now", pause while the edit plays and resume afterwards.
- Profile: banner image or colours, picture, name, username, bio, status. Chat: interface only.
- Settings: 24 themes, accent and secondary colour, background styles, roundness, glass, font, tap/drag visualiser, preview quality.
- 3D tab: SceneKit shapes you can orbit.

## Not included yet
Compound clips, nulls, camera and parenting, depth (Z), 3D layers on the timeline, animated GIF pictures, the WebGL renderer, real chat and Google sign-in.

## Notes
- I could not compile Swift where this was written. If Xcode reports a few errors on first build, they are small and local; send them to me.
- Effects are drawn with SwiftUI, so very heavy stacks of effects can be slow in the preview; lower Preview quality in Settings. Export uses the same renderer at full size and can take a while.
