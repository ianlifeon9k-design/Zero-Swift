import SwiftUI
import SceneKit
import UIKit

/// Renders 3D layers (shapes, imported models and 3D image/video slabs) to transparent images with SceneKit.
final class Scene3DCache {
    static let shared = Scene3DCache()

    private final class Entry {
        let renderer: SCNRenderer
        let holder: SCNNode
        let texture: SCNMaterial?
        let sig: String
        init(renderer: SCNRenderer, holder: SCNNode, texture: SCNMaterial?, sig: String) {
            self.renderer = renderer; self.holder = holder; self.texture = texture; self.sig = sig
        }
    }

    private var entries: [UUID: Entry] = [:]
    private let device = MTLCreateSystemDefaultDevice()

    func image(_ c: ZClip, _ pr: Props, _ lt: Double, _ size: CGSize, _ media: MediaCache, _ tex: UIImage?) -> UIImage? {
        let sig = [c.kind.rawValue, c.shape, c.shapeHex, c.material, c.wire ? "w" : "s", String(c.thickness), c.file ?? "", String(Int(size.width)), String(Int(size.height)), tex == nil ? "n" : "t"].joined(separator: "|")
        var entry = entries[c.id]
        if entry == nil || entry?.sig != sig {
            entry = build(c, media, tex, sig)
            entries[c.id] = entry
        }
        guard let e = entry else { return nil }
        if let t = tex, let m = e.texture { m.diffuse.contents = t }
        let rad = Double.pi / 180
        e.holder.eulerAngles = SCNVector3(Float(pr.rx * rad), Float((pr.ry + c.spin * lt) * rad), Float(pr.rz * rad))
        return e.renderer.snapshot(atTime: 0, with: size, antialiasingMode: .multisampling4X)
    }

    private func geometry(_ shape: String) -> SCNGeometry {
        switch shape {
        case "sphere": return SCNSphere(radius: 1)
        case "cone": return SCNCone(topRadius: 0, bottomRadius: 1, height: 2)
        case "torus": return SCNTorus(ringRadius: 1, pipeRadius: 0.35)
        case "pyramid": return SCNPyramid(width: 2, height: 2, length: 2)
        case "capsule": return SCNCapsule(capRadius: 0.6, height: 2.4)
        case "cylinder": return SCNCylinder(radius: 0.9, height: 2)
        case "tube": return SCNTube(innerRadius: 0.6, outerRadius: 1, height: 2)
        default: return SCNBox(width: 1.6, height: 1.6, length: 1.6, chamferRadius: 0.1)
        }
    }

    private func build(_ c: ZClip, _ media: MediaCache, _ tex: UIImage?, _ sig: String) -> Entry? {
        let scene = SCNScene()
        scene.background.contents = UIColor.clear
        let holder = SCNNode()
        var texMat: SCNMaterial? = nil
        let col = UIColor(Color(hex: c.shapeHex))
        if let t = tex {
            let aspect = t.size.height > 0 ? Double(t.size.width / t.size.height) : 1
            let w3 = aspect >= 1 ? 3.0 : 3.0 * aspect
            let h3 = aspect >= 1 ? 3.0 / aspect : 3.0
            let front = SCNMaterial()
            front.diffuse.contents = t
            front.lightingModel = .constant
            front.isDoubleSided = true
            texMat = front
            let geo: SCNGeometry
            if c.thickness > 0.01 {
                let box = SCNBox(width: CGFloat(w3), height: CGFloat(h3), length: CGFloat(c.thickness), chamferRadius: 0)
                let side = SCNMaterial()
                side.diffuse.contents = col
                side.lightingModel = .blinn
                box.materials = [front, side, front, side, side, side]
                geo = box
            } else {
                let plane = SCNPlane(width: CGFloat(w3), height: CGFloat(h3))
                plane.materials = [front]
                geo = plane
            }
            holder.addChildNode(SCNNode(geometry: geo))
        } else if c.shape == "model", let f = c.file, let sc = try? SCNScene(url: media.url(f), options: nil) {
            let m = SCNNode()
            for ch in sc.rootNode.childNodes { m.addChildNode(ch.clone()) }
            let b = m.boundingBox
            let ext = max(b.max.x - b.min.x, b.max.y - b.min.y, b.max.z - b.min.z)
            let k: Float = ext > 0 ? 2.4 / ext : 1
            m.pivot = SCNMatrix4MakeTranslation((b.min.x + b.max.x) / 2, (b.min.y + b.max.y) / 2, (b.min.z + b.max.z) / 2)
            m.scale = SCNVector3(k, k, k)
            holder.addChildNode(m)
        } else {
            let geo = geometry(c.shape)
            let m = SCNMaterial()
            m.lightingModel = .physicallyBased
            m.diffuse.contents = col
            switch c.material {
            case "matte": m.metalness.contents = 0.0; m.roughness.contents = 0.9
            case "metal": m.metalness.contents = 0.8; m.roughness.contents = 0.3
            default: m.metalness.contents = 0.15; m.roughness.contents = 0.2
            }
            if c.wire { m.fillMode = .lines }
            geo.materials = [m]
            holder.addChildNode(SCNNode(geometry: geo))
        }
        scene.rootNode.addChildNode(holder)
        let camNode = SCNNode()
        let cam = SCNCamera()
        cam.fieldOfView = 45
        cam.zNear = 0.1
        camNode.camera = cam
        camNode.position = SCNVector3(0, 0, 7)
        scene.rootNode.addChildNode(camNode)
        let amb = SCNNode(); amb.light = SCNLight(); amb.light?.type = .ambient; amb.light?.intensity = 650
        scene.rootNode.addChildNode(amb)
        let omni = SCNNode(); omni.light = SCNLight(); omni.light?.type = .omni; omni.light?.intensity = 1000; omni.position = SCNVector3(3, 5, 6)
        scene.rootNode.addChildNode(omni)
        let r = SCNRenderer(device: device, options: nil)
        r.scene = scene
        r.pointOfView = camNode
        return Entry(renderer: r, holder: holder, texture: texMat, sig: sig)
    }
}
