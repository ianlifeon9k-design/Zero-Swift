import SwiftUI

enum ZEROSection: String, CaseIterable, Identifiable {
    case base, studio, music, chat, profile, settings, dimension
    var id: String { rawValue }
    var title: String {
        switch self {
        case .base: return "Base"
        case .studio: return "Studio"
        case .music: return "Music"
        case .chat: return "Chat"
        case .profile: return "Profile"
        case .settings: return "Settings"
        case .dimension: return "3D"
        }
    }
    var symbol: String {
        switch self {
        case .base: return "square.grid.2x2.fill"
        case .studio: return "slider.horizontal.3"
        case .music: return "waveform"
        case .chat: return "bubble.left.and.bubble.right.fill"
        case .profile: return "person.crop.circle.fill"
        case .settings: return "gearshape.fill"
        case .dimension: return "cube.transparent"
        }
    }
}

enum ClipKind: String, Codable { case video, image, audio, text, effect, null, camera, compound, object3d }

struct ZCurve: Codable, Hashable {
    var kind = "linear"
    var a = 0.25
    var b = 0.1
    var c = 0.25
    var d = 1.0
    func value(_ f: Double) -> Double { Curves.eval(self, f) }
}

struct NamedCurve: Codable, Hashable, Identifiable { var id = UUID(); var name: String; var curve: ZCurve }
struct ZKey: Codable, Hashable, Identifiable { var id = UUID(); var t: Double; var v: Double; var curve = ZCurve() }
struct ZEffectInstance: Codable, Hashable, Identifiable {
    var id = UUID()
    var fx: String
    var amount: Double
    var speed = 1.0
    var colorHex: String? = nil
    var start = 0.0
    var end = 0.0
    var enabled = true
}
struct ZTransition: Codable, Hashable { var type = ""; var duration = 0.6 }
struct Props { var x = 0.0, y = 0.0, s = 100.0, r = 0.0, o = 100.0, z = 0.0, rx = 0.0, ry = 0.0, rz = 0.0 }

struct ZClip: Codable, Hashable, Identifiable {
    var id = UUID()
    var name: String
    var kind: ClipKind
    var lane = 0
    var start = 0.0
    var duration = 3.0
    var srcIn = 0.0
    var srcDur = 0.0
    var speed = 1.0
    var file: String? = nil
    var text = "Your text"
    var fontSize = 28.0
    var colorHex = "#FFFFFF"
    var volume = 1.0
    var muted = false
    var fadeIn = 0.0
    var fadeOut = 0.0
    var fit = "fit"
    var x = 0.0
    var y = 0.0
    var scale = 100.0
    var rotation = 0.0
    var opacity = 100.0
    var keys: [String: [ZKey]] = [:]
    var effects: [ZEffectInstance] = []
    var transition = ZTransition()
    var excluded: [UUID] = []
    var z = 0.0
    var rx = 0.0
    var ry = 0.0
    var rz = 0.0
    var parent: UUID? = nil
    var ignoreCam = false
    var sub: [ZClip] = []
    var shape = "cube"
    var shapeHex = "#A78BFA"
    var material = "glossy"
    var wire = false
    var spin = 0.0
    var thickness = 0.0
    var d3 = false
    var end: Double { start + duration }
    var isRig: Bool { kind == .null || kind == .camera }
    var rowKey: Int { kind == .audio ? -1000 : (isRig ? 2000 : lane) }
    static func laneName(_ l: Int) -> String {
        if l == -1000 { return "AUDIO" }
        if l == 2000 { return "RIG" }
        if l == 0 { return "MAIN" }
        return l > 0 ? "OVERLAY \(l)" : "UNDER \(-l)"
    }
}

extension ZClip {
    func base(_ p: String) -> Double {
        switch p {
        case "x": return x
        case "y": return y
        case "s": return scale
        case "r": return rotation
        case "z": return z
        case "rx": return rx
        case "ry": return ry
        case "rz": return rz
        default: return opacity
        }
    }
    mutating func setBase(_ p: String, _ v: Double) {
        switch p {
        case "x": x = v
        case "y": y = v
        case "s": scale = v
        case "r": rotation = v
        case "z": z = v
        case "rx": rx = v
        case "ry": ry = v
        case "rz": rz = v
        default: opacity = v
        }
    }
    func value(_ p: String, at lt: Double) -> Double {
        guard let a = keys[p], !a.isEmpty else { return base(p) }
        if lt <= a[0].t { return a[0].v }
        if lt >= a[a.count - 1].t { return a[a.count - 1].v }
        var i = 1
        while a[i].t < lt { i += 1 }
        let u = a[i - 1], v = a[i]
        return u.v + (v.v - u.v) * u.curve.value((lt - u.t) / (v.t - u.t))
    }
    func props(at lt: Double) -> Props {
        Props(x: value("x", at: lt), y: value("y", at: lt), s: value("s", at: lt), r: value("r", at: lt), o: value("o", at: lt), z: value("z", at: lt), rx: value("rx", at: lt), ry: value("ry", at: lt), rz: value("rz", at: lt))
    }
    func hasKey(_ p: String, at lt: Double) -> Bool { (keys[p] ?? []).contains { abs($0.t - lt) < 0.05 } }
    mutating func upsertKey(_ p: String, _ lt: Double, _ v: Double) {
        var a = keys[p] ?? []
        if let i = a.firstIndex(where: { abs($0.t - lt) < 0.05 }) { a[i].v = v } else { a.append(ZKey(t: lt, v: v)) }
        a.sort { $0.t < $1.t }
        keys[p] = a
    }
    mutating func removeKey(_ p: String, _ lt: Double) {
        guard var a = keys[p] else { return }
        a.removeAll { abs($0.t - lt) < 0.05 }
        keys[p] = a.isEmpty ? nil : a
    }
    func segment(_ p: String, at lt: Double) -> Int? {
        guard let a = keys[p], a.count > 1 else { return nil }
        for i in 0..<(a.count - 1) where lt >= a[i].t && lt < a[i + 1].t { return i }
        return nil
    }
}

struct ZProject: Codable, Hashable, Identifiable {
    var id = UUID()
    var name: String
    var width: Int
    var height: Int
    var fps: Int
    var clips: [ZClip] = []
    var modified = Date()
    var ratio: String { width == height ? "1:1" : (width > height ? "16:9" : (abs(Double(width) / Double(height) - 0.8) < 0.02 ? "4:5" : "9:16")) }
}

struct ZSong: Codable, Hashable, Identifiable { var id = UUID(); var name: String; var file: String; var cover: String? = nil }
struct ZPlaylist: Codable, Hashable, Identifiable { var id = UUID(); var name: String; var songs: [UUID] = []; var isPublic = false }

struct AppSettings: Codable {
    var onboardingDone = false
    var language = "English"
    var accentHex = "#A78BFA"
    var accent2Hex = "#5EF2FF"
    var bgHex = "#09090C"
    var bgStyle = "glow"
    var radius = 22.0
    var glass = 0.07
    var fontDesign = "rounded"
    var tapShow = false
    var tapSize = 44.0
    var tapStyle = "ring"
    var tapHex = "#A78BFA"
    var previewQuality = "auto"
    var pauseMusicOnPlay = true
    var shareListening = false
    var creatorName = "Your Creator Name"
    var username = "yourhandle"
    var bio = ""
    var status = ""
    var avatarFile: String? = nil
    var bannerFile: String? = nil
    var bannerPreset = 0
    var savedCurves: [NamedCurve] = []
}

enum ZFlat {
    /// All leaf clips of a timeline (compound clips expanded), with absolute start times.
    static func leaves(_ clips: [ZClip], _ offset: Double = 0) -> [ZClip] {
        var out: [ZClip] = []
        for c in clips {
            if c.kind == .compound { out += leaves(c.sub, offset + c.start) } else { var d = c; d.start += offset; out.append(d) }
        }
        return out
    }
}
