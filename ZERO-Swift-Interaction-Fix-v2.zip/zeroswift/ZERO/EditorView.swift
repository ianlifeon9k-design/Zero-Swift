import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

enum EditorPanel: String, CaseIterable, Identifiable {
    case edit = "Edit", media = "Media", fx = "Effects", transitions = "Transitions", graph = "Graph", threeD = "3D", export = "Export"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .edit: return "slider.horizontal.3"
        case .media: return "photo.on.rectangle"
        case .fx: return "sparkles"
        case .transitions: return "arrow.left.arrow.right"
        case .graph: return "chart.xyaxis.line"
        case .threeD: return "cube.transparent"
        case .export: return "square.and.arrow.up"
        }
    }
}

struct EditorView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var panel: EditorPanel = .edit
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showFiles = false
    @State private var showPlace = false
    @State private var renaming = false
    @State private var draft = ""
    private let timer = Timer.publish(every: 1.0 / 24.0, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: 8) {
            topBar
            breadcrumb
            PreviewArea()
            transport
            ZTimeline()
            toolbar
            if store.isPlaying {
                Text("Playing… panels are hidden so playback stays smooth").font(.caption).foregroundColor(.zeroMuted).frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView(showsIndicators: false) { panelView.padding(.bottom, 8) }
            }
        }
        .padding(.horizontal, 12).padding(.top, 6)
        .onReceive(timer) { _ in store.advance() }
        .onChange(of: photoItems) { items in
            guard !items.isEmpty else { return }
            Task {
                await store.importPhotoItems(items)
                await MainActor.run { photoItems = [] }
            }
        }
        .onChange(of: store.pendingPlace) { list in showPlace = !list.isEmpty }
        .fileImporter(isPresented: $showFiles, allowedContentTypes: [.movie, .image, .audio, .mp3, .mpeg4Audio, .usdz, .threeDContent], allowsMultipleSelection: true) { r in
            if case .success(let urls) = r { store.importURLs(urls) }
        }
        .confirmationDialog("Add as…", isPresented: $showPlace, titleVisibility: .visible) {
            Button("Main timeline") { store.place("main") }
            Button("Overlay above main") { store.place("over") }
            Button("Overlay below main") { store.place("under") }
            Button("Cancel", role: .cancel) { store.pendingPlace = [] }
        }
        .alert("Rename project", isPresented: $renaming) {
            TextField("Name", text: $draft)
            Button("Save") { if let id = store.currentID { store.renameProject(id, draft) } }
            Button("Cancel", role: .cancel) {}
        }
    }

    private var topBar: some View {
        HStack(spacing: 8) {
            Button { store.closeEditor() } label: { Image(systemName: "xmark").font(.headline).frame(width: 40, height: 40).background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 13)) }
            Button { draft = store.project?.name ?? ""; renaming = true } label: {
                VStack(alignment: .leading, spacing: 1) {
                    Text("ZERO STUDIO").font(.system(size: 8, weight: .bold)).tracking(2).foregroundColor(store.accent)
                    Text(store.project?.name ?? "").font(.subheadline.bold()).lineLimit(1)
                }
            }
            Spacer()
            Button { store.undo() } label: { Image(systemName: "arrow.uturn.backward").frame(width: 38, height: 38) }.disabled(!store.canUndo)
            Button { store.redo() } label: { Image(systemName: "arrow.uturn.forward").frame(width: 38, height: 38) }.disabled(!store.canRedo)
            Button { panel = .export } label: { Image(systemName: "square.and.arrow.up").font(.headline).foregroundColor(.black).frame(width: 40, height: 40).background(store.accent, in: RoundedRectangle(cornerRadius: 13)) }
        }.foregroundColor(.white)
    }

    @ViewBuilder private var breadcrumb: some View {
        if !store.path.isEmpty {
            Button { store.closeCompound() } label: {
                Label("Inside a compound clip · tap to go back", systemImage: "chevron.left").font(.caption.bold()).frame(maxWidth: .infinity)
                    .padding(.vertical, 8).background(store.accent.opacity(0.25), in: Capsule())
            }.buttonStyle(.plain).foregroundColor(.white)
        }
    }

    private var transport: some View {
        HStack(spacing: 10) {
            Button { store.playhead = max(0, store.playhead - 1.0 / 30) } label: { Image(systemName: "backward.frame.fill").frame(width: 36, height: 36) }
            Button { store.togglePlay() } label: {
                Image(systemName: store.isPlaying ? "pause.fill" : "play.fill").font(.title3).foregroundColor(.black).frame(width: 46, height: 46).background(store.accent, in: Circle())
            }
            Button { store.playhead = min(store.duration, store.playhead + 1.0 / 30) } label: { Image(systemName: "forward.frame.fill").frame(width: 36, height: 36) }
            Text(String(format: "%.2f / %.2f s", store.playhead, store.duration)).font(.caption.monospacedDigit()).foregroundColor(.zeroMuted)
            Spacer()
            Button { store.zoom = max(0.3, store.zoom / 1.4) } label: { Image(systemName: "minus.magnifyingglass").frame(width: 34, height: 34) }
            Button { store.zoom = min(6, store.zoom * 1.4) } label: { Image(systemName: "plus.magnifyingglass").frame(width: 34, height: 34) }
        }.foregroundColor(.white)
    }

    private func toolLabel(_ icon: String, _ title: String) -> some View {
        VStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundColor(store.accent)
            Text(title).font(.system(size: 10, weight: .semibold)).foregroundColor(.white)
        }.frame(width: 62, height: 52).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
    }
    private func tool(_ icon: String, _ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) { toolLabel(icon, title) }.buttonStyle(.plain)
    }

    private var toolbar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                PhotosPicker(selection: $photoItems, maxSelectionCount: 20, matching: .any(of: [.images, .videos])) { toolLabel("photo.on.rectangle", "Photos") }.buttonStyle(.plain)
                tool("folder", "Files") { showFiles = true }
                tool("textformat", "Text") { store.addText(); panel = .edit }
                tool("scissors", "Split") { store.splitSelected() }
                tool("plus.square.on.square", "Duplicate") { store.duplicateSelected() }
                tool("trash", "Delete") { store.deleteSelected() }
                tool("diamond.fill", "Key") { store.toggleAllKeys() }
                tool("chart.xyaxis.line", "Graph") { panel = .graph }
                tool("sparkles", "Effects") { panel = .fx }
                tool("arrow.left.arrow.right", "Transition") { panel = .transitions }
                tool("plus.viewfinder", "Null") { store.addNull(); panel = .edit }
                tool("video", "Camera") { store.addCamera(); panel = .edit }
                tool("square.on.square.dashed", "Group") { store.groupTap() }
                tool("arrow.up.left.and.arrow.down.right", "Open") { store.openCompound() }
                tool("cube.transparent", "3D") { panel = .threeD }
                tool("slider.horizontal.3", "Edit") { panel = .edit }
            }
        }
    }

    @ViewBuilder private var panelView: some View {
        switch panel {
        case .edit: EditPanel()
        case .media: MediaPanel(showFiles: $showFiles, photoItems: $photoItems)
        case .fx: EffectsPanel()
        case .transitions: TransitionsPanel()
        case .graph: GraphPanel()
        case .threeD: ThreeDPanel()
        case .export: ExportPanel()
        }
    }
}

struct PreviewArea: View {
    @EnvironmentObject var store: ZEROStore
    @State private var dragStart: (Double, Double)?
    @State private var pinchStart: Double?
    @State private var twistStart: Double?

    private func previewProject(_ p: ZProject) -> ZProject {
        let caps: [String: Double] = ["480": 480, "720": 720, "960": 960, "full": 1_000_000]
        var cap = caps[store.settings.previewQuality] ?? 720
        if store.isPlaying && store.settings.previewQuality == "auto" { cap = 540 }
        let f = min(1, cap / Double(min(p.width, p.height)))
        var q = p
        q.width = max(2, Int(Double(p.width) * f))
        q.height = max(2, Int(Double(p.height) * f))
        return q
    }

    var body: some View {
        GeometryReader { geo in
            if let p = store.project {
                let q = previewProject(p)
                let fit = min(geo.size.width / CGFloat(q.width), geo.size.height / CGFloat(q.height))
                ZStack {
                    CompositeView(project: q, t: store.playhead, media: store.media, fast: true)
                        .scaleEffect(fit)
                        .frame(width: CGFloat(q.width) * fit, height: CGFloat(q.height) * fit)
                    outline(q, fit)
                }
                .frame(width: CGFloat(q.width) * fit, height: CGFloat(q.height) * fit)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(store.accent.opacity(0.35), lineWidth: 1))
                .contentShape(Rectangle())
                .gesture(move(q, fit))
                .simultaneousGesture(pinch)
                .simultaneousGesture(twist)
                .position(x: geo.size.width / 2, y: geo.size.height / 2)
            }
        }.frame(maxHeight: .infinity)
    }

    private func contentSize(_ c: ZClip, _ w: Double, _ h: Double) -> CGSize {
        if c.kind == .null { return CGSize(width: w * 0.08, height: w * 0.08) }
        if c.kind == .object3d || c.d3 { return CGSize(width: w * 0.5, height: w * 0.5) }
        if c.kind == .text { return CGSize(width: w * 0.8, height: max(20, c.fontSize * w / 360 * 1.5)) }
        if c.kind == .image, c.fit != "fill", let f = c.file, let ui = store.media.uiImage(f) {
            let s = min(w / Double(ui.size.width), h / Double(ui.size.height))
            return CGSize(width: Double(ui.size.width) * s, height: Double(ui.size.height) * s)
        }
        return CGSize(width: w, height: h)
    }

    @ViewBuilder private func outline(_ q: ZProject, _ fit: CGFloat) -> some View {
        if let c = store.selectedClip, c.kind != .audio, c.kind != .effect, c.kind != .camera, Compositor.active(c, store.playhead) {
            let pr = c.props(at: max(0, store.playhead - c.start))
            let w = Double(q.width) * Double(fit), h = Double(q.height) * Double(fit)
            let size = contentSize(c, w, h)
            Rectangle().strokeBorder(store.accent, lineWidth: 1.5)
                .frame(width: size.width * pr.s / 100, height: size.height * pr.s / 100)
                .rotationEffect(.degrees(pr.r))
                .offset(x: pr.x / 100 * w, y: pr.y / 100 * h)
                .allowsHitTesting(false)
        }
    }

    private func move(_ q: ZProject, _ fit: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 4)
            .onChanged { v in
                guard let c = store.selectedClip, c.kind != .camera else { return }
                if dragStart == nil {
                    let pr = c.props(at: max(0, store.playhead - c.start))
                    dragStart = (pr.x, pr.y); store.pushUndo()
                }
                guard let s = dragStart else { return }
                store.setProp("x", s.0 + Double(v.translation.width / fit) / Double(q.width) * 100)
                store.setProp("y", s.1 + Double(v.translation.height / fit) / Double(q.height) * 100)
            }
            .onEnded { _ in dragStart = nil }
    }

    private var pinch: some Gesture {
        MagnificationGesture()
            .onChanged { m in
                guard let c = store.selectedClip, c.kind != .camera else { return }
                if pinchStart == nil { pinchStart = c.props(at: max(0, store.playhead - c.start)).s; store.pushUndo() }
                store.setProp("s", min(1000, max(5, (pinchStart ?? 100) * Double(m))))
            }
            .onEnded { _ in pinchStart = nil }
    }

    private var twist: some Gesture {
        RotationGesture()
            .onChanged { a in
                guard let c = store.selectedClip, c.kind != .camera else { return }
                if twistStart == nil { twistStart = c.props(at: max(0, store.playhead - c.start)).r; store.pushUndo() }
                store.setProp("r", (twistStart ?? 0) + a.degrees)
            }
            .onEnded { _ in twistStart = nil }
    }
}

struct ZTimeline: View {
    @EnvironmentObject var store: ZEROStore
    @State private var origin: [UUID: Double] = [:]
    @State private var trimOrigin: [UUID: [Double]] = [:]
    private let rowH: CGFloat = 40
    private let rulerH: CGFloat = 22

    static func rows(_ p: ZProject) -> [Int] {
        var s = Set<Int>([0])
        for c in p.clips { s.insert(c.rowKey) }
        return s.sorted(by: >)
    }

    var body: some View {
        if let p = store.project {
            let pps = 60.0 * store.zoom
            let rows = ZTimeline.rows(p)
            let totalW = max(UIScreen.main.bounds.width - 24, CGFloat((store.duration + 4) * pps))
            let totalH = rulerH + rowH * CGFloat(rows.count)
            ScrollView([.horizontal, .vertical], showsIndicators: false) {
                ZStack(alignment: .topLeading) {
                    VStack(spacing: 0) {
                        Color.clear.frame(height: rulerH)
                        ForEach(rows, id: \.self) { r in rowBackground(r, totalW, pps) }
                    }
                    ruler(totalW, pps)
                    ForEach(p.clips) { c in clipView(c, rows, pps) }
                    Rectangle().fill(store.accent).frame(width: 2, height: totalH).offset(x: CGFloat(store.playhead * pps) - 1).allowsHitTesting(false)
                }
                .frame(width: totalW, height: totalH, alignment: .topLeading)
                .coordinateSpace(name: "tl")
            }
            .frame(height: rulerH + rowH * CGFloat(min(max(rows.count, 3), 5)))
            .background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private func rowBackground(_ r: Int, _ w: CGFloat, _ pps: Double) -> some View {
        rowBase(r, w).dropDestination(for: String.self) { items, loc in
            store.handleDrop(items, row: r, time: Double(loc.x) / pps)
        }
    }

    private func rowBase(_ r: Int, _ w: CGFloat) -> some View {
        Rectangle().fill(Color.white.opacity(r % 2 == 0 ? 0.03 : 0.06)).frame(width: w, height: rowH)
            .overlay(alignment: .topLeading) {
                Text(ZClip.laneName(r)).font(.system(size: 8, weight: .bold)).foregroundColor(.zeroMuted)
                    .padding(.horizontal, 5).padding(.vertical, 1).background(Color.black.opacity(0.4), in: Capsule()).padding(3)
            }
    }

    private func ruler(_ w: CGFloat, _ pps: Double) -> some View {
        ZStack(alignment: .topLeading) {
            Rectangle().fill(Color.white.opacity(0.08)).frame(width: w, height: rulerH)
            ForEach(0..<(Int(Double(w) / pps) + 1), id: \.self) { s in
                Text(String(format: "%d:%02d", s / 60, s % 60)).font(.system(size: 8)).foregroundColor(.zeroMuted).offset(x: CGFloat(Double(s) * pps) + 2, y: 3)
                Rectangle().fill(Color.white.opacity(0.2)).frame(width: 1, height: 7).offset(x: CGFloat(Double(s) * pps), y: 15)
            }
        }
        .frame(width: w, height: rulerH, alignment: .topLeading)
        .contentShape(Rectangle())
        .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .named("tl")).onChanged { v in
            store.playhead = max(0, min(max(store.duration, 0.01), Double(v.location.x) / pps))
        })
    }

    private func color(_ c: ZClip) -> Color {
        switch c.kind {
        case .video: return store.accent.opacity(0.75)
        case .image: return Color(hex: "#2F6FC0")
        case .text: return Color(hex: "#C0782F")
        case .audio: return Color(hex: "#2FA06A")
        case .effect: return Color(hex: "#D0589A")
        case .null: return Color(hex: "#555A68")
        case .camera: return Color(hex: "#A0642A")
        case .compound: return Color(hex: "#8A5FD0")
        case .object3d: return Color(hex: "#1F8F9A")
        }
    }

    private func keyTimes(_ c: ZClip) -> [Double] {
        var set = Set<Double>()
        for a in c.keys.values { for k in a { set.insert(k.t) } }
        return set.sorted()
    }

    @ViewBuilder private func clipView(_ c: ZClip, _ rows: [Int], _ pps: Double) -> some View {
        let ri = rows.firstIndex(of: c.rowKey) ?? 0
        let wd = max(26, CGFloat(c.duration * pps))
        let sel = store.selectedID == c.id
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 9, style: .continuous).fill(color(c))
            RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(sel ? Color.white : Color.white.opacity(0.25), lineWidth: sel ? 2 : 1)
            Text(c.name).font(.system(size: 10, weight: .bold)).lineLimit(1).padding(.horizontal, 16).foregroundColor(.white)
            if !c.transition.type.isEmpty {
                Image(systemName: "arrow.left.arrow.right").font(.system(size: 8)).padding(3).background(Color.black.opacity(0.5), in: Circle())
                    .frame(maxWidth: .infinity, alignment: .trailing).offset(x: 6)
            }
            ForEach(keyTimes(c), id: \.self) { kt in
                Image(systemName: "diamond.fill").font(.system(size: 8)).foregroundColor(.white).offset(x: CGFloat(kt * pps) - 4, y: 12)
            }
            HStack(spacing: 0) {
                Rectangle().fill(Color.white.opacity(0.35)).frame(width: 12).gesture(trimLeft(c, pps))
                Spacer(minLength: 0)
                Rectangle().fill(Color.white.opacity(0.35)).frame(width: 12).gesture(trimRight(c, pps))
            }.clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
        .frame(width: wd, height: rowH - 6)
        .offset(x: CGFloat(c.start * pps), y: rulerH + CGFloat(ri) * rowH + 3)
        .gesture(moveGesture(c, rows, pps))
        .onTapGesture { store.selectedID = c.id }
        .dropDestination(for: String.self) { items, loc in
            store.handleDropOnClip(items, clip: c.id, rightHalf: Double(loc.x) > Double(wd) / 2)
        }
    }

    private func snap(_ n: Double, _ c: ZClip, _ pps: Double) -> Double {
        guard let p = store.project else { return n }
        var edges = [0.0, store.playhead]
        for o in p.clips where o.id != c.id { edges.append(o.start); edges.append(o.end) }
        let th = 10 / pps
        for e in edges where abs(n - e) < th { return e }
        for e in edges where abs(n + c.duration - e) < th { return max(0, e - c.duration) }
        return n
    }

    private func moveGesture(_ c: ZClip, _ rows: [Int], _ pps: Double) -> some Gesture {
        DragGesture(minimumDistance: 6, coordinateSpace: .named("tl"))
            .onChanged { v in
                if origin[c.id] == nil { origin[c.id] = c.start; store.selectedID = c.id; store.pushUndo() }
                let n = snap(max(0, (origin[c.id] ?? c.start) + Double(v.translation.width) / pps), c, pps)
                store.updateClip(c.id, record: false) { $0.start = n }
            }
            .onEnded { v in
                origin[c.id] = nil
                let row = Int((v.location.y - rulerH) / rowH)
                if row >= 0, row < rows.count, c.kind != .audio, !c.isRig, rows[row] != -1000, rows[row] != 2000, rows[row] != c.lane {
                    let lane = rows[row]
                    store.updateClip(c.id, record: false) { $0.lane = lane }
                }
            }
    }

    private func trimLeft(_ c: ZClip, _ pps: Double) -> some Gesture {
        DragGesture(minimumDistance: 2, coordinateSpace: .named("tl"))
            .onChanged { v in
                if trimOrigin[c.id] == nil { trimOrigin[c.id] = [c.start, c.duration, c.srcIn]; store.pushUndo(); store.selectedID = c.id }
                guard let o = trimOrigin[c.id] else { return }
                let media = c.kind == .video || c.kind == .audio
                var d = Double(v.translation.width) / pps
                d = max(d, -o[0])
                if media { d = max(d, -o[2] / c.speed) }
                d = min(d, o[1] - 0.2)
                store.updateClip(c.id, record: false) { $0.start = o[0] + d; $0.duration = o[1] - d; if media { $0.srcIn = o[2] + d * c.speed } }
            }
            .onEnded { _ in trimOrigin[c.id] = nil }
    }

    private func trimRight(_ c: ZClip, _ pps: Double) -> some Gesture {
        DragGesture(minimumDistance: 2, coordinateSpace: .named("tl"))
            .onChanged { v in
                if trimOrigin[c.id] == nil { trimOrigin[c.id] = [c.start, c.duration, c.srcIn]; store.pushUndo(); store.selectedID = c.id }
                guard let o = trimOrigin[c.id] else { return }
                var d = o[1] + Double(v.translation.width) / pps
                if c.srcDur > 0 && (c.kind == .video || c.kind == .audio) { d = min(d, (c.srcDur - o[2]) / c.speed) }
                d = max(0.2, d)
                store.updateClip(c.id, record: false) { $0.duration = d }
            }
            .onEnded { _ in trimOrigin[c.id] = nil }
    }
}
