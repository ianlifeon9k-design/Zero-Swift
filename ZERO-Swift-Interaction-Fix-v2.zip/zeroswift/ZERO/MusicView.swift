import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct MusicView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var showImporter = false
    @State private var renameSong: UUID?
    @State private var draft = ""
    @State private var coverFor: UUID?
    @State private var coverItem: PhotosPickerItem?
    @State private var showCover = false
    @State private var newList = false
    @State private var listName = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                Text("ZERO / MUSIC").font(.caption.bold()).tracking(2).foregroundColor(store.accent)
                playerCard
                optionsCard
                libraryCard
                playlistsCard
            }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 10)
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.audio, .movie, .mp3, .mpeg4Audio], allowsMultipleSelection: true) { r in
            if case .success(let urls) = r { store.importSongs(urls) }
        }
        .photosPicker(isPresented: $showCover, selection: $coverItem, matching: .images)
        .onChange(of: coverItem) { item in
            guard let item = item, let id = coverFor else { return }
            Task {
                if let d = try? await item.loadTransferable(type: Data.self) { await MainActor.run { store.setCover(id, data: d) } }
                await MainActor.run { coverItem = nil }
            }
        }
        .alert("Rename song", isPresented: Binding(get: { renameSong != nil }, set: { if !$0 { renameSong = nil } })) {
            TextField("Song name", text: $draft)
            Button("Save") { if let id = renameSong { store.renameSong(id, draft) }; renameSong = nil }
            Button("Cancel", role: .cancel) { renameSong = nil }
        }
        .alert("New playlist", isPresented: $newList) {
            TextField("Playlist name", text: $listName)
            Button("Create") { if !listName.isEmpty { store.playlists.append(ZPlaylist(name: listName)) }; listName = "" }
            Button("Cancel", role: .cancel) { listName = "" }
        }
    }

    private func cover(_ s: ZSong?, _ size: CGFloat) -> some View {
        Group {
            if let f = s?.cover, let ui = UIImage(contentsOfFile: store.media.url(f).path) {
                Image(uiImage: ui).resizable().scaledToFill()
            } else {
                ZStack { LinearGradient(colors: [store.accent.opacity(0.7), .black], startPoint: .topLeading, endPoint: .bottomTrailing); Image(systemName: "music.note").foregroundColor(.white) }
            }
        }.frame(width: size, height: size).clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
    }

    private var playerCard: some View {
        let cur = store.songs.first { $0.id == store.nowPlaying }
        return GlassCard {
            VStack(spacing: 14) {
                HStack(spacing: 14) {
                    cover(cur, 72)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(cur?.name ?? "Nothing playing").font(.headline).lineLimit(1)
                        Text(store.musicPlaying ? "Playing" : "Music is off until you press play").font(.caption).foregroundColor(.zeroMuted)
                    }
                    Spacer()
                }
                HStack(spacing: 18) {
                    Button { store.nextSong(-1) } label: { Image(systemName: "backward.fill") }
                    Button { store.toggleMusic() } label: {
                        Image(systemName: store.musicPlaying ? "pause.fill" : "play.fill").font(.title2).foregroundColor(.black)
                            .frame(width: 54, height: 54).background(store.accent, in: Circle())
                    }
                    Button { store.nextSong(1) } label: { Image(systemName: "forward.fill") }
                    Spacer()
                    Button { showImporter = true } label: { Label("Add music", systemImage: "plus") }.buttonStyle(ZeroButtonStyle())
                }.foregroundColor(.white)
            }
        }
    }

    private var optionsCard: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Toggle("Pause music while my edit plays, then resume", isOn: Binding(get: { store.settings.pauseMusicOnPlay }, set: { store.settings.pauseMusicOnPlay = $0 })).tint(store.accent)
                Toggle("Show what I'm listening to on my profile", isOn: Binding(get: { store.settings.shareListening }, set: { store.settings.shareListening = $0 })).tint(store.accent)
                Text("Your profile shows the song name and cover on this device. Others will see it once online accounts exist. Videos can be added as music too: their sound is used.").font(.caption).foregroundColor(.zeroMuted)
            }
        }
    }

    private var libraryCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Library").font(.title3.bold())
            if store.songs.isEmpty { GlassCard { Text("No music yet. Add an MP3, or a video to use its sound. Nothing plays until you press play.").font(.subheadline).foregroundColor(.zeroMuted) } }
            ForEach(store.songs) { s in
                HStack(spacing: 12) {
                    cover(s, 46)
                    Text(s.name).lineLimit(1).foregroundColor(.white)
                    Spacer()
                    Button { store.play(song: s.id) } label: { Image(systemName: store.nowPlaying == s.id && store.musicPlaying ? "waveform" : "play.circle.fill").font(.title3) }
                    Menu {
                        Button("Rename") { draft = s.name; renameSong = s.id }
                        Button("Set cover image") { coverFor = s.id; showCover = true }
                        Menu("Add to playlist") {
                            ForEach(store.playlists) { pl in
                                Button(pl.name) { if let i = store.playlists.firstIndex(where: { $0.id == pl.id }), !store.playlists[i].songs.contains(s.id) { store.playlists[i].songs.append(s.id) } }
                            }
                        }
                        Button("Remove", role: .destructive) { store.removeSong(s.id) }
                    } label: { Image(systemName: "ellipsis").frame(width: 32, height: 32).foregroundColor(.white) }
                }
                .padding(10).background(Color.white.opacity(store.settings.glass), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
    }

    private var playlistsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text("Playlists").font(.title3.bold()); Spacer(); Button { newList = true } label: { Label("New", systemImage: "plus") }.buttonStyle(ZeroButtonStyle()) }
            ForEach(store.playlists) { pl in
                GlassCard {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(pl.name).font(.headline)
                            Spacer()
                            Button { if let f = pl.songs.first { store.play(song: f, in: pl.songs) } } label: { Image(systemName: "play.circle.fill").font(.title2) }
                            Button(role: .destructive) { store.playlists.removeAll { $0.id == pl.id } } label: { Image(systemName: "trash") }
                        }
                        Text(pl.songs.compactMap { id in store.songs.first { $0.id == id }?.name }.joined(separator: " · ").isEmpty ? "Empty" : pl.songs.compactMap { id in store.songs.first { $0.id == id }?.name }.joined(separator: " · ")).font(.caption).foregroundColor(.zeroMuted)
                        Toggle("Show on my profile", isOn: Binding(get: { pl.isPublic }, set: { v in if let i = store.playlists.firstIndex(where: { $0.id == pl.id }) { store.playlists[i].isPublic = v } })).tint(store.accent)
                    }
                }
            }
        }
    }
}
