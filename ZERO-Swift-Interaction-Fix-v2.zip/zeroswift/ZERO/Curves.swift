import Foundation

enum Curves {
    static let groups: [(String, [String])] = [
        ("Basic", ["linear", "sineIn", "sineOut", "sineInOut"]), ("Quad", ["quadIn", "quadOut", "quadInOut"]),
        ("Cubic", ["cubicIn", "cubicOut", "cubicInOut"]), ("Quart", ["quartIn", "quartOut", "quartInOut"]),
        ("Expo", ["expoIn", "expoOut", "expoInOut"]), ("Back", ["backIn", "backOut", "backInOut"]),
        ("Elastic", ["elasticIn", "elasticOut"]), ("Bounce", ["bounceIn", "bounceOut", "bounceInOut"]), ("Spring", ["spring"])]

    // id, title, default handle x, default handle y, hint
    static let specials: [(String, String, Double, Double, String)] = [
        ("steps", "Steps", 0.3, 0, "Yellow handle: left = fewer steps, right = more. Down = hard steps, up = smooth."),
        ("bounce", "Bouncy", 0.35, 0.5, "Yellow handle: left = fewer bounces, right = more. Up = bouncier."),
        ("springx", "Spring", 0.4, 0.6, "Yellow handle: left = slower wobble, right = faster. Up = more springy."),
        ("wiggle", "Wiggle", 0.4, 0.5, "Yellow handle: left = slow shake, right = fast. Up = stronger."),
        ("loop", "Repeat", 0.6, 0, "Repeats the keyframe motion again and again. Left = more repeats, right = fewer. Up = smoother."),
        ("pp", "Ping-pong", 0.6, 0, "Plays the motion forward and back. Left = more, right = fewer. Up = smoother.")]

    static func isSpecial(_ k: String) -> Bool { specials.contains { $0.0 == k } }

    static func eval(_ c: ZCurve, _ f: Double) -> Double {
        let x = min(max(f, 0), 1)
        switch c.kind {
        case "bezier": return bezier(x, c.a, c.b, c.c, c.d)
        case "steps":
            let n = Double(2 + Int((c.a * 18).rounded()))
            let s = min(1, floor(x * n) / (n - 1))
            return s + (x - s) * c.b
        case "bounce": return bounceN(x, c.a, c.b)
        case "springx":
            let w = 4 + c.a * 36, d = 2 + (1 - c.b) * 10
            let v = 1 - exp(-d * x) * cos(w * x), v1 = 1 - exp(-d) * cos(w)
            return v + (1 - v1) * x * x * x
        case "wiggle":
            let fr = 2 + c.a * 38
            return x + c.b * 0.6 * sin(Double.pi * x) * (sin(x * fr * 6.2832) * 0.6 + sin(x * fr * 13.7 + 1.3) * 0.4)
        case "loop":
            let n = 1 + ((1 - c.a) * 15).rounded()
            let fr = x >= 1 ? 1 : (x * n).truncatingRemainder(dividingBy: 1)
            return fr + (fr * fr * (3 - 2 * fr) - fr) * c.b
        case "pp":
            let n = 1 + 2 * ((1 - c.a) * 7).rounded()
            let p = (x * n).truncatingRemainder(dividingBy: 2)
            let fr = x >= 1 ? 1 : (p < 1 ? p : 2 - p)
            return fr + (fr * fr * (3 - 2 * fr) - fr) * c.b
        default: return preset(c.kind, x)
        }
    }

    static func bounceN(_ x: Double, _ a: Double, _ b: Double) -> Double {
        if x >= 1 { return 1 }
        let n = 1 + Int((a * 7).rounded()), r = 0.15 + b * 0.7
        var seg: [Double] = [1]
        for i in 1...n { seg.append(2 * sqrt(pow(r, Double(i)))) }
        var c = x * seg.reduce(0, +)
        for (i, s) in seg.enumerated() {
            if c < s { let u = c / s; return i > 0 ? 1 - pow(r, Double(i)) * 4 * u * (1 - u) : u * u }
            c -= s
        }
        return 1
    }

    static func bezier(_ x: Double, _ a: Double, _ b: Double, _ c: Double, _ d: Double) -> Double {
        var t = x
        for _ in 0..<8 {
            let cx = 3 * a * t * pow(1 - t, 2) + 3 * c * t * t * (1 - t) + t * t * t - x
            let dx = 3 * a * pow(1 - t, 2) + 6 * (c - a) * t * (1 - t) + 3 * (1 - c) * t * t
            if abs(dx) < 1e-6 { break }
            t -= cx / dx
        }
        t = min(1, max(0, t))
        return 3 * b * t * pow(1 - t, 2) + 3 * d * t * t * (1 - t) + t * t * t
    }

    static func bounceOut(_ x0: Double) -> Double {
        var x = x0
        let n = 7.5625, d = 2.75
        if x < 1 / d { return n * x * x }
        if x < 2 / d { x -= 1.5 / d; return n * x * x + 0.75 }
        if x < 2.5 / d { x -= 2.25 / d; return n * x * x + 0.9375 }
        x -= 2.625 / d
        return n * x * x + 0.984375
    }

    static func preset(_ k: String, _ x: Double) -> Double {
        switch k {
        case "sineIn": return 1 - cos(x * Double.pi / 2)
        case "sineOut": return sin(x * Double.pi / 2)
        case "sineInOut": return -(cos(Double.pi * x) - 1) / 2
        case "quadIn": return x * x
        case "quadOut": return 1 - (1 - x) * (1 - x)
        case "quadInOut": return x < 0.5 ? 2 * x * x : 1 - pow(-2 * x + 2, 2) / 2
        case "cubicIn": return pow(x, 3)
        case "cubicOut": return 1 - pow(1 - x, 3)
        case "cubicInOut": return x < 0.5 ? 4 * pow(x, 3) : 1 - pow(-2 * x + 2, 3) / 2
        case "quartIn": return pow(x, 4)
        case "quartOut": return 1 - pow(1 - x, 4)
        case "quartInOut": return x < 0.5 ? 8 * pow(x, 4) : 1 - pow(-2 * x + 2, 4) / 2
        case "expoIn": return x == 0 ? 0 : pow(2, 10 * x - 10)
        case "expoOut": return x == 1 ? 1 : 1 - pow(2, -10 * x)
        case "expoInOut":
            if x == 0 { return 0 }
            if x == 1 { return 1 }
            return x < 0.5 ? pow(2, 20 * x - 10) / 2 : (2 - pow(2, -20 * x + 10)) / 2
        case "backIn": return 2.70158 * pow(x, 3) - 1.70158 * x * x
        case "backOut": return 1 + 2.70158 * pow(x - 1, 3) + 1.70158 * pow(x - 1, 2)
        case "backInOut":
            return x < 0.5 ? pow(2 * x, 2) * (7.189819 * x - 2.5949095) / 2 : (pow(2 * x - 2, 2) * (3.5949095 * (2 * x - 2) + 2.5949095) + 2) / 2
        case "elasticIn": return x == 0 ? 0 : (x == 1 ? 1 : -pow(2, 10 * x - 10) * sin((x * 10 - 10.75) * 2.0944))
        case "elasticOut": return x == 0 ? 0 : (x == 1 ? 1 : pow(2, -10 * x) * sin((x * 10 - 0.75) * 2.0944) + 1)
        case "bounceOut": return bounceOut(x)
        case "bounceIn": return 1 - bounceOut(1 - x)
        case "bounceInOut": return x < 0.5 ? (1 - bounceOut(1 - 2 * x)) / 2 : (1 + bounceOut(2 * x - 1)) / 2
        case "spring": return 1 - exp(-6 * x) * cos(14 * x) * (1 - x)
        default: return x
        }
    }
}
