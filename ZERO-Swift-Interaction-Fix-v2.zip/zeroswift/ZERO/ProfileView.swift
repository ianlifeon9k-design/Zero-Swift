import SwiftUI
import PhotosUI

struct ProfileView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var editing = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text("ZERO / PROFILE").font(.caption.bold()).tracking(2).foregroundColor(store.accent)
                    Spacer()
                    Button { store.section = .settings } label: { Image(systemName: "gearshape.fill").padding(10).background(Color.white.opacity(0.08), in: Circle()) }.foregroundColor(.white)
                }
                header
                if let s = store.listening, store.settings.shareListening { listeningCard(s) }
                GlassCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("BIO").font(.system(size: 10, weight: .bold)).tracking(1.5).foregroundColor(.zeroMuted)
                        Text(store.settings.bio.isEmpty ? "Add a little about your creative style." : store.settings.bio).font(.subheadline)
                        Button { editing = true } label: { Label("Edit profile", systemImage: "pencil") }.buttonStyle(ZeroButtonStyle(primary: true, accent: store.accent)).padding(.top, 4)
                    }
                }
                playlistsCard
                GlassCard {
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Local profile", systemImage: "lock.fill").font(.headline)
                        Text("Your profile is stored on this device. Friends, public sharing and discovery need an online account service, which isn't connected yet.").font(.caption).foregroundColor(.zeroMuted)
                    }
                }
            }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 10)
        }
        .sheet(isPresented: $editing) { ProfileEditSheet().environmentObject(store) }
    }

    private var header: some View {
        let s = store.settings
        return ZStack(alignment: .bottomLeading) {
            ZStack {
                if let f = s.bannerFile, f.hasSuffix(".gif") {
                    GIFImage(file: f, media: store.media)
                } else if let f = s.bannerFile, let ui = UIImage(contentsOfFile: store.media.url(f).path) {
                    Image(uiImage: ui).resizable().scaledToFill()
                } else {
                    let g = Themes.bannerGradients[min(s.bannerPreset, Themes.bannerGradients.count - 1)]
                    LinearGradient(colors: [Color(hex: g[0]), Color(hex: g[1])], startPoint: .topLeading, endPoint: .bottomTrailing)
                }
            }.frame(height: 160).frame(maxWidth: .infinity).clipped()
            HStack(alignment: .bottom, spacing: 12) {
                avatar(78)
                VStack(alignment: .leading, spacing: 3) {
                    Text(s.creatorName).font(.title3.bold())
                    Text("@\(s.username)").font(.caption).foregroundColor(.white.opacity(0.75))
                    if !s.status.isEmpty { Text(s.status).font(.caption2).padding(.horizontal, 8).padding(.vertical, 3).background(Color.black.opacity(0.4), in: Capsule()) }
                }
                Spacer()
            }.padding(14)
        }
        .clipShape(RoundedRectangle(cornerRadius: CGFloat(s.radius) + 4, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: CGFloat(s.radius) + 4, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
    }

    private func avatar(_ size: CGFloat) -> some View {
        Group {
            if let f = store.settings.avatarFile, f.hasSuffix(".gif") {
                GIFImage(file: f, media: store.media)
            } else if let f = store.settings.avatarFile, let ui = UIImage(contentsOfFile: store.media.url(f).path) {
                Image(uiImage: ui).resizable().scaledToFill()
            } else {
                ZStack {
                    LinearGradient(colors: [.white, store.accent], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Text(String(store.settings.creatorName.prefix(1)).uppercased()).font(.system(size: size * 0.4, weight: .black)).foregroundColor(.black)
                }
            }
        }.frame(width: size, height: size).clipShape(Circle()).overlay(Circle().stroke(Color.white.opacity(0.6), lineWidth: 2))
    }

    private func listeningCard(_ s: ZSong) -> some View {
        GlassCard {
            HStack(spacing: 12) {
                Group {
                    if let f = s.cover, let ui = UIImage(contentsOfFile: store.media.url(f).path) { Image(uiImage: ui).resizable().scaledToFill() }
                    else { ZStack { store.accent.opacity(0.5); Image(systemName: "music.note") } }
                }.frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 2) {
                    Text("LISTENING NOW").font(.system(size: 9, weight: .bold)).tracking(1.4).foregroundColor(store.accent)
                    Text(s.name).font(.headline).lineLimit(1)
                }
                Spacer()
                Image(systemName: "waveform").foregroundColor(store.accent)
            }
        }
    }

    private var playlistsCard: some View {
        let pub = store.playlists.filter { $0.isPublic }
        return GlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Text("PUBLIC PLAYLISTS").font(.system(size: 10, weight: .bold)).tracking(1.5).foregroundColor(.zeroMuted)
                if pub.isEmpty { Text("None yet. Turn on Show on my profile in Music.").font(.caption).foregroundColor(.zeroMuted) }
                ForEach(pub) { pl in
                    HStack { Image(systemName: "music.note.list").foregroundColor(store.accent); Text(pl.name); Spacer(); Text("\(pl.songs.count) songs").font(.caption).foregroundColor(.zeroMuted) }
                }
            }
        }
    }
}

struct ProfileEditSheet: View {
    @EnvironmentObject var store: ZEROStore
    @Environment(\.dismiss) private var dismiss
    @State private var avatarItem: PhotosPickerItem?
    @State private var bannerItem: PhotosPickerItem?

    var body: some View {
        ZStack {
            ThemeBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Edit profile").font(.title.bold())
                    field("Display name", Binding(get: { store.settings.creatorName }, set: { store.settings.creatorName = String($0.prefix(40)) }))
                    field("Username", Binding(get: { store.settings.username }, set: { store.settings.username = String($0.lowercased().filter { $0.isLetter || $0.isNumber || $0 == "_" }.prefix(20)) }))
                    field("Status", Binding(get: { store.settings.status }, set: { store.settings.status = String($0.prefix(40)) }))
                    Text("BIO").font(.caption.bold()).foregroundColor(.zeroMuted)
                    TextField("Bio", text: Binding(get: { store.settings.bio }, set: { store.settings.bio = String($0.prefix(160)) }), axis: .vertical)
                        .lineLimit(3...5).padding(12).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                    Text("PICTURES").font(.caption.bold()).foregroundColor(.zeroMuted)
                    HStack {
                        PhotosPicker(selection: $avatarItem, matching: .images) { Label("Profile picture", systemImage: "person.crop.circle") }.buttonStyle(ZeroButtonStyle())
                        PhotosPicker(selection: $bannerItem, matching: .images) { Label("Banner image", systemImage: "photo") }.buttonStyle(ZeroButtonStyle())
                    }
                    Text("BANNER COLORS").font(.caption.bold()).foregroundColor(.zeroMuted)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(0..<Themes.bannerGradients.count, id: \.self) { i in
                                let g = Themes.bannerGradients[i]
                                Button { store.settings.bannerPreset = i; store.settings.bannerFile = nil } label: {
                                    RoundedRectangle(cornerRadius: 14).fill(LinearGradient(colors: [Color(hex: g[0]), Color(hex: g[1])], startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 64, height: 44)
                                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(store.settings.bannerFile == nil && store.settings.bannerPreset == i ? Color.white : Color.clear, lineWidth: 2))
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                    Button { dismiss() } label: { Text("Done").frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle(primary: true, accent: store.accent)).padding(.top, 6)
                }.padding(20)
            }
        }
        .onChange(of: avatarItem) { item in load(item, banner: false) }
        .onChange(of: bannerItem) { item in load(item, banner: true) }
    }

    private func field(_ title: String, _ b: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title.uppercased()).font(.caption.bold()).foregroundColor(.zeroMuted)
            TextField(title, text: b).padding(12).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
        }
    }

    private func load(_ item: PhotosPickerItem?, banner: Bool) {
        guard let item = item else { return }
        Task {
            if let d = try? await item.loadTransferable(type: Data.self) { await MainActor.run { store.saveProfileImage(d, banner: banner) } }
        }
    }
}

struct ChatView: View {
    @EnvironmentObject var store: ZEROStore
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                Text("ZERO / MESSAGES").font(.caption.bold()).tracking(2).foregroundColor(store.accent)
                TextField("Search conversations", text: .constant("")).disabled(true).padding(12).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                GlassCard {
                    VStack(spacing: 8) {
                        Image(systemName: "bubble.left.and.bubble.right.fill").font(.system(size: 34)).foregroundColor(store.accent)
                        Text("No conversations yet").font(.headline)
                        Text("Messaging needs an online account service, which isn't connected yet. This screen is the interface only; nothing is sent.").font(.caption).foregroundColor(.zeroMuted).multilineTextAlignment(.center)
                    }.frame(maxWidth: .infinity)
                }
                Text("PREVIEW").font(.system(size: 10, weight: .bold)).tracking(1.5).foregroundColor(.zeroMuted)
                VStack(spacing: 8) {
                    bubble("Hey! Loved your last edit.", me: false)
                    bubble("Thanks, made it in ZERO.", me: true)
                }.opacity(0.5)
                HStack {
                    TextField("Message…", text: .constant("")).disabled(true).padding(12).background(Color.white.opacity(0.07), in: Capsule())
                    Image(systemName: "paperplane.fill").padding(12).background(Color.white.opacity(0.1), in: Circle())
                }.opacity(0.6)
            }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 10)
        }
    }
    private func bubble(_ t: String, me: Bool) -> some View {
        HStack {
            if me { Spacer() }
            Text(t).font(.subheadline).foregroundColor(me ? .black : .white).padding(.horizontal, 14).padding(.vertical, 10)
                .background(me ? store.accent : Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            if !me { Spacer() }
        }
    }
}

/// Shows an animated GIF (profile picture or banner).
struct GIFImage: UIViewRepresentable {
    let file: String
    let media: MediaCache
    func makeUIView(context: Context) -> UIImageView {
        let v = UIImageView()
        v.contentMode = .scaleAspectFill
        v.clipsToBounds = true
        return v
    }
    func updateUIView(_ v: UIImageView, context: Context) {
        if v.image == nil, let g = media.gif(file) { v.image = UIImage.animatedImage(with: g.frames, duration: g.total) }
    }
}
