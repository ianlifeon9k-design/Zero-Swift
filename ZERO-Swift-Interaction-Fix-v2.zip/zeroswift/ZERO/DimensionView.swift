import SwiftUI
import SceneKit

struct DimensionView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var shape = "Cube"
    @State private var color = Color(hex: "#A78BFA")
    @State private var spin = true
    @State private var wire = false
    private let shapes = ["Cube", "Sphere", "Cone", "Torus", "Pyramid", "Capsule", "Cylinder", "Tube"]

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Text("ZERO / 3D").font(.caption.bold()).tracking(2).foregroundColor(store.accent)
                Spacer()
            }
            SceneView(scene: makeScene(), options: [.allowsCameraControl, .autoenablesDefaultLighting])
                .clipShape(RoundedRectangle(cornerRadius: CGFloat(store.settings.radius), style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: CGFloat(store.settings.radius), style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
                .frame(maxHeight: .infinity)
            GlassCard {
                VStack(alignment: .leading, spacing: 10) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack { ForEach(shapes, id: \.self) { s in Chip(title: s, active: shape == s, accent: store.accent) { shape = s } } }
                    }
                    ColorPicker("Color", selection: $color, supportsOpacity: false)
                    Toggle("Auto-spin", isOn: $spin).tint(store.accent)
                    Toggle("Wireframe", isOn: $wire).tint(store.accent)
                    Text("Drag to orbit and pinch to zoom. Timeline 3D layers come with the WebGL stage.").font(.caption).foregroundColor(.zeroMuted)
                }
            }
        }.padding(.horizontal, 14).padding(.top, 12).padding(.bottom, 8)
    }

    private func makeScene() -> SCNScene {
        let scene = SCNScene()
        let geo: SCNGeometry
        switch shape {
        case "Sphere": geo = SCNSphere(radius: 1)
        case "Cone": geo = SCNCone(topRadius: 0, bottomRadius: 1, height: 2)
        case "Torus": geo = SCNTorus(ringRadius: 1, pipeRadius: 0.35)
        case "Pyramid": geo = SCNPyramid(width: 2, height: 2, length: 2)
        case "Capsule": geo = SCNCapsule(capRadius: 0.6, height: 2.4)
        case "Cylinder": geo = SCNCylinder(radius: 0.9, height: 2)
        case "Tube": geo = SCNTube(innerRadius: 0.6, outerRadius: 1, height: 2)
        default: geo = SCNBox(width: 1.6, height: 1.6, length: 1.6, chamferRadius: 0.1)
        }
        let m = SCNMaterial()
        m.diffuse.contents = UIColor(color)
        m.lightingModel = .physicallyBased
        m.metalness.contents = 0.3
        m.roughness.contents = 0.4
        if wire { m.fillMode = .lines }
        geo.materials = [m]
        let node = SCNNode(geometry: geo)
        if spin { node.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: CGFloat.pi * 2, z: 0, duration: 8))) }
        scene.rootNode.addChildNode(node)
        return scene
    }
}
