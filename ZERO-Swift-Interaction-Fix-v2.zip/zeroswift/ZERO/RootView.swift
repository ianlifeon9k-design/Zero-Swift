import SwiftUI

struct Ripple: Identifiable { let id = UUID(); let p: CGPoint }

struct RippleView: View {
    let color: Color
    let size: Double
    let style: String
    @State private var grow = false
    var body: some View {
        Circle()
            .strokeBorder(style == "fill" ? Color.clear : color, lineWidth: 3)
            .background(Circle().fill(style == "fill" ? color.opacity(0.45) : Color.clear))
            .shadow(color: style == "glow" ? color : Color.clear, radius: 14)
            .frame(width: size, height: size)
            .scaleEffect(grow ? 1.7 : 0.3)
            .opacity(grow ? 0 : 0.9)
            .onAppear { withAnimation(.easeOut(duration: 0.6)) { grow = true } }
    }
}

struct RootView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var ripples: [Ripple] = []

    private var design: Font.Design {
        switch store.settings.fontDesign {
        case "serif": return .serif
        case "mono": return .monospaced
        case "default": return .default
        default: return .rounded
        }
    }

    var body: some View {
        ZStack {
            ThemeBackground()
            if !store.settings.onboardingDone { OnboardingView() } else { mainContent }
            tapLayer
        }
        .fontDesign(design)
        // Keep this gesture tap-only. A zero-distance DragGesture on the root view
        // competes with native sliders, scroll views, and timeline drag handles.
        .simultaneousGesture(
            SpatialTapGesture(coordinateSpace: .local)
                .onEnded { value in
                    guard store.settings.tapShow else { return }
                    let ripple = Ripple(p: value.location)
                    ripples.append(ripple)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                        ripples.removeAll { $0.id == ripple.id }
                    }
                }
        )
        .alert("ZERO", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(store.message ?? "") }
    }

    private var tapLayer: some View {
        let c = Color(hex: store.settings.tapHex), s = store.settings.tapSize
        return ZStack {
            ForEach(ripples) { r in RippleView(color: c, size: s, style: store.settings.tapStyle).position(r.p) }
        }.ignoresSafeArea().allowsHitTesting(false)
    }

    @ViewBuilder private var mainContent: some View {
        VStack(spacing: 0) {
            Group {
                switch store.section {
                case .base: HomeView()
                case .studio: EditorView()
                case .music: MusicView()
                case .chat: ChatView()
                case .profile: ProfileView()
                case .settings: SettingsView()
                case .dimension: DimensionView()
                }
            }.frame(maxWidth: .infinity, maxHeight: .infinity)
            if store.section != .studio { TabBar() }
        }
    }
}

struct TabBar: View {
    @EnvironmentObject var store: ZEROStore
    @Namespace private var ns
    private let items: [ZEROSection] = [.base, .studio, .music, .chat, .profile]
    var body: some View {
        HStack(spacing: 4) {
            ForEach(items) { item in
                Button {
                    if item == .studio && store.currentID == nil { store.message = "Open or create a project first."; store.section = .base; return }
                    withAnimation(.spring(response: 0.38, dampingFraction: 0.75)) { store.section = item }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.symbol).font(.system(size: 18, weight: .semibold))
                        Text(item.title).font(.system(size: 10, weight: .semibold))
                    }
                    .foregroundColor(store.section == item ? .white : .zeroMuted)
                    .frame(maxWidth: .infinity).padding(.vertical, 9)
                    .background {
                        if store.section == item { RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.14)).matchedGeometryEffect(id: "tab", in: ns) }
                    }
                }.buttonStyle(.plain)
            }
        }
        .padding(6)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
        .padding(.horizontal, 14).padding(.bottom, 4)
    }
}
