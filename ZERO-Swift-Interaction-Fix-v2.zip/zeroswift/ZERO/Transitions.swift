import SwiftUI

struct TRR {
    var dx = 0.0, dy = 0.0, sx = 1.0, sy = 1.0, rot = 0.0, al = 1.0, blur = 0.0, flash = 0.0
    var mask: ((CGSize) -> Path)? = nil
}

enum Trans {
    static let all: [(String, String, String)] = [
        ("fade", "Crossfade", "Fade"), ("dip", "Dip to black", "Fade"), ("blurz", "Fade zoom", "Fade"),
        ("slide", "Slide left", "Slide"), ("slider", "Slide right", "Slide"), ("push", "Slide up", "Slide"), ("pushd", "Slide down", "Slide"), ("whip", "Whip pan", "Slide"),
        ("zoom", "Zoom in", "Zoom & spin"), ("zoomo", "Zoom out", "Zoom & spin"), ("spinz", "Spin zoom", "Zoom & spin"), ("spin", "Spin", "Zoom & spin"),
        ("wipe", "Wipe right", "Reveal"), ("wipel", "Wipe left", "Reveal"), ("wipeu", "Wipe up", "Reveal"), ("wiped", "Wipe down", "Reveal"),
        ("doors", "Doors open", "Reveal"), ("split", "Split open", "Reveal"), ("iris", "Circle", "Reveal"), ("diamond", "Diamond", "Reveal"),
        ("flip", "Flip", "3D & special"), ("flipv", "Flip vertical", "3D & special"), ("cube", "Cube turn", "3D & special"), ("glitch", "Glitch", "3D & special"),
        ("dipw", "Dip to white", "Fade"), ("zoomblur", "Zoom blur", "Fade"), ("slidefade", "Slide fade", "Slide"), ("bounce", "Bounce in", "Slide"), ("elastic", "Elastic", "Slide"),
        ("rotatein", "Rotate in", "Zoom & spin"), ("ripple", "Ripple", "Zoom & spin"), ("blinds", "Blinds", "Reveal"), ("vblinds", "Vertical blinds", "Reveal"),
        ("checker", "Checkerboard", "Reveal"), ("clock", "Clock wipe", "Reveal"), ("cross", "Cross", "Reveal"), ("heart", "Heart", "Reveal"), ("star", "Star", "Reveal"),
        ("wipediag", "Diagonal wipe", "Reveal"), ("swing", "Door swing", "3D & special")]
    static let groups = ["Fade", "Slide", "Zoom & spin", "Reveal", "3D & special"]
    static func name(_ id: String) -> String { all.first { $0.0 == id }?.1 ?? "None" }

    static func make(_ ty: String, out o: Bool, _ f0: Double, _ sz: CGSize) -> TRR {
        let W = Double(sz.width), H = Double(sz.height)
        let f = f0 * f0 * (3 - 2 * f0)
        let hf = f * Double.pi / 2
        var r = TRR()
        switch ty {
        case "fade": r.al = o ? 1 - f : f
        case "dip": r.al = o ? max(0, 1 - f * 2) : max(0, f * 2 - 1)
        case "slide": r.dx = (o ? -f : 1 - f) * W
        case "slider": r.dx = (o ? f : f - 1) * W
        case "push": r.dy = (o ? -f : 1 - f) * H
        case "pushd": r.dy = (o ? f : f - 1) * H
        case "zoom":
            let s = o ? 1 + f * 0.6 : 0.5 + 0.5 * f
            r.sx = s; r.sy = s; r.al = o ? 1 - f : f
        case "zoomo":
            let s = o ? 1 - f * 0.5 : 1.6 - 0.6 * f
            r.sx = s; r.sy = s; r.al = o ? 1 - f : f
        case "blurz":
            let s = o ? 1 + f * 0.2 : 1.2 - 0.2 * f
            r.sx = s; r.sy = s; r.al = o ? 1 - f : f
        case "wipe": if !o { r.mask = { s in Path(CGRect(x: 0, y: 0, width: s.width * f, height: s.height)) } }
        case "wipel": if !o { r.mask = { s in Path(CGRect(x: s.width * (1 - f), y: 0, width: s.width * f, height: s.height)) } }
        case "wipeu": if !o { r.mask = { s in Path(CGRect(x: 0, y: s.height * (1 - f), width: s.width, height: s.height * f)) } }
        case "wiped": if !o { r.mask = { s in Path(CGRect(x: 0, y: 0, width: s.width, height: s.height * f)) } }
        case "doors":
            if !o { r.mask = { s in var p = Path(); p.addRect(CGRect(x: 0, y: 0, width: s.width * f / 2, height: s.height)); p.addRect(CGRect(x: s.width * (1 - f / 2), y: 0, width: s.width * f / 2, height: s.height)); return p } }
        case "split": if !o { r.mask = { s in Path(CGRect(x: s.width * (1 - f) / 2, y: 0, width: s.width * f, height: s.height)) } }
        case "iris":
            let rad = f * hypot(W, H) / 2
            if !o { r.mask = { s in Path(ellipseIn: CGRect(x: s.width / 2 - rad, y: s.height / 2 - rad, width: rad * 2, height: rad * 2)) } }
        case "diamond":
            let k = f * (W + H) * 0.6
            if !o {
                r.mask = { s in
                    var p = Path()
                    p.move(to: CGPoint(x: s.width / 2, y: s.height / 2 - k)); p.addLine(to: CGPoint(x: s.width / 2 + k, y: s.height / 2))
                    p.addLine(to: CGPoint(x: s.width / 2, y: s.height / 2 + k)); p.addLine(to: CGPoint(x: s.width / 2 - k, y: s.height / 2))
                    p.closeSubpath(); return p
                }
            }
        case "flip": r.sx = max(0.01, o ? cos(hf) : sin(hf))
        case "flipv": r.sy = max(0.01, o ? cos(hf) : sin(hf))
        case "spin":
            r.rot = (o ? -f * 1.2 : (1 - f) * 1.2) * 57.2958; r.al = o ? 1 - f : f
        case "spinz":
            let s = o ? 1 + f : 2 - f
            r.sx = s; r.sy = s; r.rot = (o ? f * 1.5 : (f - 1) * 1.5) * 57.2958; r.al = o ? 1 - f : f
        case "cube":
            r.sx = max(0.01, o ? cos(hf) : sin(hf)); r.dx = (o ? -f : 1 - f) * W * 0.5
        case "glitch":
            r.dx = sin(f * 60) * W * 0.04 * (1 - abs(2 * f - 1)); r.al = o ? (f < 0.5 ? 1 : 0) : (f >= 0.5 ? 1 : 0)
        case "whip":
            r.dx = (o ? -f * f * f : pow(1 - f, 3)) * W * 1.2; r.al = o ? 1 - f * 0.6 : 0.4 + 0.6 * f
        case "dipw":
            r.al = o ? (f < 0.5 ? 1 : 0) : (f > 0.5 ? 1 : 0)
            r.flash = o ? min(1, f * 2) : min(1, (1 - f) * 2)
        case "zoomblur":
            let s = o ? 1 + f * 0.8 : 1.8 - 0.8 * f
            r.sx = s; r.sy = s; r.blur = (o ? f : 1 - f) * W / 27; r.al = o ? 1 - f : f
        case "slidefade": r.dx = (o ? -f : 1 - f) * W * 0.4; r.al = o ? 1 - f : f
        case "bounce": r.dx = o ? -Curves.bounceOut(f0) * W : (1 - Curves.bounceOut(f0)) * W
        case "elastic":
            let k = Curves.preset("elasticOut", f0)
            r.dx = o ? -k * W : (1 - k) * W
        case "rotatein":
            let s = o ? 1 - f * 0.3 : 0.7 + 0.3 * f
            r.sx = s; r.sy = s; r.rot = (o ? f * 0.8 : -(1 - f) * 0.8) * 57.2958; r.al = o ? 1 - f : f
        case "ripple":
            let rad2 = f * hypot(W, H) / 2
            let s = o ? 1 : 1.2 - 0.2 * f
            r.sx = s; r.sy = s
            if !o { r.mask = { sz in Path(ellipseIn: CGRect(x: sz.width / 2 - rad2, y: sz.height / 2 - rad2, width: rad2 * 2, height: rad2 * 2)) } }
        case "swing":
            r.sx = max(0.01, o ? cos(hf) : sin(hf))
            r.dx = o ? -(1 - r.sx) * W / 2 : (1 - r.sx) * W / 2
        case "blinds", "vblinds":
            if !o {
                let vert = ty == "vblinds"
                r.mask = { sz in
                    var p = Path()
                    let n = 8
                    for i in 0..<n {
                        if vert {
                            let cw = sz.width / CGFloat(n)
                            p.addRect(CGRect(x: cw * CGFloat(i), y: 0, width: cw * CGFloat(f), height: sz.height))
                        } else {
                            let ch = sz.height / CGFloat(n)
                            p.addRect(CGRect(x: 0, y: ch * CGFloat(i), width: sz.width, height: ch * CGFloat(f)))
                        }
                    }
                    return p
                }
            }
        case "checker":
            if !o {
                r.mask = { sz in
                    var p = Path()
                    let cols = 6
                    let rows = max(1, Int((6 * sz.height / sz.width).rounded()))
                    let cw = sz.width / CGFloat(cols), ch = sz.height / CGFloat(rows)
                    for i in 0..<cols {
                        for j in 0..<rows {
                            let k = min(1, max(0, CGFloat(f) * 1.7 - ((i + j) % 2 == 0 ? 0 : 0.7)))
                            let w2 = cw * k, h2 = ch * k
                            p.addRect(CGRect(x: cw * CGFloat(i) + (cw - w2) / 2, y: ch * CGFloat(j) + (ch - h2) / 2, width: w2, height: h2))
                        }
                    }
                    return p
                }
            }
        case "clock":
            if !o {
                r.mask = { sz in
                    var p = Path()
                    let c = CGPoint(x: sz.width / 2, y: sz.height / 2)
                    p.move(to: c)
                    p.addArc(center: c, radius: hypot(sz.width, sz.height), startAngle: .degrees(-90), endAngle: .degrees(-90 + 360 * f), clockwise: false)
                    p.closeSubpath()
                    return p
                }
            }
        case "cross":
            if !o {
                r.mask = { sz in
                    var p = Path()
                    let k = CGFloat(f)
                    p.addRect(CGRect(x: 0, y: sz.height * (1 - k) / 2, width: sz.width, height: sz.height * k))
                    p.addRect(CGRect(x: sz.width * (1 - k) / 2, y: 0, width: sz.width * k, height: sz.height))
                    return p
                }
            }
        case "heart":
            if !o {
                let k = f * hypot(W, H) / 40
                r.mask = { sz in
                    var p = Path()
                    p.move(to: CGPoint(x: 0, y: 40))
                    p.addCurve(to: CGPoint(x: -45, y: -10), control1: CGPoint(x: -20, y: 25), control2: CGPoint(x: -45, y: 10))
                    p.addCurve(to: CGPoint(x: 0, y: -20), control1: CGPoint(x: -45, y: -40), control2: CGPoint(x: -10, y: -40))
                    p.addCurve(to: CGPoint(x: 45, y: -10), control1: CGPoint(x: 10, y: -40), control2: CGPoint(x: 45, y: -40))
                    p.addCurve(to: CGPoint(x: 0, y: 40), control1: CGPoint(x: 45, y: 10), control2: CGPoint(x: 20, y: 25))
                    p.closeSubpath()
                    return p.applying(CGAffineTransform(scaleX: CGFloat(k), y: CGFloat(k)).concatenating(CGAffineTransform(translationX: sz.width / 2, y: sz.height / 2)))
                }
            }
        case "star":
            if !o {
                let big = f * hypot(W, H) * 0.65
                r.mask = { sz in
                    var p = Path()
                    for i in 0..<10 {
                        let a = Double(i) * Double.pi / 5 - Double.pi / 2
                        let rr = i % 2 == 0 ? big : big * 0.42
                        let pt = CGPoint(x: Double(sz.width) / 2 + rr * cos(a), y: Double(sz.height) / 2 + rr * sin(a))
                        if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
                    }
                    p.closeSubpath()
                    return p
                }
            }
        case "wipediag":
            if !o {
                let d = CGFloat(f * (W + H))
                r.mask = { _ in
                    var p = Path()
                    p.move(to: .zero)
                    p.addLine(to: CGPoint(x: d, y: 0))
                    p.addLine(to: CGPoint(x: 0, y: d))
                    p.closeSubpath()
                    return p
                }
            }
        default: break
        }
        return r
    }
}
