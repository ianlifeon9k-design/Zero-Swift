import SwiftUI
import AVFoundation

/// Offline export: every frame is rendered from the same compositor the preview uses (not in real time),
/// written with AVAssetWriter, then audio from all clips is mixed in.
@MainActor
enum Exporter {
    static func export(project p: ZProject, media: MediaCache, progress: @escaping (Double) -> Void) async throws -> URL {
        let w = p.width - p.width % 2, h = p.height - p.height % 2
        let dur = max(0.5, p.clips.map { $0.end }.max() ?? 0)
        let tmp = FileManager.default.temporaryDirectory
        let videoURL = tmp.appendingPathComponent("zero-video-\(UUID().uuidString).mp4")
        let writer = try AVAssetWriter(outputURL: videoURL, fileType: .mp4)
        let bitrate = min(25_000_000, max(2_000_000, w * h * p.fps / 10))
        let settings: [String: Any] = [AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: w, AVVideoHeightKey: h,
                                       AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: bitrate]]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false
        let attrs: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA), kCVPixelBufferWidthKey as String: w, kCVPixelBufferHeightKey as String: h]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attrs)
        writer.add(input)
        guard writer.startWriting() else { throw writer.error ?? NSError(domain: "ZERO", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not start the export."]) }
        writer.startSession(atSourceTime: .zero)
        let n = Int(ceil(dur * Double(p.fps)))
        for i in 0..<n {
            while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 4_000_000) }
            let t = Double(i) / Double(p.fps)
            let renderer = ImageRenderer(content: CompositeView(project: p, t: t, media: media, sync: true))
            renderer.scale = 1
            guard let cg = renderer.cgImage, let pb = pixelBuffer(cg, w, h, adaptor.pixelBufferPool) else { throw NSError(domain: "ZERO", code: 2, userInfo: [NSLocalizedDescriptionKey: "A frame could not be rendered."]) }
            adaptor.append(pb, withPresentationTime: CMTime(value: Int64(i), timescale: Int32(p.fps)))
            if i % 3 == 0 { progress(Double(i) / Double(n) * 0.9); await Task.yield() }
        }
        input.markAsFinished()
        await writer.finishWriting()
        if writer.status != .completed { throw writer.error ?? NSError(domain: "ZERO", code: 3, userInfo: [NSLocalizedDescriptionKey: "Export failed."]) }
        let out = try await addAudio(video: videoURL, project: p, media: media, duration: dur)
        progress(1)
        return out
    }

    private static func pixelBuffer(_ img: CGImage, _ w: Int, _ h: Int, _ pool: CVPixelBufferPool?) -> CVPixelBuffer? {
        var pb: CVPixelBuffer?
        if let pool = pool { CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pb) } else { CVPixelBufferCreate(nil, w, h, kCVPixelFormatType_32BGRA, nil, &pb) }
        guard let buf = pb else { return nil }
        CVPixelBufferLockBaseAddress(buf, [])
        defer { CVPixelBufferUnlockBaseAddress(buf, []) }
        let info = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        guard let ctx = CGContext(data: CVPixelBufferGetBaseAddress(buf), width: w, height: h, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(buf), space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: info) else { return nil }
        ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
        return buf
    }

    private static func addAudio(video: URL, project p: ZProject, media: MediaCache, duration: Double) async throws -> URL {
        let sources = ZFlat.leaves(p.clips).filter { ($0.kind == .audio || $0.kind == .video) && !$0.muted && $0.file != nil }
        let comp = AVMutableComposition()
        let vAsset = AVURLAsset(url: video)
        let vDur = try await vAsset.load(.duration)
        guard let vTrack = try await vAsset.loadTracks(withMediaType: .video).first, let compV = comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { return video }
        try compV.insertTimeRange(CMTimeRange(start: .zero, duration: vDur), of: vTrack, at: .zero)
        var params: [AVMutableAudioMixInputParameters] = []
        for c in sources {
            guard let f = c.file else { continue }
            let a = AVURLAsset(url: media.url(f))
            guard let aTrack = try? await a.loadTracks(withMediaType: .audio).first, let ct = comp.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) else { continue }
            let len = CMTime(seconds: c.duration * c.speed, preferredTimescale: 600)
            let at = CMTime(seconds: c.start, preferredTimescale: 600)
            do { try ct.insertTimeRange(CMTimeRange(start: CMTime(seconds: c.srcIn, preferredTimescale: 600), duration: len), of: aTrack, at: at) } catch { continue }
            if c.speed != 1 { ct.scaleTimeRange(CMTimeRange(start: at, duration: len), toDuration: CMTime(seconds: c.duration, preferredTimescale: 600)) }
            let ip = AVMutableAudioMixInputParameters(track: ct)
            let vol = Float(c.volume)
            if c.fadeIn > 0 { ip.setVolumeRamp(fromStartVolume: 0, toEndVolume: vol, timeRange: CMTimeRange(start: at, duration: CMTime(seconds: c.fadeIn, preferredTimescale: 600))) } else { ip.setVolume(vol, at: at) }
            if c.fadeOut > 0 { ip.setVolumeRamp(fromStartVolume: vol, toEndVolume: 0, timeRange: CMTimeRange(start: CMTime(seconds: c.end - c.fadeOut, preferredTimescale: 600), duration: CMTime(seconds: c.fadeOut, preferredTimescale: 600))) }
            params.append(ip)
        }
        if comp.tracks(withMediaType: .audio).isEmpty { return video }
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("ZERO-\(UUID().uuidString).mp4")
        guard let session = AVAssetExportSession(asset: comp, presetName: AVAssetExportPresetHighestQuality) else { return video }
        let mix = AVMutableAudioMix(); mix.inputParameters = params
        session.audioMix = mix
        session.outputURL = out
        session.outputFileType = .mp4
        await withCheckedContinuation { (k: CheckedContinuation<Void, Never>) in session.exportAsynchronously { k.resume() } }
        return session.status == .completed ? out : video
    }
}
