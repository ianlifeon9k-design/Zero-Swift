import SwiftUI

struct FXDef: Identifiable {
    let id: String
    let name: String
    let cat: String
    var def = 50.0
    var lo = 0.0
    var hi = 100.0
    var label = "Amount"
    var color: String? = nil
    var speed = false
}

struct MT { var dx = 0.0, dy = 0.0, rot = 0.0, sx = 1.0, sy = 1.0 }

enum FX {
    // id, name, default color, blend mode (static colour washes: no speed control, colour is customisable)
    static let washes: [(String, String, String, BlendMode)] = [
        ("sepia", "Sepia", "#8a5a2b", .color), ("warm", "Warm", "#ff8a2b", .overlay), ("cool", "Cool", "#2b8aff", .overlay), ("violet", "Violet", "#8b5cf6", .overlay),
        ("sunset", "Sunset", "#ff5e62", .overlay), ("ocean", "Ocean", "#0a84ff", .softLight), ("mint", "Mint", "#2ee6a6", .overlay), ("rose", "Rose", "#ff6fa5", .overlay),
        ("lav", "Lavender", "#b69cff", .softLight), ("ember", "Ember", "#ff3b1f", .overlay), ("ice", "Ice", "#9fe8ff", .softLight), ("toxic", "Toxic", "#9dff00", .overlay),
        ("tealo", "Teal & orange", "#00b3b3", .softLight), ("matrix", "Matrix", "#00ff55", .color), ("dusk", "Dusk", "#6a3df0", .color), ("peach", "Peach", "#ffb199", .softLight),
        ("cine", "Cinematic", "#0f6e8c", .softLight), ("vint", "Vintage", "#d9a05b", .softLight), ("cold", "Cold blue", "#4aa3ff", .overlay), ("wfilm", "Warm film", "#ff9d4d", .softLight),
        ("candy", "Candy", "#ff7ad9", .softLight), ("npink", "Neon pink", "#ff2e93", .color), ("nblue", "Neon blue", "#1f6bff", .color), ("blood", "Blood", "#c1121f", .overlay),
        ("autm", "Autumn", "#e07a2f", .overlay), ("sprg", "Spring", "#7be07b", .softLight), ("midn", "Midnight", "#101840", .multiply), ("sand", "Sandstorm", "#d8b480", .overlay),
        ("frst", "Forest", "#1f6b3a", .softLight), ("pastel", "Pastel", "#ffd1dc", .softLight), ("deep", "Deep sea", "#003b6f", .multiply), ("lava", "Lava", "#ff4d00", .color),
        ("aqua", "Aqua", "#00e5ff", .softLight), ("grape", "Grape", "#6d28d9", .softLight), ("tr", "Tint red", "#ff2a2a", .color), ("tg", "Tint green", "#2aff5a", .color),
        ("tb2", "Tint blue", "#2a5aff", .color), ("ty", "Tint yellow", "#ffe62a", .color), ("tc2", "Tint cyan", "#2affff", .color), ("tm", "Tint magenta", "#ff2aff", .color),
        ("gold", "Golden hour", "#ffb347", .softLight), ("cyber", "Cyberpunk", "#ff2bd6", .overlay), ("over", "Overexpose", "#ffffff", .softLight), ("solid", "Solid color", "#7c3aed", .normal)]

    static let washMap: [String: (String, BlendMode)] = Dictionary(uniqueKeysWithValues: washes.map { ($0.0, ($0.2, $0.3)) })

    private static func d(_ id: String, _ name: String, _ cat: String, _ def: Double = 50, _ hi: Double = 100, _ label: String = "Amount", color: String? = nil, speed: Bool = false) -> FXDef {
        FXDef(id: id, name: name, cat: cat, def: def, hi: hi, label: label, color: color, speed: speed)
    }

    static let others: [FXDef] = [
        d("bw", "Black & white", "Color", 100), d("inv", "Invert", "Color", 100), d("bri", "Brightness", "Color", 25, 60, "Brightness"), d("con", "Contrast", "Color", 30, 100, "Contrast"),
        d("sat", "Saturate", "Color", 50, 150, "Saturation"), d("hue", "Hue shift", "Color", 90, 360, "Degrees"),
        d("blur", "Blur", "Blur", 12, 40, "Radius"), d("bpul", "Blur pulse", "Blur", 14, 40, "Radius", speed: true), d("frost", "Frost", "Blur", 10, 40, "Radius"),
        d("tilt", "Tilt shift", "Blur", 14, 40, "Radius"), d("dbl", "Double vision", "Blur", 40), d("ghost", "Ghost", "Blur", 40, speed: true), d("echo", "Echo", "Blur", 40, speed: true),
        d("mblur", "Motion blur", "Blur", 40), d("zblur", "Zoom blur", "Blur", 40),
        d("glow", "Glow", "Light", 20, 40, "Intensity"), d("bloom", "Bloom", "Light", 40, 100, "Intensity"), d("halo", "Halo", "Light", 60), d("lsw", "Light sweep", "Light", 60, speed: true),
        d("sweep", "Spotlight sweep", "Light", 70, speed: true), d("flash", "Flash pulse", "Light", 60, color: "#ffffff", speed: true), d("strobe", "Strobe", "Light", 50, color: "#ffffff", speed: true),
        d("flk", "Flicker", "Light", 40, speed: true), d("burn", "Film burn", "Light", 50, speed: true), d("vig", "Vignette", "Light", 60, 100, "Darkness"), d("disco", "Disco", "Light", 40, speed: true),
        d("rgb", "RGB split", "Glitch", 14, 60, "Offset"), d("rgbs", "RGB shake", "Glitch", 20, 60, "Offset", speed: true), d("gli", "Glitch slices", "Glitch", 30, speed: true), d("stat", "Static burst", "Glitch", 70, speed: true),
        d("scan", "Scanlines", "Retro", 40), d("rscan", "Red scan", "Retro", 40), d("crt", "CRT", "Retro", 50), d("vhs", "VHS tracking", "Retro", 30, speed: true), d("grain", "Film grain", "Retro", 30, speed: true),
        d("tv", "Noise TV", "Retro", 60, speed: true), d("bars", "Cinema bars", "Retro", 12, 30, "Thickness", color: "#000000"), d("sbars", "Side bars", "Retro", 12, 40, "Thickness", color: "#000000"),
        d("lbp", "Letterbox pulse", "Retro", 14, 30, "Thickness", speed: true), d("frame", "Frame", "Retro", 12, 40, "Thickness", color: "#ffffff"), d("pola", "Polaroid frame", "Retro", 12, 30, "Thickness"),
        d("snow", "Snow", "Weather", 60, 150, "Count", speed: true), d("rain", "Rain", "Weather", 60, 150, "Count", speed: true), d("stars", "Stars", "Weather", 50, 150, "Count", speed: true),
        d("dust", "Dust", "Weather", 40, 120, "Count", speed: true), d("bub", "Bubbles", "Weather", 30, 80, "Count", speed: true), d("fire", "Fireflies", "Weather", 30, 80, "Count", speed: true),
        d("hrt", "Hearts", "Weather", 25, 60, "Count", speed: true), d("conf", "Confetti", "Weather", 60, 150, "Count", speed: true), d("mrain", "Matrix rain", "Weather", 40, 100, "Count", speed: true),
        d("bolt", "Lightning", "Weather", 70, speed: true), d("spark", "Sparkle", "Weather", 60, 150, "Count", speed: true), d("bokeh", "Bokeh", "Weather", 40, 80, "Count", speed: true),
        d("mir", "Mirror", "Distort", 100), d("split4", "Split 4", "Distort", 100), d("tile3", "Tile 3x3", "Distort", 100)]

    // id, name, category, default, max
    static let motions: [(String, String, String, Double, Double)] = [
        ("shake", "Shake", "Shake", 30, 100), ("shx", "Shake X", "Shake", 40, 100), ("shy", "Shake Y", "Shake", 40, 100), ("micro", "Micro shake", "Shake", 40, 100),
        ("punch", "Camera punch", "Shake", 40, 100), ("shz", "Shake zoom", "Shake", 40, 100), ("whip", "Whip shake", "Shake", 40, 100), ("shk2", "Shake hard", "Shake", 40, 100),
        ("rumble", "Rumble", "Shake", 30, 100), ("jit", "Jitter", "Shake", 40, 100), ("eq", "Earthquake", "Shake", 40, 100), ("hand", "Handheld", "Shake", 40, 100), ("bnc", "Bounce", "Shake", 40, 100),
        ("flo", "Float", "Motion", 30, 100), ("bin", "Bounce in", "Motion", 100, 100), ("swirl", "Swirl in", "Motion", 100, 100), ("tick", "Tick rotate", "Motion", 40, 100),
        ("hb2", "Double beat", "Motion", 40, 100), ("str", "Stretch pulse", "Motion", 40, 100), ("zin", "Slow zoom in", "Motion", 30, 100), ("zin2", "Zoom-in intro", "Motion", 100, 100),
        ("zout", "Slow zoom out", "Motion", 30, 100), ("beat", "Heartbeat", "Motion", 40, 100), ("spin", "Spin", "Motion", 90, 360), ("jelly", "Jelly", "Motion", 30, 100),
        ("swing", "Swing", "Motion", 30, 100), ("drift", "Drift", "Motion", 30, 100), ("pop", "Pop in", "Motion", 50, 100), ("stut", "Stutter", "Motion", 40, 100),
        ("orb", "Orbit", "Motion", 40, 100), ("f8", "Figure 8", "Motion", 40, 100), ("pend", "Pendulum", "Motion", 40, 100), ("px", "Pulse X", "Motion", 40, 100),
        ("py", "Pulse Y", "Motion", 40, 100), ("zz", "Zigzag", "Motion", 40, 100), ("elas", "Elastic", "Motion", 40, 100), ("rock", "Rock", "Motion", 30, 100),
        ("hop", "Hop", "Motion", 40, 100), ("roll", "Roll", "Motion", 40, 100), ("pout", "Pop out", "Motion", 40, 100), ("wsw", "Wave sway", "Motion", 40, 100),
        ("sil", "Slide in left", "Motion", 100, 100), ("sir", "Slide in right", "Motion", 100, 100), ("sit", "Slide in top", "Motion", 100, 100), ("sib", "Slide in bottom", "Motion", 100, 100),
        ("squash", "Squash", "Motion", 40, 100), ("flip", "3D flip", "Motion", 50, 200), ("flipv", "3D flip vertical", "Motion", 50, 200)]

    static let all: [FXDef] = {
        var a: [FXDef] = []
        for w in washes { a.append(FXDef(id: w.0, name: w.1, cat: "Color", def: w.0 == "solid" ? 100 : 45, color: w.2)) }
        a += others
        for m in motions { a.append(FXDef(id: m.0, name: m.1, cat: m.2, def: m.3, hi: m.4, speed: true)) }
        return a
    }()
    static let byID: [String: FXDef] = Dictionary(uniqueKeysWithValues: all.map { ($0.id, $0) })
    static let categories: [String] = ["All", "Color", "Light", "Blur", "Shake", "Motion", "Glitch", "Retro", "Weather", "Distort"]
}

enum FXR {
    static func on(_ e: ZEffectInstance, _ lt: Double) -> Bool { lt >= e.start && (e.end <= 0 || lt <= e.end) }
    static func frac(_ v: Double) -> Double { v - floor(v) }

    static func motion(_ id: String, _ a: Double, _ l: Double, _ w: Double, _ h: Double) -> MT? {
        let d57 = 57.2958
        switch id {
        case "shake": return MT(dx: sin(l * 60) * a * w / 1500, dy: cos(l * 47) * a * w / 1500)
        case "shx": return MT(dx: sin(l * 90) * a * w / 700)
        case "shy": return MT(dy: sin(l * 90) * a * w / 700)
        case "micro": return MT(dx: sin(l * 200) * a * w / 3000, dy: cos(l * 170) * a * w / 3000)
        case "punch":
            let s = 1 + a / 300 * exp(-(l.truncatingRemainder(dividingBy: 0.5)) * 10)
            return MT(sx: s, sy: s)
        case "shz":
            let s = 1 + sin(l * 50) * a / 1500
            return MT(dx: sin(l * 70) * a * w / 2000, sx: s, sy: s)
        case "whip": return MT(dx: sin(l * 40) * a * w / 900, rot: sin(l * 20) * a / 300 * d57)
        case "shk2": return MT(dx: sin(l * 140) * a * w / 900, dy: cos(l * 113) * a * w / 900)
        case "rumble": return MT(dx: sin(l * 47) * a * w / 1200, dy: cos(l * 53) * a * w / 1200, rot: sin(l * 31) * a / 2500 * d57)
        case "jit":
            let n = floor(l * 20)
            return MT(dx: sin(n * 12.9) * a * w / 800, dy: cos(n * 78.2) * a * w / 800)
        case "eq": return MT(dy: sin(l * 80) * a * w / 700)
        case "hand": return MT(dx: (sin(l * 3) + sin(l * 7.3)) * a * w / 2400, dy: (cos(l * 2.6) + sin(l * 5.1)) * a * w / 2400)
        case "bnc": return MT(dy: -abs(sin(l * 6)) * a * w / 300)
        case "flo": return MT(dx: sin(l * 1.5) * a * w / 600, dy: sin(l * 2.2) * a * w / 300)
        case "bin":
            let s = l >= 0.7 ? 1 : max(0.01, 1 - exp(-l * 6) * cos(l * 16))
            return MT(sx: s, sy: s)
        case "swirl":
            let k = max(0, 1 - l / 0.8), s = 1 - k * 0.6
            return MT(rot: k * k * a * 0.06 * d57, sx: s, sy: s)
        case "tick": return MT(rot: floor(l * 4) * a)
        case "hb2":
            let p = l.truncatingRemainder(dividingBy: 1)
            let s = 1 + a / 400 * (exp(-abs(p - 0.1) * 30) + exp(-abs(p - 0.3) * 30))
            return MT(sx: s, sy: s)
        case "str": return MT(sx: 1 + sin(l * 5) * a / 300, sy: 1 - sin(l * 5) * a / 400)
        case "zin":
            let s = 1 + l * a / 200
            return MT(sx: s, sy: s)
        case "zin2":
            let s = 1 + pow(max(0, 1 - l / 0.5), 2) * a / 50
            return MT(sx: s, sy: s)
        case "zout":
            let s = max(0.2, 1.5 - l * a / 200)
            return MT(sx: s, sy: s)
        case "beat":
            let s = 1 + a / 400 * pow(abs(sin(l * 3)), 8)
            return MT(sx: s, sy: s)
        case "spin": return MT(rot: l * a)
        case "jelly": return MT(sx: 1 + sin(l * 8) * a / 300, sy: 1 - sin(l * 8) * a / 300)
        case "swing": return MT(rot: sin(l * 3) * a / 200 * d57)
        case "drift": return MT(dx: sin(l) * a * w / 300, dy: cos(l * 0.8) * a * w / 500)
        case "pop":
            let s = max(0.01, l >= 0.4 ? 1 : 1 - pow(1 - l / 0.4, 3) * a / 100)
            return MT(sx: s, sy: s)
        case "stut": return MT(dx: floor(l * 8).truncatingRemainder(dividingBy: 2) * a * w / 400)
        case "orb": return MT(dx: cos(l * 2) * a * w / 300, dy: sin(l * 2) * a * w / 300)
        case "f8": return MT(dx: sin(l * 2) * a * w / 300, dy: sin(l * 4) * a * w / 600)
        case "pend": return MT(rot: sin(l * 2.5) * a / 150 * d57)
        case "px": return MT(sx: 1 + sin(l * 6) * a / 300)
        case "py": return MT(sy: 1 + sin(l * 6) * a / 300)
        case "zz": return MT(dy: (abs((l * 2).truncatingRemainder(dividingBy: 2) - 1) - 0.5) * a * w / 100)
        case "elas":
            let s = 1 + exp(-l * 3) * sin(l * 18) * a / 200
            return MT(sx: s, sy: s)
        case "rock": return MT(rot: sin(l * 4) * a / 250 * d57)
        case "hop": return MT(dy: -abs(sin(l * 5)) * a * w / 200)
        case "roll": return MT(dx: ((l * a / 20).truncatingRemainder(dividingBy: 1.2) - 0.6) * w, rot: l * a / 10 * d57)
        case "pout":
            let s = 1 + exp(-l * 5) * a / 80
            return MT(sx: s, sy: s)
        case "wsw": return MT(dx: sin(l * 2) * a * w / 300, rot: cos(l * 2) * a / 500 * d57)
        case "sil": return MT(dx: -w * pow(max(0, 1 - l / 0.5), 2) * a / 50)
        case "sir": return MT(dx: w * pow(max(0, 1 - l / 0.5), 2) * a / 50)
        case "sit": return MT(dy: -h * pow(max(0, 1 - l / 0.5), 2) * a / 50)
        case "sib": return MT(dy: h * pow(max(0, 1 - l / 0.5), 2) * a / 50)
        case "squash": return MT(sx: 1 + abs(sin(l * 4)) * a / 200, sy: 1 - abs(sin(l * 4)) * a / 250)
        case "flip": return MT(sx: cos(l * a / 20))
        case "flipv": return MT(sy: cos(l * a / 20))
        default: return nil
        }
    }

    private static func halfMask(_ w: Double, _ h: Double) -> some View {
        HStack(spacing: 0) { Color.clear.frame(width: w / 2, height: h); Color.black.frame(width: w / 2, height: h) }.frame(width: w, height: h)
    }

    private static func strip(_ w: Double, _ h: Double, _ y: Double, _ hh: Double) -> some View {
        ZStack(alignment: .top) { Color.clear; Rectangle().frame(height: hh).offset(y: y) }.frame(width: w, height: h)
    }

    static func apply(_ v: AnyView, _ e: ZEffectInstance, _ l: Double, _ size: CGSize) -> AnyView {
        let a = e.amount, t = l * e.speed, w = Double(size.width), h = Double(size.height), u = w / 540
        if let m = motion(e.fx, a, t, w, h) {
            return AnyView(v.scaleEffect(x: m.sx, y: m.sy).rotationEffect(.degrees(m.rot)).offset(x: m.dx, y: m.dy))
        }
        if let wash = FX.washMap[e.fx] {
            let c = Color(hex: e.colorHex ?? wash.0)
            return AnyView(v.compositingGroup().overlay(c.opacity(min(1, a / 100)).blendMode(wash.1)).mask(v))
        }
        switch e.fx {
        case "bw": return AnyView(v.grayscale(min(1, a / 100)))
        case "inv": return AnyView(ZStack { v; v.colorInvert().opacity(min(1, a / 100)) })
        case "bri": return AnyView(v.brightness(a / 100))
        case "con": return AnyView(v.contrast(1 + a / 100))
        case "sat": return AnyView(v.saturation(1 + a / 100))
        case "hue": return AnyView(v.hueRotation(.degrees(a)))
        case "blur": return AnyView(v.blur(radius: a * u))
        case "bpul": return AnyView(v.blur(radius: a * u * (0.5 + 0.5 * sin(t * 3))))
        case "frost": return AnyView(v.blur(radius: a * u).overlay(Color.white.opacity(0.12)))
        case "tilt":
            let g = LinearGradient(stops: [.init(color: .black, location: 0), .init(color: .black, location: 0.3), .init(color: .clear, location: 0.4), .init(color: .clear, location: 0.6), .init(color: .black, location: 0.7), .init(color: .black, location: 1)], startPoint: .top, endPoint: .bottom)
            return AnyView(ZStack { v; v.blur(radius: a * u).mask(g) })
        case "dbl": return AnyView(ZStack { v; v.opacity(0.5).offset(x: a * w / 200) })
        case "ghost": return AnyView(ZStack { v; v.opacity(0.3).offset(y: -a * w / 200 * abs(sin(t * 2))) })
        case "echo": return AnyView(ZStack { v; v.opacity(0.35).offset(x: -a * w / 300 * sin(t * 3)) })
        case "mblur": return AnyView(ZStack { ForEach(Array(-3...3), id: \.self) { i in v.opacity(0.2).offset(x: Double(i) * a * w / 1500) } })
        case "zblur": return AnyView(ZStack { ForEach(Array(1...5), id: \.self) { i in v.opacity(0.16).scaleEffect(1 + Double(i) * a / 1500) }; v })
        case "glow", "bloom": return AnyView(ZStack { v; v.blur(radius: a * u * 0.6).blendMode(.screen).opacity(0.75) }.compositingGroup())
        case "mir":
            return AnyView(ZStack { v; v.scaleEffect(x: -1, y: 1).mask(halfMask(w, h)) })
        case "split4", "tile3":
            let n = e.fx == "split4" ? 2 : 3
            let tile = v.frame(width: w, height: h).scaleEffect(1 / Double(n)).frame(width: w / Double(n), height: h / Double(n))
            return AnyView(VStack(spacing: 0) { ForEach(0..<n, id: \.self) { _ in HStack(spacing: 0) { ForEach(0..<n, id: \.self) { _ in tile } } } })
        case "rgb", "rgbs":
            let dd = e.fx == "rgb" ? a * w / 1000 : a * w / 1000 * (0.5 + 0.5 * abs(sin(t * 25)))
            return AnyView(ZStack { v.colorMultiply(.red).offset(x: -dd); v.colorMultiply(.green).blendMode(.screen); v.colorMultiply(.blue).offset(x: dd).blendMode(.screen) }.compositingGroup())
        case "gli":
            let n = floor(t * 14)
            return AnyView(ZStack {
                v
                ForEach(0..<5, id: \.self) { i in
                    let r1 = abs(sin(n * 12.9 + Double(i) * 78.2)), r2 = abs(sin(n * 4.1 + Double(i) * 37.7))
                    v.offset(x: (r2 - 0.5) * a * w / 100).mask(strip(w, h, r1 * h * 0.9, h * (0.02 + r2 * 0.06)))
                }
            })
        case "stat":
            if sin(t * 7) > 0.6, let o = overlay("tv", a, t, nil, size) { return AnyView(v.overlay(o)) }
            return v
        default:
            if let o = overlay(e.fx, a, t, e.colorHex.map { Color(hex: $0) }, size) { return AnyView(v.overlay(o)) }
            return v
        }
    }

    static func overlay(_ id: String, _ a: Double, _ t: Double, _ col: Color?, _ size: CGSize) -> AnyView? {
        let ids: Set<String> = ["scan", "rscan", "crt", "vhs", "tv", "grain", "bars", "sbars", "lbp", "frame", "pola", "flash", "strobe", "flk", "burn", "vig", "halo", "lsw", "sweep", "snow", "rain", "stars", "dust", "bub", "fire", "hrt", "conf", "mrain", "bolt", "spark", "bokeh", "disco"]
        guard ids.contains(id) else { return nil }
        return AnyView(Canvas { ctx, sz in draw(id, &ctx, sz, a, t, col) }.allowsHitTesting(false))
    }

    static func draw(_ id: String, _ ctx: inout GraphicsContext, _ sz: CGSize, _ a: Double, _ t: Double, _ col: Color?) {
        let w = Double(sz.width), h = Double(sz.height), u = w / 540
        func rect(_ x: Double, _ y: Double, _ ww: Double, _ hh: Double, _ c: Color, _ op: Double) { ctx.fill(Path(CGRect(x: x, y: y, width: ww, height: hh)), with: .color(c.opacity(op))) }
        func dot(_ x: Double, _ y: Double, _ r: Double, _ c: Color, _ op: Double) { ctx.fill(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)), with: .color(c.opacity(op))) }
        func lines(_ c: Color, _ op: Double, _ gap: Double, _ th: Double) { var y = 0.0; while y < h { rect(0, y, w, th, c, op); y += gap } }
        switch id {
        case "scan": lines(.black, a / 150, 4 * u, 2 * u)
        case "rscan": lines(Color(red: 1, green: 0, blue: 0.24), a / 200, 6 * u, 2 * u)
        case "crt": lines(.black, a / 150, 4 * u, 2 * u); draw("vig", &ctx, sz, a, t, nil)
        case "vhs": lines(.black, 0.25, 4 * u, 2 * u); rect(0, frac(t * 0.4) * h, w, h * 0.03, .white, 0.25)
        case "grain", "tv":
            let n = floor(t * 24)
            for i in 0..<500 {
                let x = frac(sin(Double(i) * 12.9898 + n * 78.233) * 43758.5453) * w, y = frac(sin(Double(i) * 78.233 + n * 12.9898) * 24634.6345) * h
                rect(x, y, 2 * u, 2 * u, i % 2 == 0 ? .white : .black, min(1, a / (id == "tv" ? 90 : 220)))
            }
        case "bars": let b = h * a / 100; rect(0, 0, w, b, col ?? .black, 1); rect(0, h - b, w, b, col ?? .black, 1)
        case "sbars": let b = w * a / 100; rect(0, 0, b, h, col ?? .black, 1); rect(w - b, 0, b, h, col ?? .black, 1)
        case "lbp": let b = h * a / 100 * (0.5 + 0.5 * sin(t * 3)); rect(0, 0, w, b, .black, 1); rect(0, h - b, w, b, .black, 1)
        case "frame":
            let b = a * w / 500
            ctx.stroke(Path(CGRect(x: b / 2, y: b / 2, width: w - b, height: h - b)), with: .color(col ?? .white), lineWidth: b)
        case "pola":
            let b = a * w / 400, c = Color(red: 0.96, green: 0.95, blue: 0.92)
            rect(0, 0, w, b, c, 1); rect(0, 0, b, h, c, 1); rect(w - b, 0, b, h, c, 1); rect(0, h - b * 3.2, w, b * 3.2, c, 1)
        case "flash": rect(0, 0, w, h, col ?? .white, a / 100 * max(0, 1 - t.truncatingRemainder(dividingBy: 1) * 3))
        case "strobe": rect(0, 0, w, h, col ?? .white, sin(t * 50) > 0 ? a / 100 : 0)
        case "flk": rect(0, 0, w, h, .black, abs(sin(t * 40)) * a / 100)
        case "burn":
            ctx.blendMode = .screen
            rect(0, 0, w, h, Color(red: 1, green: (100 + sin(t * 9) * 50) / 255, blue: 0.08), a / 100 * abs(sin(t * 5)))
        case "vig":
            ctx.fill(Path(CGRect(x: 0, y: 0, width: w, height: h)), with: .radialGradient(Gradient(colors: [.clear, Color.black.opacity(a / 100)]), center: CGPoint(x: w / 2, y: h / 2), startRadius: min(w, h) * 0.3, endRadius: max(w, h) * 0.75))
        case "halo":
            ctx.blendMode = .screen
            ctx.fill(Path(CGRect(x: 0, y: 0, width: w, height: h)), with: .radialGradient(Gradient(colors: [Color.white.opacity(a / 100), .clear]), center: CGPoint(x: w / 2, y: h / 2), startRadius: 0, endRadius: w * 0.7))
        case "lsw":
            ctx.blendMode = .screen
            let x = (frac(t * 0.6 / 1.6) * 1.6 - 0.3) * w
            ctx.fill(Path(CGRect(x: 0, y: 0, width: w, height: h)), with: .linearGradient(Gradient(colors: [.clear, Color.white.opacity(a / 100), .clear]), startPoint: CGPoint(x: x - w * 0.2, y: 0), endPoint: CGPoint(x: x + w * 0.2, y: h * 0.4)))
        case "sweep":
            let x = w * (0.5 + 0.3 * sin(t * 2))
            ctx.fill(Path(CGRect(x: 0, y: 0, width: w, height: h)), with: .radialGradient(Gradient(colors: [.clear, Color.black.opacity(a / 100)]), center: CGPoint(x: x, y: h / 2), startRadius: w * 0.1, endRadius: w * 0.65))
        case "snow":
            for i in 0..<Int(a * 2) {
                let fi = Double(i)
                let x = (sin(fi * 12.9) * 0.5 + 0.5) * w + sin(t * 2 + fi) * 20, y = ((cos(fi * 7.3) * 0.5 + 0.5) * h + t * 60 * (0.5 + Double(i % 3) * 0.3) * u).truncatingRemainder(dividingBy: h)
                dot(x, y, (1 + Double(i % 3)) * u, .white, 0.85)
            }
        case "rain":
            for i in 0..<Int(a * 2) {
                let fi = Double(i)
                let x = (sin(fi * 12.9) * 0.5 + 0.5) * w, y = ((cos(fi * 7.3) * 0.5 + 0.5) * h + t * 900 * u).truncatingRemainder(dividingBy: h)
                var p = Path(); p.move(to: CGPoint(x: x, y: y)); p.addLine(to: CGPoint(x: x - 6 * u, y: y + 22 * u))
                ctx.stroke(p, with: .color(Color(red: 0.81, green: 0.9, blue: 1).opacity(0.5)), lineWidth: u)
            }
        case "stars":
            for i in 0..<Int(a) {
                let fi = Double(i)
                rect((sin(fi * 43.7) * 0.5 + 0.5) * w, (cos(fi * 19.1) * 0.5 + 0.5) * h, (1 + Double(i % 3)) * u, (1 + Double(i % 3)) * u, .white, 0.4 + 0.6 * abs(sin(t * 2 + fi)))
            }
        case "dust":
            for i in 0..<Int(a) {
                let fi = Double(i)
                dot(((sin(fi * 21.3) * 0.5 + 0.5) * w + t * 8 * Double(i % 5)).truncatingRemainder(dividingBy: w), ((cos(fi * 8.7) * 0.5 + 0.5) * h + t * 5 * Double(i % 4)).truncatingRemainder(dividingBy: h), (1 + Double(i % 3)) * u, .white, 0.35)
            }
        case "bub":
            for i in 0..<Int(a) {
                let fi = Double(i)
                let x = (sin(fi * 31.1) * 0.5 + 0.5) * w + sin(t * 2 + fi) * 10, y = h - ((cos(fi * 17.7) * 0.5 + 0.5) * h + t * 60 * (0.5 + Double(i % 3) * 0.3) * u).truncatingRemainder(dividingBy: h)
                let r = (6 + Double(i % 5) * 5) * u
                ctx.stroke(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)), with: .color(Color.white.opacity(0.7)), lineWidth: w / 300)
            }
        case "fire":
            ctx.blendMode = .screen
            for i in 0..<Int(a) {
                let fi = Double(i)
                dot((sin(fi * 12.3) * 0.5 + 0.5) * w + sin(t + fi) * 30, (cos(fi * 9.1) * 0.5 + 0.5) * h + cos(t * 1.3 + fi) * 30, 5 * u, Color(red: 1, green: 0.96, blue: 0.63), max(0, sin(t * 2 + fi * 2)))
            }
        case "hrt":
            for i in 0..<Int(a) {
                let fi = Double(i)
                let x = (sin(fi * 12.9) * 0.5 + 0.5) * w, y = h - ((cos(fi * 7.3) * 0.5 + 0.5) * h + t * 80 * u).truncatingRemainder(dividingBy: h)
                ctx.draw(Text("♥").font(.system(size: 28 * u)).foregroundColor(Color(red: 1, green: 0.44, blue: 0.65)), at: CGPoint(x: x, y: y))
            }
        case "conf":
            for i in 0..<Int(a) {
                let fi = Double(i)
                let x = (sin(fi * 12.9) * 0.5 + 0.5) * w + sin(t * 3 + fi) * 14 * u, y = ((cos(fi * 7.3) * 0.5 + 0.5) * h + t * 120 * u * (0.6 + Double(i % 4) * 0.3)).truncatingRemainder(dividingBy: h)
                rect(x, y, 8 * u, 4 * u, Color(hue: frac(fi * 47 / 360), saturation: 0.9, brightness: 0.95), 0.9)
            }
        case "mrain":
            let n = max(1, Int(a))
            for i in 0..<n {
                let fi = Double(i)
                let x = fi * w / Double(n), y = ((sin(fi * 9.7) * 0.5 + 0.5) * h + t * 260 * u * (0.5 + Double(i % 3) * 0.4)).truncatingRemainder(dividingBy: h)
                for j in 0..<8 { rect(x, y - Double(j) * 14 * u, 6 * u, 10 * u, Color(red: 0, green: 1, blue: 0.4), 1 - Double(j) / 8) }
            }
        case "bolt":
            let p = sin(t * 9) * sin(t * 3.7)
            if p > 0.85 { rect(0, 0, w, h, .white, min(1, a / 100 * (p - 0.85) * 6)) }
        case "spark":
            ctx.blendMode = .screen
            for i in 0..<Int(a) {
                let fi = Double(i)
                let x = (sin(fi * 91.7) * 0.5 + 0.5) * w, y = (cos(fi * 47.3) * 0.5 + 0.5) * h, op = max(0, sin(t * 4 + fi * 3))
                rect(x - 6 * u, y - u, 12 * u, 2 * u, .white, op); rect(x - u, y - 6 * u, 2 * u, 12 * u, .white, op)
            }
        case "bokeh":
            ctx.blendMode = .screen
            for i in 0..<Int(a) {
                let fi = Double(i)
                dot(((sin(fi * 31.1) * 0.5 + 0.5) * w + t * 10 * Double(i % 4)).truncatingRemainder(dividingBy: w), (cos(fi * 17.7) * 0.5 + 0.5) * h, (12 + Double(i % 5) * 10) * u, .white, 0.12)
            }
        case "disco":
            ctx.blendMode = .overlay
            rect(0, 0, w, h, Color(hue: frac(floor(t * 6) * 67 / 360), saturation: 0.9, brightness: 0.95), a / 100)
        default: break
        }
    }
}
