import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var showNew = false
    @State private var renameID: UUID?
    @State private var draft = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("ZERO").font(.system(size: 30, weight: .black, design: .rounded)).tracking(3)
                        Text("EDIT WITHOUT LIMITS").font(.system(size: 9, weight: .bold)).tracking(2.8).foregroundColor(store.accent)
                    }
                    Spacer()
                }.foregroundColor(.white)
                hero
                tiles
                projectsList
            }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 10)
        }
        .sheet(isPresented: $showNew) { NewProjectSheet().environmentObject(store) }
        .alert("Rename project", isPresented: Binding(get: { renameID != nil }, set: { if !$0 { renameID = nil } })) {
            TextField("Name", text: $draft)
            Button("Save") { if let id = renameID { store.renameProject(id, draft) }; renameID = nil }
            Button("Cancel", role: .cancel) { renameID = nil }
        }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            RoundedRectangle(cornerRadius: CGFloat(store.settings.radius) + 8, style: .continuous)
                .fill(LinearGradient(colors: [store.accent.opacity(0.55), Color.black.opacity(0.4)], startPoint: .topLeading, endPoint: .bottomTrailing))
            VStack(alignment: .leading, spacing: 12) {
                Text("YOUR NEXT MASTERPIECE").font(.caption.bold()).tracking(1.8).foregroundColor(.white.opacity(0.8))
                Text("Make every\nframe matter.").font(.system(size: 33, weight: .bold, design: .rounded))
                Text("Edit video, motion and ideas in one place.").font(.subheadline).foregroundColor(.white.opacity(0.75))
                Button { showNew = true } label: { Label("Create project", systemImage: "plus") }
                    .buttonStyle(ZeroButtonStyle(primary: true, accent: .white)).frame(maxWidth: 220)
            }.padding(22)
        }
        .frame(height: 250)
        .overlay(RoundedRectangle(cornerRadius: CGFloat(store.settings.radius) + 8, style: .continuous).stroke(Color.white.opacity(0.2), lineWidth: 1))
    }

    private var tiles: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            tile("Studio", "Edit video & motion", "slider.horizontal.3") { if store.currentID == nil { showNew = true } else { store.section = .studio } }
            tile("3D", "Shapes & scenes", "cube.transparent") { store.section = .dimension }
            tile("Music", "Songs & playlists", "waveform") { store.section = .music }
            tile("Messages", "Chat (interface)", "bubble.left.and.bubble.right") { store.section = .chat }
            tile("Profile", "Banner, bio, status", "person.crop.circle") { store.section = .profile }
            tile("Settings", "Themes & customization", "gearshape") { store.section = .settings }
        }
    }

    private func tile(_ title: String, _ sub: String, _ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: icon).font(.system(size: 21, weight: .semibold)).foregroundColor(store.accent)
                    .frame(width: 42, height: 42).background(store.accent.opacity(0.15), in: RoundedRectangle(cornerRadius: 13))
                Text(title).font(.headline).foregroundColor(.white)
                Text(sub).font(.caption).foregroundColor(.zeroMuted)
            }.frame(maxWidth: .infinity, alignment: .leading)
        }.buttonStyle(TileStyle(radius: CGFloat(store.settings.radius), glass: store.settings.glass))
    }

    private var projectsList: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Recent projects").font(.title3.bold())
            if store.projects.isEmpty {
                GlassCard { Text("No projects yet. Tap Create project to start.").font(.subheadline).foregroundColor(.zeroMuted) }
            }
            ForEach(store.projects) { p in
                HStack(spacing: 8) {
                    Button { store.openProject(p.id) } label: {
                        HStack(spacing: 12) {
                            RoundedRectangle(cornerRadius: 14).fill(LinearGradient(colors: [store.accent.opacity(0.8), .black], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 58, height: 58).overlay(Image(systemName: "play.rectangle.fill").font(.title3))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(p.name).font(.headline).foregroundColor(.white)
                                Text("\(p.ratio) · \(p.width)×\(p.height) · \(p.fps)fps · \(p.clips.count) clips").font(.caption).foregroundColor(.zeroMuted)
                                Text(p.modified.formatted(date: .abbreviated, time: .shortened)).font(.caption2).foregroundColor(.zeroMuted)
                            }
                            Spacer()
                        }
                    }.buttonStyle(.plain)
                    Menu {
                        Button("Rename") { draft = p.name; renameID = p.id }
                        Button("Duplicate") { store.duplicateProject(p.id) }
                        Button("Delete", role: .destructive) { store.deleteProject(p.id) }
                    } label: { Image(systemName: "ellipsis").font(.headline).frame(width: 36, height: 36).foregroundColor(.white) }
                }
                .padding(12)
                .background(Color.white.opacity(store.settings.glass), in: RoundedRectangle(cornerRadius: CGFloat(store.settings.radius), style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: CGFloat(store.settings.radius), style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
            }
        }
    }
}

struct TileStyle: ButtonStyle {
    var radius: CGFloat
    var glass: Double
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.padding(14)
            .background(Color.white.opacity(glass), in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct NewProjectSheet: View {
    @EnvironmentObject var store: ZEROStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = "Untitled project"
    @State private var ratio = "9:16"
    @State private var res = "1080p"
    @State private var fps = "30"

    var body: some View {
        ZStack {
            ThemeBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("New project").font(.title.bold())
                    TextField("Project name", text: $name).padding(12).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                    label("Frame"); SlidingPicker(options: ["9:16", "16:9", "1:1", "4:5"], selection: $ratio)
                    label("Resolution"); SlidingPicker(options: ["480p", "720p", "1080p"], selection: $res)
                    label("Frame rate"); SlidingPicker(options: ["24", "30", "60"], selection: $fps)
                    Button {
                        store.createProject(name: name, ratio: ratio, res: Int(res.dropLast()) ?? 1080, fps: Int(fps) ?? 30)
                        dismiss()
                    } label: { Label("Create project", systemImage: "plus").frame(maxWidth: .infinity) }
                        .buttonStyle(ZeroButtonStyle(primary: true, accent: store.accent)).padding(.top, 6)
                }.padding(20)
            }
        }
    }
    private func label(_ t: String) -> some View { Text(t.uppercased()).font(.caption.bold()).tracking(1.4).foregroundColor(.zeroMuted) }
}
