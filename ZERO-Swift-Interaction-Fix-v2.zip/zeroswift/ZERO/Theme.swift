import SwiftUI
import UIKit

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        if s.count == 3 { s = s.map { "\($0)\($0)" }.joined() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(red: Double((v >> 16) & 255) / 255, green: Double((v >> 8) & 255) / 255, blue: Double(v & 255) / 255)
    }
    var hex: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
    static let zeroBackground = Color(red: 0.035, green: 0.033, blue: 0.05)
    static let zeroPanel = Color.white.opacity(0.065)
    static let zeroLine = Color.white.opacity(0.13)
    static let zeroMuted = Color(red: 0.63, green: 0.61, blue: 0.69)
}

struct ThemePreset: Identifiable { let name: String; let accent: String; let bg: String; var id: String { name } }

enum Themes {
    static let presets: [ThemePreset] = [
        ThemePreset(name: "Violet", accent: "#A78BFA", bg: "#09090C"), ThemePreset(name: "Ocean", accent: "#38BDF8", bg: "#060D18"),
        ThemePreset(name: "Sunset", accent: "#FB923C", bg: "#140A08"), ThemePreset(name: "Mint", accent: "#34D399", bg: "#06120D"),
        ThemePreset(name: "Rose", accent: "#FB7185", bg: "#14080C"), ThemePreset(name: "Neon", accent: "#E879F9", bg: "#0A0614"),
        ThemePreset(name: "Gold", accent: "#FACC15", bg: "#100D04"), ThemePreset(name: "Ice", accent: "#7DD3FC", bg: "#05101A"),
        ThemePreset(name: "Mono", accent: "#E5E7EB", bg: "#050505"), ThemePreset(name: "Aurora", accent: "#34D399", bg: "#04121A"),
        ThemePreset(name: "Lava", accent: "#F97316", bg: "#180604"), ThemePreset(name: "Forest", accent: "#4ADE80", bg: "#050F08"),
        ThemePreset(name: "Candy", accent: "#F472B6", bg: "#14061A"), ThemePreset(name: "Midnight", accent: "#818CF8", bg: "#04051A"),
        ThemePreset(name: "Sakura", accent: "#FDA4AF", bg: "#160A0E"), ThemePreset(name: "Cyber", accent: "#22D3EE", bg: "#050816"),
        ThemePreset(name: "Graphite", accent: "#94A3B8", bg: "#0B0D10"), ThemePreset(name: "Sunrise", accent: "#FBBF24", bg: "#160A02"),
        ThemePreset(name: "Deep sea", accent: "#06B6D4", bg: "#02101A"), ThemePreset(name: "Grape", accent: "#A855F7", bg: "#0D0518"),
        ThemePreset(name: "Mocha", accent: "#D6A77A", bg: "#120C08"), ThemePreset(name: "Ruby", accent: "#F43F5E", bg: "#12050A"),
        ThemePreset(name: "Emerald", accent: "#10B981", bg: "#04120D"), ThemePreset(name: "Orchid", accent: "#D946EF", bg: "#10051A")]
    static let bgStyles = ["glow", "mesh", "aurora", "spot", "dots", "grid", "plain"]
    static let bannerGradients: [[String]] = [["#7C3AED", "#1E1B4B"], ["#0EA5E9", "#0B1020"], ["#F97316", "#3B0A0A"], ["#10B981", "#04201A"], ["#EC4899", "#2A0A24"], ["#FACC15", "#2B1B02"], ["#6366F1", "#0A0A1F"], ["#94A3B8", "#0B0D10"]]
}

struct ThemeBackground: View {
    @EnvironmentObject var store: ZEROStore
    var body: some View {
        let s = store.settings
        let a = Color(hex: s.accentHex), b = Color(hex: s.accent2Hex)
        ZStack {
            Color(hex: s.bgHex)
            switch s.bgStyle {
            case "mesh":
                RadialGradient(colors: [a.opacity(0.35), .clear], center: .topLeading, startRadius: 0, endRadius: 380)
                RadialGradient(colors: [b.opacity(0.25), .clear], center: .topTrailing, startRadius: 0, endRadius: 360)
                RadialGradient(colors: [a.opacity(0.3), .clear], center: .bottom, startRadius: 0, endRadius: 420)
            case "aurora":
                LinearGradient(colors: [a.opacity(0.35), .clear], startPoint: .topLeading, endPoint: .center)
                LinearGradient(colors: [b.opacity(0.28), .clear], startPoint: .bottomTrailing, endPoint: .center)
            case "spot":
                RadialGradient(colors: [a.opacity(0.4), .clear], center: .top, startRadius: 0, endRadius: 460)
            case "dots":
                DotGrid(line: false)
                RadialGradient(colors: [a.opacity(0.3), .clear], center: .top, startRadius: 0, endRadius: 420)
            case "grid":
                DotGrid(line: true)
                RadialGradient(colors: [a.opacity(0.3), .clear], center: .top, startRadius: 0, endRadius: 420)
            case "plain":
                Color.clear
            default:
                RadialGradient(colors: [a.opacity(0.3), .clear], center: .topLeading, startRadius: 0, endRadius: 420)
                RadialGradient(colors: [b.opacity(0.2), .clear], center: .bottomTrailing, startRadius: 0, endRadius: 380)
            }
        }.ignoresSafeArea()
    }
}

struct DotGrid: View {
    let line: Bool
    var body: some View {
        Canvas { ctx, size in
            var x: CGFloat = 0
            while x < size.width {
                var y: CGFloat = 0
                while y < size.height {
                    if line {
                        ctx.fill(Path(CGRect(x: x, y: 0, width: 0.5, height: size.height)), with: .color(.white.opacity(0.05)))
                        ctx.fill(Path(CGRect(x: 0, y: y, width: size.width, height: 0.5)), with: .color(.white.opacity(0.05)))
                    } else {
                        ctx.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 1.6, height: 1.6)), with: .color(.white.opacity(0.09)))
                    }
                    y += 26
                }
                x += 26
            }
        }
    }
}

struct GlassCard<Content: View>: View {
    @EnvironmentObject private var store: ZEROStore
    @ViewBuilder var content: Content
    var body: some View {
        let r = CGFloat(store.settings.radius)
        content.padding(16).frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: r, style: .continuous).fill(Color.white.opacity(store.settings.glass)))
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: r, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: r, style: .continuous).stroke(Color.zeroLine, lineWidth: 1))
    }
}

struct ZeroButtonStyle: ButtonStyle {
    var primary = false
    var accent: Color = Color(red: 0.65, green: 0.53, blue: 0.98)
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.system(size: 15, weight: .semibold, design: .rounded))
            .foregroundColor(primary ? Color.black.opacity(0.85) : .white)
            .padding(.horizontal, 16).frame(minHeight: 46)
            .background(primary ? accent : Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.white.opacity(primary ? 0.24 : 0.13), lineWidth: 1))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

/// Segmented control with a sliding thumb.
struct SlidingPicker: View {
    let options: [String]
    @Binding var selection: String
    @Namespace private var ns
    var body: some View {
        HStack(spacing: 4) {
            ForEach(options, id: \.self) { o in
                Text(o).font(.system(size: 13, weight: .semibold)).frame(maxWidth: .infinity).padding(.vertical, 10)
                    .foregroundColor(selection == o ? .white : .zeroMuted)
                    .background {
                        if selection == o { RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.16)).matchedGeometryEffect(id: "thumb", in: ns) }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { withAnimation(.spring(response: 0.35, dampingFraction: 0.78)) { selection = o } }
            }
        }.padding(4).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct Chip: View {
    let title: String
    let active: Bool
    let accent: Color
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title).font(.caption.bold()).padding(.horizontal, 12).padding(.vertical, 8)
                .foregroundColor(active ? .black.opacity(0.85) : .white)
                .background(active ? accent : Color.white.opacity(0.08), in: Capsule())
        }.buttonStyle(.plain)
    }
}
