import SwiftUI
import PhotosUI

struct NumRow: View {
    @EnvironmentObject var store: ZEROStore
    let title: String
    let value: Double
    let range: ClosedRange<Double>
    let onChange: (Double) -> Void
    var body: some View {
        VStack(spacing: 2) {
            HStack {
                Text(title).font(.subheadline)
                Spacer()
                Text(String(format: "%.2f", value)).font(.caption.monospacedDigit()).foregroundColor(.zeroMuted)
            }
            Slider(value: Binding(get: { min(max(value, range.lowerBound), range.upperBound) }, set: { onChange($0) }), in: range, onEditingChanged: { if $0 { store.pushUndo() } }).tint(store.accent)
        }
    }
}

/// Slider that can hold keyframes (diamond button).
struct PropRow: View {
    @EnvironmentObject var store: ZEROStore
    let title: String
    let prop: String
    let range: ClosedRange<Double>
    var body: some View {
        if let c = store.selectedClip {
            let lt = max(0, min(c.duration, store.playhead - c.start))
            let val = c.value(prop, at: lt)
            VStack(spacing: 2) {
                HStack {
                    Text(title).font(.subheadline)
                    Spacer()
                    Text(String(format: "%.1f", val)).font(.caption.monospacedDigit()).foregroundColor(.zeroMuted)
                    Button { store.toggleKey(prop) } label: {
                        Image(systemName: c.hasKey(prop, at: lt) ? "diamond.fill" : "diamond").foregroundColor(store.accent)
                    }
                }
                Slider(value: Binding(get: { min(max(val, range.lowerBound), range.upperBound) }, set: { store.setProp(prop, $0) }), in: range, onEditingChanged: { if $0 { store.pushUndo() } }).tint(store.accent)
            }
        }
    }
}

struct EditPanel: View {
    @EnvironmentObject var store: ZEROStore

    var body: some View {
        if let c = store.selectedClip {
            clipForm(c)
        } else {
            GlassCard { Text("Select a clip on the timeline, or add media, text, a null, a camera or a 3D shape.").font(.subheadline).foregroundColor(.zeroMuted) }
        }
    }

    private func up(_ c: ZClip, _ f: @escaping (inout ZClip) -> Void) { store.updateClip(c.id, record: false, f) }

    private func kindName(_ c: ZClip) -> String {
        switch c.kind {
        case .video: return "Video clip"
        case .image: return (c.file?.lowercased().hasSuffix(".gif") ?? false) ? "GIF clip" : "Image clip"
        case .audio: return "Audio clip"
        case .text: return "Text"
        case .effect: return "Effect track"
        case .null: return "Null (invisible handle)"
        case .camera: return "Camera"
        case .compound: return "Compound clip"
        case .object3d: return "3D object"
        }
    }

    private func clipForm(_ c: ZClip) -> some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                header(c)
                VStack(alignment: .leading, spacing: 12) {
                    if c.kind != .audio && c.kind != .effect { transformFields(c) }
                    if c.kind == .video || c.kind == .audio { mediaFields(c) }
                    if c.kind == .image || c.kind == .video { fitField(c) }
                    if c.kind == .object3d || c.kind == .image || c.kind == .video { threeDFields(c) }
                    if c.kind == .compound { Text("Compound clip: tap Open in the toolbar to edit what is inside. Effects, transitions, keyframes and parenting work on it like on any clip.").font(.caption).foregroundColor(.zeroMuted) }
                }
                VStack(alignment: .leading, spacing: 12) {
                    if c.kind != .effect && !c.isRig { fadeFields(c) }
                    if c.kind != .audio && c.kind != .effect && !c.isRig { transitionFields(c) }
                    if c.kind == .effect { affects(c) }
                    if c.kind != .audio && c.kind != .effect && c.kind != .camera { parentFields(c) }
                    if c.kind != .audio && !c.isRig {
                        Stepper("Layer \(c.lane)  (0 = main, above = overlay, below = under)", value: Binding(get: { c.lane }, set: { v in up(c) { $0.lane = v } }), in: -6...12).font(.caption)
                    }
                }
            }
        }
    }

    private func header(_ c: ZClip) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(kindName(c)).font(.headline)
            TextField("Name", text: Binding(get: { c.name }, set: { v in up(c) { $0.name = v } }))
                .padding(10).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
            if c.kind == .text { textFields(c) }
            NumRow(title: "Start (s)", value: c.start, range: 0...max(10, store.duration + 5)) { v in up(c) { $0.start = max(0, v) } }
            NumRow(title: "Duration (s)", value: c.duration, range: 0.2...max(10, store.duration + 5)) { v in up(c) { $0.duration = max(0.2, v) } }
        }
    }

    private func textFields(_ c: ZClip) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            TextField("Text", text: Binding(get: { c.text }, set: { v in up(c) { $0.text = v } }), axis: .vertical)
                .lineLimit(1...4).padding(10).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
            NumRow(title: "Size", value: c.fontSize, range: 8...120) { v in up(c) { $0.fontSize = v } }
            ColorPicker("Color", selection: Binding(get: { Color(hex: c.colorHex) }, set: { col in up(c) { $0.colorHex = col.hex } }), supportsOpacity: false)
        }
    }

    private func transformFields(_ c: ZClip) -> some View {
        let cam = c.kind == .camera
        return VStack(alignment: .leading, spacing: 10) {
            Text(cam ? "CAMERA · pans, zooms and rotates the whole scene" : "TRANSFORM · diamond = keyframe at the playhead").font(.system(size: 10, weight: .bold)).foregroundColor(.zeroMuted)
            PropRow(title: cam ? "Pan X" : "Position X", prop: "x", range: -100...100)
            PropRow(title: cam ? "Pan Y" : "Position Y", prop: "y", range: -100...100)
            PropRow(title: cam ? "Zoom" : "Scale", prop: "s", range: 5...400)
            PropRow(title: "Rotation", prop: "r", range: -360...360)
            if !cam && c.kind != .null { PropRow(title: "Opacity", prop: "o", range: 0...100) }
            if c.kind != .null { PropRow(title: cam ? "Camera Z (negative = fly forward)" : "Depth Z (lower = behind)", prop: "z", range: -1000...1000) }
            if cam { Text("Layers the camera flies past disappear, and what was behind them appears. Add Shake effects to this camera to shake the whole scene.").font(.caption).foregroundColor(.zeroMuted) }
            if c.kind == .null { Text("A null is an invisible handle. Pick it as the Parent of other clips to move, rotate and scale them together.").font(.caption).foregroundColor(.zeroMuted) }
        }
    }

    private func mediaFields(_ c: ZClip) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            NumRow(title: "Speed", value: c.speed, range: 0.25...3) { v in up(c) { $0.speed = v } }
            NumRow(title: "Volume", value: c.volume, range: 0...1) { v in up(c) { $0.volume = v } }
            Toggle("Mute", isOn: Binding(get: { c.muted }, set: { v in up(c) { $0.muted = v } })).tint(store.accent)
        }
    }

    private func fitField(_ c: ZClip) -> some View {
        SlidingPicker(options: ["Fit", "Fill"], selection: Binding(get: { c.fit == "fill" ? "Fill" : "Fit" }, set: { v in up(c) { $0.fit = v.lowercased() } }))
    }

    private func threeDFields(_ c: ZClip) -> some View {
        let shapes = ["cube", "sphere", "cone", "torus", "pyramid", "capsule", "cylinder", "tube"]
        return VStack(alignment: .leading, spacing: 10) {
            if c.kind == .image || c.kind == .video {
                Toggle("3D layer (rotate it in 3D, give it thickness)", isOn: Binding(get: { c.d3 }, set: { v in up(c) { $0.d3 = v } })).tint(store.accent)
            }
            if c.kind == .object3d && c.shape != "model" {
                HStack {
                    Text("Shape").font(.subheadline)
                    Spacer()
                    Menu {
                        ForEach(shapes, id: \.self) { s in Button(s.capitalized) { up(c) { $0.shape = s } } }
                    } label: { Text(c.shape.capitalized).font(.subheadline.bold()).foregroundColor(store.accent) }
                }
                SlidingPicker(options: ["Matte", "Glossy", "Metal"], selection: Binding(get: { c.material.capitalized }, set: { v in up(c) { $0.material = v.lowercased() } }))
                Toggle("Wireframe", isOn: Binding(get: { c.wire }, set: { v in up(c) { $0.wire = v } })).tint(store.accent)
            }
            if (c.kind == .object3d && c.shape != "model") || c.d3 {
                ColorPicker(c.kind == .object3d ? "Color" : "Edge color", selection: Binding(get: { Color(hex: c.shapeHex) }, set: { col in up(c) { $0.shapeHex = col.hex } }), supportsOpacity: false)
            }
            if c.d3 { NumRow(title: "Thickness", value: c.thickness, range: 0...2) { v in up(c) { $0.thickness = v } } }
            if c.kind == .object3d || c.d3 {
                PropRow(title: "Rotate X", prop: "rx", range: -360...360)
                PropRow(title: "Rotate Y", prop: "ry", range: -360...360)
                PropRow(title: "Rotate Z", prop: "rz", range: -360...360)
                NumRow(title: "Spin (°/s)", value: c.spin, range: -360...360) { v in up(c) { $0.spin = v } }
            }
        }
    }

    private func fadeFields(_ c: ZClip) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            NumRow(title: "Fade in (s)", value: c.fadeIn, range: 0...5) { v in up(c) { $0.fadeIn = v } }
            NumRow(title: "Fade out (s)", value: c.fadeOut, range: 0...5) { v in up(c) { $0.fadeOut = v } }
        }
    }

    private func transitionFields(_ c: ZClip) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Transition into next clip").font(.subheadline)
                Spacer()
                Menu {
                    Button("None") { store.applyTransition("") }
                    ForEach(Trans.all, id: \.0) { t in Button(t.1) { store.applyTransition(t.0) } }
                } label: { Text(Trans.name(c.transition.type)).font(.subheadline.bold()).foregroundColor(store.accent) }
            }
            if !c.transition.type.isEmpty {
                NumRow(title: "Transition length (s)", value: c.transition.duration, range: 0.2...2) { v in up(c) { $0.transition.duration = v } }
            }
        }
    }

    private func parentFields(_ c: ZClip) -> some View {
        let options = store.parentCandidates(for: c)
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Parent").font(.subheadline)
                Spacer()
                Menu {
                    Button("None") { store.setParent(nil) }
                    ForEach(options) { o in Button(o.name) { store.setParent(o.id) } }
                } label: { Text(options.first(where: { $0.id == c.parent })?.name ?? "None").font(.subheadline.bold()).foregroundColor(store.accent) }
            }
            Toggle("Ignore camera", isOn: Binding(get: { c.ignoreCam }, set: { v in up(c) { $0.ignoreCam = v } })).tint(store.accent)
            Text("A parented clip moves, rotates and scales with its parent. Use a Null as a handle.").font(.caption).foregroundColor(.zeroMuted)
        }
    }

    private func affects(_ c: ZClip) -> some View {
        let below = (store.project?.clips ?? []).filter { $0.kind != .audio && $0.kind != .effect && !$0.isRig && $0.lane < c.lane }
        return VStack(alignment: .leading, spacing: 8) {
            Text("AFFECTS · everything below this track").font(.system(size: 10, weight: .bold)).foregroundColor(.zeroMuted)
            if below.isEmpty { Text("Nothing below this track yet.").font(.caption).foregroundColor(.zeroMuted) }
            ForEach(below) { o in
                Toggle(o.name, isOn: Binding(get: { !c.excluded.contains(o.id) }, set: { on in
                    up(c) { x in if on { x.excluded.removeAll { $0 == o.id } } else if !x.excluded.contains(o.id) { x.excluded.append(o.id) } }
                })).tint(store.accent)
            }
            Text("Add effects in the Effects tab. Tracks above this one are not affected.").font(.caption).foregroundColor(.zeroMuted)
        }
    }
}

struct ThreeDPanel: View {
    @EnvironmentObject var store: ZEROStore
    private let shapes = ["cube", "sphere", "cone", "torus", "pyramid", "capsule", "cylinder", "tube"]
    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Text("3D layers").font(.headline)
                Text("Tap a shape to add it as a 3D layer on the timeline. Select a picture or video and turn on 3D layer in Edit to rotate it in 3D with thickness. Import .usdz, .obj, .scn or .dae models with the Files button. Depth Z, cameras, parenting and keyframes all work on 3D layers.").font(.caption).foregroundColor(.zeroMuted)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    ForEach(shapes, id: \.self) { s in
                        Button { store.add3D(s) } label: {
                            Text(s.capitalized).font(.subheadline.bold()).foregroundColor(.white).frame(maxWidth: .infinity).padding(.vertical, 12)
                                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct MediaPanel: View {
    @EnvironmentObject var store: ZEROStore
    @Binding var showFiles: Bool
    @Binding var photoItems: [PhotosPickerItem]

    var body: some View {
        let files = store.mediaFiles()
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("Media").font(.headline)
                    Spacer()
                    PhotosPicker(selection: $photoItems, maxSelectionCount: 20, matching: .any(of: [.images, .videos])) { Label("Photos", systemImage: "photo") }.buttonStyle(ZeroButtonStyle())
                    Button { showFiles = true } label: { Label("Files", systemImage: "folder") }.buttonStyle(ZeroButtonStyle())
                }
                if files.isEmpty { Text("No media yet. Import video, photos or audio. When your project already has pictures you'll be asked whether to add them on the main timeline or as an overlay.").font(.caption).foregroundColor(.zeroMuted) }
                ForEach(files, id: \.file) { m in
                    HStack {
                        Image(systemName: m.kind == .video ? "film" : (m.kind == .audio ? "waveform" : "photo")).foregroundColor(store.accent)
                        Text(m.name).lineLimit(1)
                        Spacer()
                        Button(role: .destructive) { store.removeMedia(m.file) } label: { Image(systemName: "xmark.circle.fill") }
                    }
                }
            }
        }
    }
}

struct TransitionsPanel: View {
    @EnvironmentObject var store: ZEROStore
    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Text("Transitions").font(.headline)
                Text("Select the first of two clips that touch, then tap a transition. It plays from that clip into the next one.").font(.caption).foregroundColor(.zeroMuted)
                if let c = store.selectedClip, !c.transition.type.isEmpty {
                    HStack {
                        Text("Current: \(Trans.name(c.transition.type))").font(.subheadline.bold())
                        Spacer()
                        Button("Remove") { store.applyTransition("") }.foregroundColor(store.accent)
                    }
                }
                ForEach(Trans.groups, id: \.self) { g in
                    Text(g.uppercased()).font(.system(size: 10, weight: .bold)).tracking(1.4).foregroundColor(.zeroMuted)
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                        ForEach(Trans.all.filter { $0.2 == g }, id: \.0) { t in
                            let on = store.selectedClip?.transition.type == t.0
                            Button { store.applyTransition(t.0) } label: {
                                Text(t.1).font(.subheadline.bold()).foregroundColor(on ? .black : .white).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    .background(on ? store.accent : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }.buttonStyle(.plain).draggable("tr:\(t.0)")
                        }
                    }
                }
            }
        }
    }
}

struct EffectsPanel: View {
    @EnvironmentObject var store: ZEROStore
    @State private var search = ""
    @State private var cat = "All"
    @State private var limit = 40

    private var results: [FXDef] {
        FX.all.filter { (cat == "All" || $0.cat == cat) && (search.isEmpty || $0.name.localizedCaseInsensitiveContains(search)) }
    }

    var body: some View {
        VStack(spacing: 12) {
            if let c = store.selectedClip, !c.effects.isEmpty {
                GlassCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(c.kind == .effect ? "Effects on this layer" : "Applied effects").font(.headline)
                        ForEach(c.effects) { e in EffectRow(clipID: c.id, e: e, dur: c.duration) }
                    }
                }
            }
            GlassCard { library }
        }
    }

    private var library: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Effect library · \(FX.all.count) effects").font(.headline)
            Text("Tap to add to the selected clip. With nothing selected it creates an effect track that affects everything below it. Press, hold and drag an effect onto a clip, or onto a timeline row to make its own effect track there.").font(.caption).foregroundColor(.zeroMuted)
            TextField("Search effects", text: $search).padding(10).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack { ForEach(FX.categories, id: \.self) { c in Chip(title: c, active: cat == c, accent: store.accent) { cat = c; limit = 40 } } }
            }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(Array(results.prefix(limit))) { d in
                    Button { store.addEffect(d.id) } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(d.name).font(.subheadline.bold()).foregroundColor(.white).lineLimit(1)
                            Text(d.cat.uppercased()).font(.system(size: 9, weight: .bold)).foregroundColor(.zeroMuted)
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .draggable("fx:\(d.id)")
                    .contextMenu { Button("Add as effect layer") { store.addEffectLayer(d.id) } }
                }
            }
            if results.count > limit { Button("Show more effects") { limit += 40 }.buttonStyle(ZeroButtonStyle()) }
        }
    }
}

struct EffectRow: View {
    @EnvironmentObject var store: ZEROStore
    let clipID: UUID
    let e: ZEffectInstance
    let dur: Double
    private var d: FXDef? { FX.byID[e.fx] }
    private func up(_ f: @escaping (inout ZEffectInstance) -> Void) {
        store.updateClip(clipID, record: false) { c in
            if let i = c.effects.firstIndex(where: { $0.id == e.id }) { f(&c.effects[i]) }
        }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Toggle("", isOn: Binding(get: { e.enabled }, set: { v in up { $0.enabled = v } })).labelsHidden().tint(store.accent)
                Text(d?.name ?? e.fx).font(.subheadline.bold())
                Spacer()
                Button(role: .destructive) { store.updateClip(clipID) { c in c.effects.removeAll { $0.id == e.id } } } label: { Image(systemName: "trash") }
            }
            NumRow(title: d?.label ?? "Amount", value: e.amount, range: (d?.lo ?? 0)...(d?.hi ?? 100)) { v in up { $0.amount = v } }
            if let col = d?.color {
                ColorPicker("Color", selection: Binding(get: { Color(hex: e.colorHex ?? col) }, set: { c in up { $0.colorHex = c.hex } }), supportsOpacity: false)
            }
            if d?.speed == true { NumRow(title: "Speed", value: e.speed, range: 0.25...4) { v in up { $0.speed = v } } }
            NumRow(title: "Starts at (s)", value: e.start, range: 0...max(1, dur)) { v in up { $0.start = v } }
            NumRow(title: "Ends at (s, 0 = end)", value: e.end, range: 0...max(1, dur)) { v in up { $0.end = v } }
        }
        .padding(10).background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct GraphPanel: View {
    @EnvironmentObject var store: ZEROStore
    @State private var prop = "x"
    @State private var clipboard: ZCurve?
    @State private var active = -1
    @State private var saving = false
    @State private var presetName = ""
    private let names = ["x": "X", "y": "Y", "s": "Scale", "r": "Rotate", "o": "Opacity", "z": "Depth", "rx": "Rot X", "ry": "Rot Y", "rz": "Rot Z"]

    struct Seg { let pr: String; let i: Int; let curve: ZCurve; let f: Double }

    private func currentSegment() -> Seg? {
        guard let c = store.selectedClip else { return nil }
        let props = ["x", "y", "s", "r", "o", "z", "rx", "ry", "rz"].filter { (c.keys[$0]?.count ?? 0) > 1 }
        guard !props.isEmpty else { return nil }
        let pr = props.contains(prop) ? prop : props[0]
        let lt = max(0, min(c.duration, store.playhead - c.start))
        guard let i = c.segment(pr, at: lt), let a = c.keys[pr] else { return nil }
        return Seg(pr: pr, i: i, curve: a[i].curve, f: (lt - a[i].t) / (a[i + 1].t - a[i].t))
    }
    private func apply(_ s: Seg, _ cv: ZCurve) { store.setCurve(s.pr, s.i, cv, record: true) }
    private func pretty(_ id: String) -> String {
        var out = ""
        for ch in id { if ch.isUppercase { out += " " }; out.append(ch) }
        return out.prefix(1).uppercased() + out.dropFirst()
    }
    private func savePreset() {
        guard let s = currentSegment(), !presetName.isEmpty else { return }
        store.settings.savedCurves.append(NamedCurve(name: presetName, curve: s.curve))
        presetName = ""
    }

    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Text("Graph editor").font(.headline)
                if let c = store.selectedClip { content(c) } else { Text("Select a clip with keyframes.").font(.caption).foregroundColor(.zeroMuted) }
            }
        }
        .alert("Save curve preset", isPresented: $saving) {
            TextField("Preset name", text: $presetName)
            Button("Save") { savePreset() }
            Button("Cancel", role: .cancel) {}
        }
    }

    @ViewBuilder private func content(_ c: ZClip) -> some View {
        let props = ["x", "y", "s", "r", "o", "z", "rx", "ry", "rz"].filter { (c.keys[$0]?.count ?? 0) > 1 }
        if props.isEmpty {
            Text("Add two or more keyframes on one property (the Key button, or the diamond next to a slider), then open the graph.").font(.caption).foregroundColor(.zeroMuted)
        } else {
            let pr = props.contains(prop) ? prop : props[0]
            ScrollView(.horizontal, showsIndicators: false) {
                HStack { ForEach(props, id: \.self) { p in Chip(title: names[p] ?? p, active: p == pr, accent: store.accent) { prop = p } } }
            }
            if let s = currentSegment() {
                graph(s)
                controls(s)
                presets(s)
            } else {
                Text("Move the playhead between two \(names[pr] ?? "") keyframes. Only that segment is edited, so other keyframes keep their own curves.").font(.caption).foregroundColor(.zeroMuted)
            }
        }
    }

    private func pick(_ curve: ZCurve, _ s: CGPoint, _ X: (Double) -> CGFloat, _ Y: (Double) -> CGFloat) -> Int {
        var best = 0
        var bd = CGFloat(48)
        var cands: [(Int, Double, Double)] = []
        if curve.kind == "bezier" { cands = [(1, curve.a, curve.b), (2, curve.c, curve.d)] }
        else if Curves.isSpecial(curve.kind) { cands = [(3, curve.a, curve.b)] }
        for (id, x, y) in cands {
            let d = hypot(X(x) - s.x, Y(y) - s.y)
            if d < bd { bd = d; best = id }
        }
        return best
    }

    private func graph(_ s: Seg) -> some View {
        GeometryReader { geo in
            let W = geo.size.width, H = geo.size.height
            let px: CGFloat = 20, pw = W - 40, py: CGFloat = 40, ph = H - 80
            let X: (Double) -> CGFloat = { px + CGFloat($0) * pw }
            let Y: (Double) -> CGFloat = { py + ph * CGFloat(1 - $0) }
            let cv = s.curve
            ZStack {
                Path { p in p.addRect(CGRect(x: px, y: py, width: pw, height: ph)) }.stroke(Color.white.opacity(0.2), lineWidth: 1)
                Path { p in p.move(to: CGPoint(x: X(0), y: Y(0))); p.addLine(to: CGPoint(x: X(1), y: Y(1))) }.stroke(Color.white.opacity(0.12), style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
                Path { p in
                    for k in 0...60 {
                        let x = Double(k) / 60
                        let pt = CGPoint(x: X(x), y: Y(cv.value(x)))
                        if k == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
                    }
                }.stroke(store.accent, lineWidth: 3)
                if cv.kind == "bezier" {
                    Path { p in
                        p.move(to: CGPoint(x: X(0), y: Y(0))); p.addLine(to: CGPoint(x: X(cv.a), y: Y(cv.b)))
                        p.move(to: CGPoint(x: X(1), y: Y(1))); p.addLine(to: CGPoint(x: X(cv.c), y: Y(cv.d)))
                    }.stroke(Color.white.opacity(0.5), lineWidth: 1)
                    Circle().fill(Color.white).frame(width: 22, height: 22).position(x: X(cv.a), y: Y(cv.b))
                    Circle().fill(Color.white).frame(width: 22, height: 22).position(x: X(cv.c), y: Y(cv.d))
                } else if Curves.isSpecial(cv.kind) {
                    Circle().fill(Color.yellow).frame(width: 24, height: 24).position(x: X(cv.a), y: Y(cv.b))
                }
                Circle().fill(Color.cyan).frame(width: 9, height: 9).position(x: X(s.f), y: Y(cv.value(s.f)))
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        if active == -1 { active = pick(cv, v.startLocation, X, Y); store.pushUndo() }
                        guard active > 0 else { return }
                        let nx = min(max(Double((v.location.x - px) / pw), 0), 1)
                        let ny = min(max(Double(1 - (v.location.y - py) / ph), -0.4), 1.4)
                        var n = cv
                        if active == 1 { n.a = nx; n.b = ny } else if active == 2 { n.c = nx; n.d = ny } else { n.a = nx; n.b = min(max(ny, 0), 1) }
                        store.setCurve(s.pr, s.i, n)
                    }
                    .onEnded { _ in active = -1 }
            )
        }.frame(height: 230)
    }

    private func controls(_ s: Seg) -> some View {
        HStack {
            Button { clipboard = s.curve } label: { Label("Copy", systemImage: "doc.on.doc") }.buttonStyle(ZeroButtonStyle())
            Button { if let cb = clipboard { apply(s, cb) } } label: { Label("Paste", systemImage: "doc.on.clipboard") }.buttonStyle(ZeroButtonStyle()).disabled(clipboard == nil)
            Button { apply(s, ZCurve(kind: "bezier", a: 0.25, b: 0.1, c: 0.25, d: 1)) } label: { Text("Bézier") }.buttonStyle(ZeroButtonStyle())
            Button { saving = true } label: { Image(systemName: "star") }.buttonStyle(ZeroButtonStyle())
        }.font(.caption)
    }

    private func presets(_ s: Seg) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("SPECIAL GRAPHS").font(.system(size: 10, weight: .bold)).foregroundColor(.zeroMuted)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(Curves.specials, id: \.0) { sp in
                        Chip(title: sp.1, active: s.curve.kind == sp.0, accent: Color.yellow) { apply(s, ZCurve(kind: sp.0, a: sp.2, b: sp.3)) }
                    }
                }
            }
            if let hint = Curves.specials.first(where: { $0.0 == s.curve.kind })?.4 { Text(hint).font(.caption).foregroundColor(.zeroMuted) }
            if s.curve.kind == "bezier" { Text("Drag the two white handles to shape the curve.").font(.caption).foregroundColor(.zeroMuted) }
            if !store.settings.savedCurves.isEmpty {
                Text("MY PRESETS · hold to delete").font(.system(size: 10, weight: .bold)).foregroundColor(.zeroMuted)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(store.settings.savedCurves) { nc in
                            Chip(title: "★ " + nc.name, active: false, accent: store.accent) { apply(s, nc.curve) }
                                .contextMenu { Button("Delete", role: .destructive) { store.settings.savedCurves.removeAll { $0.id == nc.id } } }
                        }
                    }
                }
            }
            ForEach(Curves.groups, id: \.0) { g in
                Text(g.0.uppercased()).font(.system(size: 10, weight: .bold)).foregroundColor(.zeroMuted)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack { ForEach(g.1, id: \.self) { id in Chip(title: pretty(id), active: s.curve.kind == id, accent: store.accent) { apply(s, ZCurve(kind: id)) } } }
                }
            }
        }
    }
}

struct ExportPanel: View {
    @EnvironmentObject var store: ZEROStore
    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                Text("Export").font(.headline)
                if let p = store.project {
                    Text("\(p.width)×\(p.height) · \(p.fps) fps · \(String(format: "%.1f", store.duration)) s").font(.caption).foregroundColor(.zeroMuted)
                }
                Text("Every frame is rendered one by one (not in real time) with all effects, transitions and keyframes, and the sound from all clips is mixed in.").font(.caption).foregroundColor(.zeroMuted)
                if store.exporting {
                    ProgressView(value: store.exportProgress).tint(store.accent)
                    Text("Rendering… keep the app open").font(.caption)
                }
                Button { store.startExport() } label: { Label("Export video", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }
                    .buttonStyle(ZeroButtonStyle(primary: true, accent: store.accent)).disabled(store.exporting || store.duration <= 0)
                if let url = store.exportURL {
                    ShareLink(item: url) { Label("Share or save video", systemImage: "square.and.arrow.up.on.square").frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle())
                }
            }
        }
    }
}
