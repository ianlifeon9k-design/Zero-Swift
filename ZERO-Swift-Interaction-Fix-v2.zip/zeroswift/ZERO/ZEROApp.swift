import SwiftUI

@main
struct ZEROApp: App {
    @StateObject private var store = ZEROStore()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(store).preferredColorScheme(.dark) }
    }
}
