import SwiftUI
import AVFoundation
import UIKit
import ImageIO

struct ClosureShape: Shape {
    let build: (CGRect) -> Path
    func path(in rect: CGRect) -> Path { build(rect) }
}

/// Loads still images and video frames. Keeps the last frame so the preview never flashes black while a new frame loads.
final class MediaCache: ObservableObject {
    @Published var tick = 0
    static var dir: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Media", isDirectory: true) }
    private var images: [String: UIImage] = [:]
    private var frames: [String: UIImage] = [:]
    private var last: [String: UIImage] = [:]
    private var pending = Set<String>()
    private var gens: [String: AVAssetImageGenerator] = [:]
    private var exactGens: [String: AVAssetImageGenerator] = [:]
    private var gifs: [String: (frames: [UIImage], delays: [Double], total: Double)] = [:]

    func url(_ f: String) -> URL { MediaCache.dir.appendingPathComponent(f) }
    func uiImage(_ f: String) -> UIImage? {
        if let i = images[f] { return i }
        guard let i = UIImage(contentsOfFile: url(f).path) else { return nil }
        images[f] = i
        return i
    }
    func forget(_ f: String) { images[f] = nil; last[f] = nil; gens[f] = nil; exactGens[f] = nil }

    private func makeGen(_ f: String, exact: Bool) -> AVAssetImageGenerator {
        let g = AVAssetImageGenerator(asset: AVURLAsset(url: url(f)))
        g.appliesPreferredTrackTransform = true
        g.maximumSize = exact ? CGSize(width: 1920, height: 1920) : CGSize(width: 720, height: 720)
        if exact { g.requestedTimeToleranceBefore = .zero; g.requestedTimeToleranceAfter = .zero }
        else { g.requestedTimeToleranceBefore = CMTime(value: 1, timescale: 30); g.requestedTimeToleranceAfter = CMTime(value: 1, timescale: 30) }
        return g
    }

    /// Decodes an animated GIF once and keeps its frames and delays.
    func gif(_ f: String) -> (frames: [UIImage], delays: [Double], total: Double)? {
        if let g = gifs[f] { return g }
        guard let src = CGImageSourceCreateWithURL(url(f) as CFURL, nil) else { return nil }
        var frames: [UIImage] = [], delays: [Double] = []
        var total = 0.0
        for i in 0..<min(CGImageSourceGetCount(src), 300) {
            guard let cg = CGImageSourceCreateImageAtIndex(src, i, nil) else { continue }
            var d = 0.1
            if let props = CGImageSourceCopyPropertiesAtIndex(src, i, nil) as? [CFString: Any], let gp = props[kCGImagePropertyGIFDictionary] as? [CFString: Any] {
                d = (gp[kCGImagePropertyGIFUnclampedDelayTime] as? Double) ?? (gp[kCGImagePropertyGIFDelayTime] as? Double) ?? 0.1
                if d < 0.02 { d = 0.1 }
            }
            frames.append(UIImage(cgImage: cg)); delays.append(d); total += d
        }
        guard !frames.isEmpty else { return nil }
        let g = (frames: frames, delays: delays, total: total)
        gifs[f] = g
        return g
    }

    func image(for c: ZClip, at lt: Double, sync: Bool) -> UIImage? {
        guard let f = c.file else { return nil }
        if c.kind == .image {
            if f.lowercased().hasSuffix(".gif"), let g = gif(f) {
                var t = max(0, c.srcIn + lt * c.speed).truncatingRemainder(dividingBy: g.total)
                var i = 0
                while i < g.frames.count - 1 && t >= g.delays[i] { t -= g.delays[i]; i += 1 }
                return g.frames[i]
            }
            return uiImage(f)
        }
        let src = max(0, c.srcIn + lt * c.speed)
        let key = "\(f)#\(Int((src * 30).rounded()))"
        if let i = frames[key] { last[f] = i; return i }
        let time = CMTime(seconds: src, preferredTimescale: 600)
        if sync {
            let g = exactGens[f] ?? makeGen(f, exact: true)
            exactGens[f] = g
            if let cg = try? g.copyCGImage(at: time, actualTime: nil) {
                let ui = UIImage(cgImage: cg)
                frames[key] = ui; last[f] = ui
                if frames.count > 160 { frames.removeAll() }
                return ui
            }
            return last[f]
        }
        if !pending.contains(key) {
            pending.insert(key)
            let g = gens[f] ?? makeGen(f, exact: false)
            gens[f] = g
            g.generateCGImagesAsynchronously(forTimes: [NSValue(time: time)]) { [weak self] _, cg, _, _, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.pending.remove(key)
                    if let cg = cg {
                        let ui = UIImage(cgImage: cg)
                        self.frames[key] = ui; self.last[f] = ui
                        if self.frames.count > 160 { self.frames.removeAll() }
                        self.tick += 1
                    }
                }
            }
        }
        return last[f]
    }
}

struct CompositeView: View {
    let project: ZProject
    let t: Double
    @ObservedObject var media: MediaCache
    var sync = false
    var fast = false
    var body: some View {
        let content = ZStack { Color.black; Compositor.stack(project, t, media, sync) }
            .frame(width: CGFloat(project.width), height: CGFloat(project.height))
            .clipped()
        if fast { content.drawingGroup() } else { content }
    }
}

struct CamState { let clip: ZClip; let props: Props; let lt: Double }

enum Compositor {
    static func active(_ c: ZClip, _ t: Double) -> Bool { t >= c.start && t <= c.end }

    static func trw(_ c: ZClip, _ p: ZProject, _ t: Double) -> (out: Bool, f: Double, type: String)? {
        guard c.kind != .effect, c.kind != .audio, !c.isRig else { return nil }
        func visual(_ o: ZClip) -> Bool { o.kind != .audio && o.kind != .effect && !o.isRig && o.id != c.id && o.lane == c.lane }
        if !c.transition.type.isEmpty, p.clips.contains(where: { visual($0) && abs($0.start - c.end) < 0.06 }) {
            let d = c.transition.duration
            let f = (t - (c.end - d)) / d
            if f >= 0 && f <= 1 { return (true, f, c.transition.type) }
        }
        if let pv = p.clips.first(where: { visual($0) && !$0.transition.type.isEmpty && abs($0.end - c.start) < 0.06 }) {
            let d = pv.transition.duration
            let f = (t - (c.start - d)) / d
            if f >= 0 && f <= 1 { return (false, f, pv.transition.type) }
        }
        return nil
    }

    static func show(_ c: ZClip, _ p: ZProject, _ t: Double) -> Bool { active(c, t) || trw(c, p, t) != nil }

    /// The camera that is active at time t (a later camera wins).
    static func camera(_ p: ZProject, _ t: Double) -> CamState? {
        let cams = p.clips.filter { $0.kind == .camera && active($0, t) }.sorted { $0.start < $1.start }
        guard let c = cams.last else { return nil }
        let lt = max(0, t - c.start)
        return CamState(clip: c, props: c.props(at: lt), lt: lt)
    }

    /// Depth: a layer at Z is seen from a camera at 1000 + camera Z. Closer layers grow, layers the camera has flown past disappear.
    static func depth(_ c: ZClip, _ pr: Props, _ cam: CamState?) -> (scale: Double, hidden: Bool) {
        let cz = (c.ignoreCam ? 0 : (cam?.props.z ?? 0)) + 1000
        return (min(40, 1000 / max(1, cz - pr.z)), pr.z >= cz - 1)
    }

    static func stack(_ p: ZProject, _ t: Double, _ media: MediaCache, _ sync: Bool) -> AnyView {
        let size = CGSize(width: p.width, height: p.height)
        let cam = camera(p, t)
        func zOf(_ c: ZClip) -> Double { c.kind == .effect ? 0 : c.value("z", at: max(0, t - c.start)) }
        let vis = p.clips.filter { $0.kind != .audio && $0.kind != .camera && ($0.kind != .null || !sync) }.sorted { a, b in
            let za = zOf(a), zb = zOf(b)
            if za != zb { return za < zb }
            if a.lane != b.lane { return a.lane < b.lane }
            return a.start < b.start
        }
        var skipped = Set<UUID>()
        for f in vis where f.kind == .effect && active(f, t) {
            for id in f.excluded { if let c = vis.first(where: { $0.id == id }), c.lane < f.lane { skipped.insert(id) } }
        }
        func hidden(_ c: ZClip) -> Bool {
            if c.kind == .effect || c.kind == .null { return false }
            return depth(c, c.props(at: max(0, t - c.start)), cam).hidden
        }
        var acc = AnyView(EmptyView())
        for c in vis {
            if skipped.contains(c.id) { continue }
            if c.kind == .effect {
                guard active(c, t) else { continue }
                acc = effectLayer(acc, c, t, size)
                for id in c.excluded {
                    if let d = vis.first(where: { $0.id == id }), d.lane < c.lane, show(d, p, t), !hidden(d) {
                        let layerView = layer(d, p, t, media, sync, cam)
                        let below = acc
                        acc = AnyView(ZStack { below; layerView })
                    }
                }
            } else if show(c, p, t), !hidden(c) {
                let layerView = layer(c, p, t, media, sync, cam)
                let below = acc
                acc = AnyView(ZStack { below; layerView })
            }
        }
        return acc
    }

    static func effectLayer(_ acc: AnyView, _ c: ZClip, _ t: Double, _ size: CGSize) -> AnyView {
        let lt = max(0, t - c.start)
        var v = AnyView(acc.frame(width: size.width, height: size.height))
        for e in c.effects where e.enabled && FXR.on(e, lt) { v = FXR.apply(v, e, lt, size) }
        return v
    }

    static func three(_ c: ZClip, _ pr: Props, _ lt: Double, _ size: CGSize, _ media: MediaCache, _ tex: UIImage?) -> AnyView {
        if let img = Scene3DCache.shared.image(c, pr, lt, size, media, tex) {
            return AnyView(Image(uiImage: img).resizable().frame(width: size.width, height: size.height))
        }
        return AnyView(Color.clear.frame(width: size.width, height: size.height))
    }

    static func nullMarker(_ sync: Bool, _ size: CGSize) -> AnyView {
        if sync { return AnyView(Color.clear.frame(width: size.width, height: size.height)) }
        return AnyView(Canvas { ctx, sz in
            let r = Double(sz.width) / 30, cx = Double(sz.width) / 2, cy = Double(sz.height) / 2
            var p = Path()
            p.move(to: CGPoint(x: cx - r, y: cy)); p.addLine(to: CGPoint(x: cx + r, y: cy))
            p.move(to: CGPoint(x: cx, y: cy - r)); p.addLine(to: CGPoint(x: cx, y: cy + r))
            p.addEllipse(in: CGRect(x: cx - r * 0.6, y: cy - r * 0.6, width: r * 1.2, height: r * 1.2))
            ctx.stroke(p, with: .color(Color(red: 0.65, green: 0.55, blue: 0.98)), lineWidth: Double(sz.width) / 150)
        }.frame(width: size.width, height: size.height).allowsHitTesting(false))
    }

    static func layer(_ c: ZClip, _ p: ZProject, _ t: Double, _ media: MediaCache, _ sync: Bool, _ cam: CamState?) -> AnyView {
        let size = CGSize(width: p.width, height: p.height)
        let w = Double(p.width), h = Double(p.height)
        let lt = max(0, t - c.start)
        let pr = c.props(at: lt)
        var v: AnyView
        switch c.kind {
        case .image, .video:
            let ui = media.image(for: c, at: lt, sync: sync)
            if c.d3 {
                v = three(c, pr, lt, size, media, ui)
            } else if let ui = ui {
                v = AnyView(Image(uiImage: ui).resizable().aspectRatio(contentMode: c.fit == "fill" ? .fill : .fit).frame(width: size.width, height: size.height).clipped())
            } else { v = AnyView(Color.clear.frame(width: size.width, height: size.height)) }
        case .object3d:
            v = three(c, pr, lt, size, media, nil)
        case .text:
            v = AnyView(Text(c.text).font(.system(size: c.fontSize * w / 360, weight: .heavy, design: .rounded)).foregroundColor(Color(hex: c.colorHex)).multilineTextAlignment(.center).shadow(color: Color.black.opacity(0.5), radius: w / 120).frame(width: size.width, height: size.height))
        case .compound:
            var sp = p
            sp.clips = c.sub
            v = AnyView(stack(sp, lt, media, sync).frame(width: size.width, height: size.height))
        case .null:
            v = nullMarker(sync, size)
        default:
            v = AnyView(Color.clear.frame(width: size.width, height: size.height))
        }
        if c.kind != .null { for e in c.effects where e.enabled && FXR.on(e, lt) { v = FXR.apply(v, e, lt, size) } }
        var fade = 1.0
        if c.fadeIn > 0 { fade = min(fade, lt / c.fadeIn) }
        if c.fadeOut > 0 { fade = min(fade, (c.duration - lt) / c.fadeOut) }
        fade = min(max(fade, 0), 1)
        let tr: TRR? = trw(c, p, t).map { Trans.make($0.type, out: $0.out, $0.f, size) }
        if let m = tr?.mask { v = AnyView(v.clipShape(ClosureShape(build: { r in m(r.size) }))) }
        let zs = c.kind == .null ? 1 : depth(c, pr, cam).scale
        v = AnyView(v.scaleEffect(pr.s / 100 * zs).rotationEffect(.degrees(pr.r)).offset(x: pr.x / 100 * w, y: pr.y / 100 * h).opacity(c.kind == .null ? 1 : pr.o / 100 * fade))
        if let t2 = tr {
            v = AnyView(v.scaleEffect(x: t2.sx, y: t2.sy).rotationEffect(.degrees(t2.rot)).offset(x: t2.dx, y: t2.dy).blur(radius: t2.blur).brightness(t2.flash).opacity(t2.al))
        }
        // Parenting: a child is carried by its parent's position, rotation and scale (and the parent's own parent, and so on).
        var cur = c
        var hops = 0
        while let pid = cur.parent, hops < 6, let par = p.clips.first(where: { $0.id == pid }) {
            let pp = par.props(at: min(max(t - par.start, 0), par.duration))
            v = AnyView(v.scaleEffect(pp.s / 100).rotationEffect(.degrees(pp.r)).offset(x: pp.x / 100 * w, y: pp.y / 100 * h))
            cur = par
            hops += 1
        }
        if let cam = cam, !c.ignoreCam { v = cameraView(v, cam, w, h) }
        return v
    }

    static func cameraView(_ v: AnyView, _ cam: CamState, _ w: Double, _ h: Double) -> AnyView {
        let cp = cam.props
        var out = AnyView(v.offset(x: -cp.x / 100 * w, y: -cp.y / 100 * h).rotationEffect(.degrees(-cp.r)).scaleEffect(cp.s / 100))
        for e in cam.clip.effects where e.enabled && FXR.on(e, cam.lt) {
            if let m = FXR.motion(e.fx, e.amount, cam.lt * e.speed, w, h) {
                out = AnyView(out.scaleEffect(x: m.sx, y: m.sy).rotationEffect(.degrees(m.rot)).offset(x: m.dx, y: m.dy))
            }
        }
        return out
    }
}
