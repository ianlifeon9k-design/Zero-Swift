import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: ZEROStore
    @State private var confirmReset = false

    private func bind<T>(_ kp: WritableKeyPath<AppSettings, T>) -> Binding<T> {
        Binding(get: { store.settings[keyPath: kp] }, set: { store.settings[keyPath: kp] = $0 })
    }
    private func colorBind(_ kp: WritableKeyPath<AppSettings, String>) -> Binding<Color> {
        Binding(get: { Color(hex: store.settings[keyPath: kp]) }, set: { store.settings[keyPath: kp] = $0.hex })
    }
    private func title(_ t: String) -> some View { Text(t.uppercased()).font(.system(size: 11, weight: .bold)).tracking(1.5).foregroundColor(.zeroMuted) }
    private func slider(_ name: String, _ kp: WritableKeyPath<AppSettings, Double>, _ r: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack { Text(name); Spacer(); Text(String(format: "%.2f", store.settings[keyPath: kp])).font(.caption.monospacedDigit()).foregroundColor(.zeroMuted) }
            Slider(value: bind(kp), in: r).tint(store.accent)
        }
    }
    private func mapped(_ kp: WritableKeyPath<AppSettings, String>, _ pairs: [(String, String)]) -> Binding<String> {
        Binding(get: { pairs.first { $0.1 == store.settings[keyPath: kp] }?.0 ?? pairs[0].0 },
                set: { name in if let p = pairs.first(where: { $0.0 == name }) { store.settings[keyPath: kp] = p.1 } })
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Button { store.section = .base } label: { Image(systemName: "chevron.left").padding(10).background(Color.white.opacity(0.08), in: Circle()) }.foregroundColor(.white)
                    Text("Settings").font(.title.bold()); Spacer()
                }
                themes
                colors
                shape
                gestures
                preview
                music
                GlassCard {
                    VStack(alignment: .leading, spacing: 8) {
                        title("Account")
                        Text("Local mode").font(.headline)
                        Text("Google sign-in and cloud accounts need an authentication provider and are not set up yet. Nothing leaves your device.").font(.caption).foregroundColor(.zeroMuted)
                    }
                }
                GlassCard {
                    VStack(alignment: .leading, spacing: 10) {
                        title("Storage")
                        Button { store.settings.onboardingDone = false } label: { Label("Replay onboarding", systemImage: "arrow.counterclockwise").frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle())
                        Button { confirmReset = true } label: { Label("Delete all projects, media and music", systemImage: "trash").frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle())
                        Button { store.settings = AppSettings(onboardingDone: true) } label: { Label("Reset customization", systemImage: "paintbrush").frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle())
                    }
                }
                Text("ZERO · Free. No subscriptions, no Pro tier, no watermarks.").font(.caption).foregroundColor(.zeroMuted).padding(.bottom, 8)
            }.padding(.horizontal, 16).padding(.top, 12)
        }
        .confirmationDialog("Delete all projects, media and music?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Delete everything", role: .destructive) { store.deleteEverything() }
        }
    }

    private var themes: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                title("Themes")
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 72), spacing: 10)], spacing: 10) {
                    ForEach(Themes.presets) { t in
                        let on = store.settings.accentHex.uppercased() == t.accent && store.settings.bgHex.uppercased() == t.bg
                        Button {
                            withAnimation(.easeInOut(duration: 0.3)) { store.settings.accentHex = t.accent; store.settings.bgHex = t.bg }
                        } label: {
                            Text(t.name).font(.system(size: 10, weight: .bold)).foregroundColor(.white).shadow(radius: 2)
                                .frame(maxWidth: .infinity).frame(height: 62, alignment: .bottom).padding(4)
                                .background(LinearGradient(colors: [Color(hex: t.accent), Color(hex: t.bg)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(on ? Color.white : Color.white.opacity(0.2), lineWidth: on ? 2 : 1))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private var colors: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                title("Colors & background")
                ColorPicker("Accent color", selection: colorBind(\.accentHex), supportsOpacity: false)
                ColorPicker("Secondary accent", selection: colorBind(\.accent2Hex), supportsOpacity: false)
                ColorPicker("Background color", selection: colorBind(\.bgHex), supportsOpacity: false)
                Text("Background style").font(.subheadline)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack { ForEach(Themes.bgStyles, id: \.self) { s in Chip(title: s.capitalized, active: store.settings.bgStyle == s, accent: store.accent) { withAnimation { store.settings.bgStyle = s } } } }
                }
            }
        }
    }

    private var shape: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                title("Shape, glass & font")
                slider("Corner roundness", \.radius, 8...40)
                slider("Glass opacity", \.glass, 0.02...0.25)
                Text("Font style").font(.subheadline)
                SlidingPicker(options: ["Rounded", "Default", "Serif", "Mono"], selection: mapped(\.fontDesign, [("Rounded", "rounded"), ("Default", "default"), ("Serif", "serif"), ("Mono", "mono")]))
            }
        }
    }

    private var gestures: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                title("Gestures")
                Toggle("Show my taps and drags", isOn: bind(\.tapShow)).tint(store.accent)
                slider("Tap size", \.tapSize, 24...90)
                ColorPicker("Tap color", selection: colorBind(\.tapHex), supportsOpacity: false)
                SlidingPicker(options: ["Ring", "Fill", "Glow"], selection: mapped(\.tapStyle, [("Ring", "ring"), ("Fill", "fill"), ("Glow", "glow")]))
            }
        }
    }

    private var preview: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                title("Preview quality")
                SlidingPicker(options: ["Auto", "480", "720", "960", "Full"], selection: mapped(\.previewQuality, [("Auto", "auto"), ("480", "480"), ("720", "720"), ("960", "960"), ("Full", "full")]))
                Text("Lower quality plays back more smoothly. Exports are always full quality.").font(.caption).foregroundColor(.zeroMuted)
            }
        }
    }

    private var music: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 10) {
                title("Music")
                Toggle("Pause music while my edit plays, then resume", isOn: bind(\.pauseMusicOnPlay)).tint(store.accent)
                Toggle("Show what I'm listening to on my profile", isOn: bind(\.shareListening)).tint(store.accent)
            }
        }
    }
}
