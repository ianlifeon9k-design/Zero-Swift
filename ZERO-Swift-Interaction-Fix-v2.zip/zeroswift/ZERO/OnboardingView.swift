import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject private var store: ZEROStore
    @State private var page = 0
    @State private var language = "English"
    @State private var selectedReasons: Set<String> = []
    @State private var selectedInterests: Set<String> = []
    @State private var selectedBenefits: Set<String> = []
    private let titles = ["EDIT WITHOUT LIMITS.", "Your language. Your workflow.", "Why ZERO?", "What do you create?", "Creative freedom."]
    private let descriptions = ["One creative space for your ideas.", "Choose how ZERO speaks to you.", "Editing tools without unnecessary limits.", "Football edits, anime, gaming, motion graphics and more.", "Build your style with projects, media and effects together."]
    var body: some View {
        VStack(spacing: 0) {
            HStack { ZMark(size: 42); Text("ZERO").font(.system(size: 16, weight: .black, design: .rounded)).tracking(5); Spacer(); Text("\(page + 1) / 5").font(.caption).foregroundStyle(Color.zeroMuted) }.padding(.horizontal, 24).padding(.top, 18)
            Spacer(minLength: 24)
            VStack(spacing: 20) {
                ZMark(size: page == 0 ? 120 : 82)
                    .shadow(color: store.accent.opacity(0.45), radius: 35)
                Text(titles[page]).font(.system(size: page == 0 ? 29 : 25, weight: .bold, design: .rounded)).multilineTextAlignment(.center)
                Text(descriptions[page]).font(.system(size: 15)).foregroundStyle(Color.zeroMuted).multilineTextAlignment(.center).padding(.horizontal, 24)
                if page == 1 {
                    ForEach(["English", "Português", "Español", "Français"], id: \.self) { item in
                        Button { language = item } label: { HStack { Text(item); Spacer(); if language == item { Image(systemName: "checkmark.circle.fill").foregroundStyle(store.accent) } }.padding(14).background(Color.white.opacity(language == item ? 0.12 : 0.045), in: RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(language == item ? store.accent : Color.zeroLine, lineWidth: 1)) }.buttonStyle(.plain)
                    }
                } else if page == 2 || page == 3 || page == 4 {
                    let options = page == 3 ? ["Football and sports edits", "Anime and gaming", "Motion graphics", "Cinematic videos", "Music videos", "3D animation"] : (page == 2 ? ["Everything in one editing app", "Creative tools that grow with me", "Core tools without paywalls", "Less app switching", "More control over my edits"] : ["Projects and media together", "Effects and transitions", "My own visual style", "Keyframes and graphs", "3D tools"])
                    ForEach(options, id: \.self) { item in
                        let selected = page == 2 ? selectedReasons.contains(item) : (page == 3 ? selectedInterests.contains(item) : selectedBenefits.contains(item))
                        Button {
                            if page == 2 { if selected { selectedReasons.remove(item) } else { selectedReasons.insert(item) } }
                            else if page == 3 { if selected { selectedInterests.remove(item) } else { selectedInterests.insert(item) } }
                            else { if selected { selectedBenefits.remove(item) } else { selectedBenefits.insert(item) } }
                        } label: {
                            HStack(spacing: 10) { Image(systemName: selected ? "checkmark.circle.fill" : "circle").foregroundStyle(selected ? store.accent : Color.zeroMuted); Text(item).font(.system(size: 14)); Spacer() }
                                .padding(12).background(Color.white.opacity(selected ? 0.13 : 0.055), in: RoundedRectangle(cornerRadius: 13)).overlay(RoundedRectangle(cornerRadius: 13).stroke(selected ? store.accent.opacity(0.8) : Color.zeroLine, lineWidth: 1))
                        }.buttonStyle(.plain)
                    }
                    Text("Choose all that apply").font(.system(size: 11)).foregroundStyle(Color.zeroMuted).frame(maxWidth: .infinity, alignment: .leading)
                }
            }.padding(24).frame(maxWidth: 480).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 32)).overlay(RoundedRectangle(cornerRadius: 32).stroke(Color.zeroLine, lineWidth: 1)).padding(.horizontal, 20)
            Spacer(minLength: 24)
            Button { if page < 4 { page += 1 } else { store.language = language; store.finishOnboarding() } } label: { HStack { Text(page == 4 ? "Enter ZERO" : "Continue"); Image(systemName: "arrow.right") }.frame(maxWidth: .infinity) }.buttonStyle(ZeroButtonStyle(primary: true, accent: store.accent)).padding(.horizontal, 24).padding(.bottom, 24)
        }
    }
}

struct ZMark: View {
    var size: CGFloat = 40
    var body: some View {
        ZStack { RoundedRectangle(cornerRadius: size * 0.27).fill(LinearGradient(colors: [Color(red: 0.78, green: 0.69, blue: 1), Color(red: 0.42, green: 0.20, blue: 0.82)], startPoint: .topLeading, endPoint: .bottomTrailing)); RoundedRectangle(cornerRadius: size * 0.27).stroke(.white.opacity(0.42), lineWidth: 1); Text("Z").font(.system(size: size * 0.66, weight: .black, design: .rounded)).foregroundStyle(Color(red: 0.08, green: 0.035, blue: 0.16)) }.frame(width: size, height: size)
    }
}
