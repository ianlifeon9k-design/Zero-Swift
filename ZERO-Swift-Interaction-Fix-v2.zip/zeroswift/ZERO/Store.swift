import SwiftUI
import AVFoundation
import PhotosUI
import UniformTypeIdentifiers

struct MovieFile: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(contentType: .movie) { m in
            SentTransferredFile(m.url)
        } importing: { received in
            try? FileManager.default.createDirectory(at: MediaCache.dir, withIntermediateDirectories: true)
            let dest = MediaCache.dir.appendingPathComponent(UUID().uuidString + "-" + received.file.lastPathComponent)
            try FileManager.default.copyItem(at: received.file, to: dest)
            return MovieFile(url: dest)
        }
    }
}

struct Library: Codable { var songs: [ZSong]; var playlists: [ZPlaylist] }

final class ZEROStore: ObservableObject {
    @Published var settings: AppSettings { didSet { saveSettings() } }
    @Published var projects: [ZProject] = []
    @Published var currentID: UUID?
    @Published var section: ZEROSection = .base
    @Published var selectedID: UUID?
    @Published var playhead = 0.0
    @Published var isPlaying = false
    @Published var zoom = 1.0
    @Published var message: String?
    @Published var pendingPlace: [ZClip] = []
    @Published var songs: [ZSong] = [] { didSet { saveLibrary() } }
    @Published var playlists: [ZPlaylist] = [] { didSet { saveLibrary() } }
    @Published var nowPlaying: UUID?
    @Published var musicPlaying = false
    @Published var exporting = false
    @Published var exportProgress = 0.0
    @Published var exportURL: URL?
    @Published var path: [UUID] = []
    @Published var groupMark: UUID?
    let media = MediaCache()

    private var undoStack: [[ZClip]] = []
    private var redoStack: [[ZClip]] = []
    private var lastTick = Date()
    private var clipPlayers: [UUID: AVPlayer] = [:]
    private var musicPlayer: AVPlayer?
    private var resumeMusic = false
    private var queue: [UUID] = []
    private var saveWork: DispatchWorkItem?
    private var pathPlayheads: [Double] = []

    // MARK: setup
    init() {
        if let d = UserDefaults.standard.data(forKey: "zero.settings.v2"), let s = try? JSONDecoder().decode(AppSettings.self, from: d) { settings = s } else { settings = AppSettings() }
        try? FileManager.default.createDirectory(at: MediaCache.dir, withIntermediateDirectories: true)
        loadAll()
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] n in self?.itemEnded(n) }
    }

    private var docs: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    private var projectsURL: URL { docs.appendingPathComponent("zero-projects-v3.json") }
    private var libraryURL: URL { docs.appendingPathComponent("zero-library-v2.json") }
    private func saveSettings() { if let d = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(d, forKey: "zero.settings.v2") } }
    func saveProjects() { if let d = try? JSONEncoder().encode(projects) { try? d.write(to: projectsURL, options: .atomic) } }
    private func saveLibrary() { if let d = try? JSONEncoder().encode(Library(songs: songs, playlists: playlists)) { try? d.write(to: libraryURL, options: .atomic) } }
    private func loadAll() {
        if let d = try? Data(contentsOf: projectsURL), let v = try? JSONDecoder().decode([ZProject].self, from: d) { projects = v.sorted { $0.modified > $1.modified } }
        if let d = try? Data(contentsOf: libraryURL), let l = try? JSONDecoder().decode(Library.self, from: d) { songs = l.songs; playlists = l.playlists }
    }
    private func scheduleSave() {
        saveWork?.cancel()
        let w = DispatchWorkItem { [weak self] in self?.saveProjects() }
        saveWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: w)
    }

    var accent: Color { Color(hex: settings.accentHex) }
    var language: String { get { settings.language } set { settings.language = newValue } }
    func finishOnboarding() { settings.onboardingDone = true }

    // MARK: projects
    private var idx: Int? { projects.firstIndex { $0.id == currentID } }
    /// The timeline being edited: the whole project, or the inside of a compound clip when `path` is not empty.
    var project: ZProject? {
        guard let i = idx else { return nil }
        var p = projects[i]
        p.clips = levelClips(p.clips, path)
        return p
    }
    var topProject: ZProject? { idx.map { projects[$0] } }
    private func levelClips(_ clips: [ZClip], _ path: [UUID]) -> [ZClip] {
        var cur = clips
        for id in path {
            guard let c = cur.first(where: { $0.id == id }) else { return [] }
            cur = c.sub
        }
        return cur
    }
    private func setLevel(_ clips: inout [ZClip], _ path: [UUID], _ new: [ZClip]) {
        guard let first = path.first else { clips = new; return }
        guard let i = clips.firstIndex(where: { $0.id == first }) else { return }
        setLevel(&clips[i].sub, Array(path.dropFirst()), new)
    }
    var selectedClip: ZClip? { project?.clips.first { $0.id == selectedID } }
    var duration: Double { max(0, project?.clips.map { $0.end }.max() ?? 0) }
    var canUndo: Bool { !undoStack.isEmpty }
    var canRedo: Bool { !redoStack.isEmpty }

    func createProject(name: String, ratio: String, res: Int, fps: Int) {
        let parts = ratio.split(separator: ":").compactMap { Double($0) }
        var w = res, h = res
        if parts.count == 2 {
            if parts[0] <= parts[1] { w = res; h = Int((Double(res) * parts[1] / parts[0]).rounded()) } else { h = res; w = Int((Double(res) * parts[0] / parts[1]).rounded()) }
        }
        w -= w % 2; h -= h % 2
        let p = ZProject(name: name.trimmingCharacters(in: .whitespaces).isEmpty ? "Untitled project" : name, width: w, height: h, fps: fps)
        projects.insert(p, at: 0)
        openProject(p.id)
        saveProjects()
    }
    func openProject(_ id: UUID) {
        stopPlayback(); currentID = id; selectedID = nil; playhead = 0; undoStack = []; redoStack = []; exportURL = nil; path = []; pathPlayheads = []; groupMark = nil; section = .studio
    }
    func renameProject(_ id: UUID, _ name: String) {
        guard let i = projects.firstIndex(where: { $0.id == id }), !name.isEmpty else { return }
        projects[i].name = name; scheduleSave()
    }
    func duplicateProject(_ id: UUID) {
        guard var p = projects.first(where: { $0.id == id }) else { return }
        p.id = UUID(); p.name += " copy"; p.modified = Date()
        projects.insert(p, at: 0); scheduleSave()
    }
    func deleteProject(_ id: UUID) {
        projects.removeAll { $0.id == id }
        if currentID == id { currentID = nil }
        scheduleSave()
    }
    func closeEditor() { stopPlayback(); path = []; pathPlayheads = []; saveProjects(); section = .base }

    func mutate(record: Bool = true, _ f: (inout ZProject) -> Void) {
        guard let i = idx else { return }
        var top = projects[i]
        var lvl = top
        lvl.clips = levelClips(top.clips, path)
        if record { undoStack.append(lvl.clips); redoStack.removeAll(); if undoStack.count > 60 { undoStack.removeFirst() } }
        f(&lvl)
        setLevel(&top.clips, path, lvl.clips)
        top.modified = Date()
        projects[i] = top
        scheduleSave()
    }
    func updateClip(_ id: UUID, record: Bool = true, _ f: (inout ZClip) -> Void) {
        mutate(record: record) { p in
            if let i = p.clips.firstIndex(where: { $0.id == id }) { f(&p.clips[i]) }
        }
    }
    func pushUndo() {
        guard let p = project else { return }
        undoStack.append(p.clips); redoStack.removeAll()
        if undoStack.count > 60 { undoStack.removeFirst() }
    }
    func undo() {
        guard let i = idx, let prev = undoStack.popLast() else { return }
        var top = projects[i]
        redoStack.append(levelClips(top.clips, path))
        setLevel(&top.clips, path, prev)
        projects[i] = top; scheduleSave()
        if selectedClip == nil { selectedID = nil }
    }
    func redo() {
        guard let i = idx, let next = redoStack.popLast() else { return }
        var top = projects[i]
        undoStack.append(levelClips(top.clips, path))
        setLevel(&top.clips, path, next)
        projects[i] = top; scheduleSave()
        if selectedClip == nil { selectedID = nil }
    }

    // MARK: importing and placing media
    private func clipFor(file: String, name: String, kind: ClipKind) -> ZClip {
        var c = ZClip(name: name, kind: kind)
        c.file = file
        if kind == .object3d { c.shape = "model"; c.duration = 4; c.spin = 30; return c }
        if kind == .image {
            c.duration = 4
            if file.lowercased().hasSuffix(".gif"), let g = media.gif(file) { c.duration = max(1, g.total) }
        } else {
            let s = CMTimeGetSeconds(AVURLAsset(url: media.url(file)).duration)
            c.srcDur = s.isFinite && s > 0 ? s : 0
            c.duration = c.srcDur > 0 ? min(c.srcDur, 600) : 5
        }
        return c
    }
    func importURLs(_ urls: [URL]) {
        var made: [ZClip] = []
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            let file = UUID().uuidString + "-" + url.lastPathComponent
            do { try FileManager.default.copyItem(at: url, to: media.url(file)) } catch { message = "Couldn't import \(url.lastPathComponent): \(error.localizedDescription)"; continue }
            let ext = url.pathExtension.lowercased()
            let kind: ClipKind = ["jpg", "jpeg", "png", "heic", "webp", "gif"].contains(ext) ? .image : (["usdz", "obj", "scn", "dae"].contains(ext) ? .object3d : (["mp3", "wav", "m4a", "aac", "aiff", "flac"].contains(ext) ? .audio : .video))
            made.append(clipFor(file: file, name: url.deletingPathExtension().lastPathComponent, kind: kind))
        }
        stage(made)
    }
    func importPhotoItems(_ items: [PhotosPickerItem]) async {
        var made: [ZClip] = []
        for item in items {
            if item.supportedContentTypes.contains(where: { $0.conforms(to: .gif) }), let data = try? await item.loadTransferable(type: Data.self) {
                let f = UUID().uuidString + "-anim.gif"
                try? data.write(to: media.url(f))
                made.append(clipFor(file: f, name: "GIF", kind: .image))
            } else if item.supportedContentTypes.contains(where: { $0.conforms(to: .movie) }), let mv = try? await item.loadTransferable(type: MovieFile.self) {
                made.append(clipFor(file: mv.url.lastPathComponent, name: "Video", kind: .video))
            } else if let data = try? await item.loadTransferable(type: Data.self), let ui = UIImage(data: data), let jpg = ui.jpegData(compressionQuality: 0.92) {
                let f = UUID().uuidString + "-photo.jpg"
                try? jpg.write(to: media.url(f))
                made.append(clipFor(file: f, name: "Photo", kind: .image))
            }
        }
        await MainActor.run { self.stage(made) }
    }
    private func stage(_ clips: [ZClip]) {
        guard !clips.isEmpty, let p = project else { return }
        let hasVisual = p.clips.contains { $0.kind == .video || $0.kind == .image }
        if hasVisual && clips.contains(where: { $0.kind != .audio }) { pendingPlace = clips } else { pendingPlace = clips; place("main") }
    }
    func freeLane(_ p: ZProject, _ s: Double, _ e: Double, dir: Int) -> Int {
        var l = dir
        while p.clips.contains(where: { $0.kind != .audio && $0.lane == l && $0.start < e && $0.end > s }) { l += dir }
        return l
    }
    func place(_ mode: String) {
        let list = pendingPlace
        pendingPlace = []
        guard !list.isEmpty else { return }
        let ph = playhead
        var lastID: UUID?
        mutate { p in
            for var c in list {
                if c.kind == .audio {
                    c.lane = 0
                    c.start = p.clips.filter { $0.kind == .audio }.map { $0.end }.max() ?? 0
                } else if mode == "over" || mode == "under" {
                    c.lane = freeLane(p, ph, ph + c.duration, dir: mode == "over" ? 1 : -1)
                    c.start = ph
                } else {
                    c.lane = 0
                    c.start = p.clips.filter { $0.kind != .audio && $0.lane == 0 }.map { $0.end }.max() ?? 0
                }
                p.clips.append(c)
                lastID = c.id
            }
        }
        selectedID = lastID
        message = "Added to your timeline."
    }
    func mediaFiles() -> [(file: String, name: String, kind: ClipKind)] {
        var seen = Set<String>(), out: [(file: String, name: String, kind: ClipKind)] = []
        for c in ZFlat.leaves(topProject?.clips ?? []) { if let f = c.file, !seen.contains(f) { seen.insert(f); out.append((file: f, name: c.name, kind: c.kind)) } }
        return out
    }
    private func removeFile(_ file: String, _ clips: inout [ZClip]) {
        clips.removeAll { $0.file == file }
        for i in clips.indices { removeFile(file, &clips[i].sub) }
    }
    func removeMedia(_ file: String) {
        guard let i = idx else { return }
        var top = projects[i]
        removeFile(file, &top.clips)
        projects[i] = top; scheduleSave()
        if selectedClip == nil { selectedID = nil }
        message = "Removed from this project (the file stays on your device until the app is deleted)."
    }

    // MARK: editing
    func addText() {
        mutate { p in
            var c = ZClip(name: "Text", kind: .text)
            c.start = playhead
            c.lane = freeLane(p, c.start, c.end, dir: 1)
            c.id = UUID(); selectedID = c.id
            p.clips.append(c)
        }
    }
    func addEffectLayer(_ fx: String) {
        guard let d = FX.byID[fx] else { return }
        mutate { p in
            var c = ZClip(name: d.name, kind: .effect)
            c.start = playhead
            c.lane = (p.clips.filter { $0.kind != .audio }.map { $0.lane }.max() ?? 0) + 1
            c.effects = [ZEffectInstance(fx: fx, amount: d.def, colorHex: d.color)]
            selectedID = c.id
            p.clips.append(c)
        }
        message = "Effect layer added. It affects everything below it."
    }
    func addEffect(_ fx: String) {
        guard let d = FX.byID[fx] else { return }
        if let c = selectedClip, c.kind != .audio, c.kind != .null {
            updateClip(c.id) { $0.effects.append(ZEffectInstance(fx: fx, amount: d.def, colorHex: d.color)) }
        } else { addEffectLayer(fx) }
    }
    func splitSelected() {
        guard let c = selectedClip else { message = "Select a clip first."; return }
        let cut = playhead - c.start
        guard cut > 0.1, cut < c.duration - 0.1 else { message = "Move the playhead inside the selected clip."; return }
        var second = c
        second.id = UUID(); second.start = playhead; second.duration = c.duration - cut; second.srcIn = c.srcIn + cut * c.speed; second.fadeIn = 0
        var firstKeys: [String: [ZKey]] = [:], secondKeys: [String: [ZKey]] = [:]
        for (k, a) in c.keys {
            let f = a.filter { $0.t <= cut }
            var s = a.filter { $0.t >= cut }
            for i in s.indices { s[i].t -= cut }
            if !f.isEmpty { firstKeys[k] = f }
            if !s.isEmpty { secondKeys[k] = s }
        }
        second.keys = secondKeys
        updateClip(c.id) { $0.duration = cut; $0.fadeOut = 0; $0.transition = ZTransition(); $0.keys = firstKeys }
        mutate(record: false) { p in p.clips.append(second) }
        selectedID = second.id
    }
    func duplicateSelected() {
        guard var c = selectedClip else { message = "Select a clip first."; return }
        c.id = UUID(); c.start = c.end
        mutate { p in p.clips.append(c) }
        selectedID = c.id
    }
    func deleteSelected() {
        guard let id = selectedID else { message = "Select a clip first."; return }
        mutate { p in p.clips.removeAll { $0.id == id } }
        selectedID = nil
    }
    func setProp(_ prop: String, _ v: Double) {
        guard let id = selectedID, let c = selectedClip else { return }
        let lt = min(max(playhead - c.start, 0), c.duration)
        updateClip(id, record: false) { c in
            if let ks = c.keys[prop], !ks.isEmpty { c.upsertKey(prop, lt, v) } else { c.setBase(prop, v) }
        }
    }
    func toggleKey(_ prop: String) {
        guard let id = selectedID, let c = selectedClip else { return }
        let lt = min(max(playhead - c.start, 0), c.duration)
        updateClip(id) { c in
            if c.hasKey(prop, at: lt) { c.removeKey(prop, lt) } else { c.upsertKey(prop, lt, c.value(prop, at: lt)) }
        }
    }
    func toggleAllKeys() {
        guard let id = selectedID, let c = selectedClip, c.kind != .audio else { message = "Select a picture or text clip first."; return }
        let lt = min(max(playhead - c.start, 0), c.duration)
        let props = ["x", "y", "s", "r", "o", "z"] + (c.kind == .object3d || c.d3 ? ["rx", "ry", "rz"] : [])
        let has = props.contains { c.hasKey($0, at: lt) }
        updateClip(id) { c in
            for p in props { if has { c.removeKey(p, lt) } else { c.upsertKey(p, lt, c.value(p, at: lt)) } }
        }
        message = has ? "Keyframes removed at this time." : "Keyframes added at the playhead."
    }
    func setCurve(_ prop: String, _ index: Int, _ curve: ZCurve, record: Bool = false) {
        guard let id = selectedID else { return }
        updateClip(id, record: record) { c in
            if var a = c.keys[prop], index < a.count { a[index].curve = curve; c.keys[prop] = a }
        }
    }
    func applyTransition(_ type: String) {
        guard let c = selectedClip, c.kind != .audio, c.kind != .effect, let p = project else { message = "Select the first clip of the pair."; return }
        let hasNext = p.clips.contains { $0.id != c.id && $0.kind != .audio && $0.kind != .effect && $0.lane == c.lane && abs($0.start - c.end) < 0.06 }
        guard hasNext || type.isEmpty else { message = "Place another clip right after this one first."; return }
        updateClip(c.id) { $0.transition = ZTransition(type: type, duration: c.transition.duration) }
    }

    // MARK: rig, compound, 3D, drops
    func addNull() {
        mutate { p in
            var c = ZClip(name: "Null", kind: .null)
            c.start = playhead
            c.duration = max(3, (p.clips.map { $0.end }.max() ?? 0) - playhead)
            selectedID = c.id
            p.clips.append(c)
        }
    }
    func addCamera() {
        mutate { p in
            var c = ZClip(name: "Camera", kind: .camera)
            c.start = 0
            c.duration = max(3, p.clips.map { $0.end }.max() ?? 3)
            selectedID = c.id
            p.clips.append(c)
        }
    }
    func add3D(_ shape: String) {
        mutate { p in
            var c = ZClip(name: shape.capitalized, kind: .object3d)
            c.shape = shape; c.start = playhead; c.spin = 40; c.ry = 20; c.rx = -10
            c.lane = freeLane(p, c.start, c.end, dir: 1)
            selectedID = c.id
            p.clips.append(c)
        }
    }
    func groupTap() {
        guard let c = selectedClip, !c.isRig else { message = "Select a picture, text, 3D, audio or effect clip first."; return }
        guard let mark = groupMark else {
            groupMark = c.id
            message = "Now pick a second clip and tap Group again. Tap Group again on this same clip to wrap only it."
            return
        }
        groupMark = nil
        guard let p = project else { return }
        var set: [ZClip] = [c]
        if mark != c.id, let a = p.clips.first(where: { $0.id == mark }) { set = [a, c] }
        let s = set.map { $0.start }.min() ?? 0
        let e = set.map { $0.end }.max() ?? 1
        let ids = Set(set.map { $0.id })
        let sub = set.map { x -> ZClip in
            var y = x
            y.start -= s
            if let pr = y.parent, !ids.contains(pr) { y.parent = nil }
            return y
        }
        var g = ZClip(name: "Compound", kind: .compound)
        g.start = s; g.duration = max(0.2, e - s); g.lane = set.filter { $0.kind != .audio }.map { $0.lane }.min() ?? 0; g.sub = sub
        mutate { pr in
            pr.clips.removeAll { ids.contains($0.id) }
            pr.clips.append(g)
        }
        selectedID = g.id
        message = "Grouped. Select it and tap Open to edit inside."
    }
    func openCompound() {
        guard let c = selectedClip, c.kind == .compound else { message = "Select a compound clip first."; return }
        stopPlayback()
        pathPlayheads.append(playhead)
        path.append(c.id)
        selectedID = nil; playhead = 0; undoStack = []; redoStack = []
    }
    func closeCompound() {
        guard let id = path.last else { return }
        stopPlayback()
        let inner = duration
        path.removeLast()
        playhead = pathPlayheads.popLast() ?? 0
        selectedID = id; undoStack = []; redoStack = []
        updateClip(id, record: false) { $0.duration = max(0.2, inner) }
    }
    func setParent(_ pid: UUID?) {
        guard let id = selectedID else { return }
        updateClip(id) { $0.parent = pid }
    }
    func parentCandidates(for c: ZClip) -> [ZClip] {
        guard let p = project else { return [] }
        func descends(_ x: ZClip) -> Bool {
            var cur = x
            var n = 0
            while let pid = cur.parent, n < 8 {
                if pid == c.id { return true }
                guard let nx = p.clips.first(where: { $0.id == pid }) else { return false }
                cur = nx; n += 1
            }
            return false
        }
        return p.clips.filter { $0.id != c.id && $0.kind != .audio && $0.kind != .effect && $0.kind != .camera && !descends($0) }
    }
    func dropEffectLayer(_ fx: String, time: Double, aboveLane: Int) {
        guard let d = FX.byID[fx] else { return }
        let base = max(0, aboveLane)
        mutate { p in
            for i in p.clips.indices where p.clips[i].kind != .audio && !p.clips[i].isRig && p.clips[i].lane > base { p.clips[i].lane += 1 }
            var c = ZClip(name: d.name, kind: .effect)
            c.start = max(0, time); c.lane = base + 1
            c.effects = [ZEffectInstance(fx: fx, amount: d.def, colorHex: d.color)]
            selectedID = c.id
            p.clips.append(c)
        }
        message = "Effect track added above this layer. It affects everything below it."
    }
    func handleDrop(_ items: [String], row: Int, time: Double) -> Bool {
        guard let s = items.first else { return false }
        if s.hasPrefix("fx:") {
            if row == -1000 || row == 2000 { message = "Drop effects on a picture layer."; return false }
            dropEffectLayer(String(s.dropFirst(3)), time: time, aboveLane: row)
            return true
        }
        if s.hasPrefix("tr:") { message = "Drop a transition onto a clip."; return false }
        return false
    }
    func handleDropOnClip(_ items: [String], clip id: UUID, rightHalf: Bool) -> Bool {
        guard let s = items.first, let p = project, let c = p.clips.first(where: { $0.id == id }) else { return false }
        if s.hasPrefix("fx:") {
            guard let d = FX.byID[String(s.dropFirst(3))], c.kind != .audio, c.kind != .null else { message = "Effects can't go on this clip."; return false }
            updateClip(id) { $0.effects.append(ZEffectInstance(fx: d.id, amount: d.def, colorHex: d.color)) }
            selectedID = id
            return true
        }
        if s.hasPrefix("tr:") {
            var target = c
            if !rightHalf, let prev = p.clips.first(where: { $0.id != c.id && $0.lane == c.lane && !$0.isRig && $0.kind != .audio && abs($0.end - c.start) < 0.06 }) { target = prev }
            selectedID = target.id
            applyTransition(String(s.dropFirst(3)))
            return true
        }
        return false
    }

    // MARK: playback
    func togglePlay() { if isPlaying { stopPlayback() } else { startPlayback() } }
    func startPlayback() {
        guard duration > 0 else { message = "Add media or text first."; return }
        if playhead >= duration - 0.05 { playhead = 0 }
        if settings.pauseMusicOnPlay && musicPlaying { musicPlayer?.pause(); musicPlaying = false; resumeMusic = true }
        lastTick = Date(); isPlaying = true
    }
    func stopPlayback() {
        isPlaying = false
        clipPlayers.values.forEach { $0.pause() }
        if resumeMusic { resumeMusic = false; musicPlayer?.play(); musicPlaying = musicPlayer != nil }
    }
    func advance() {
        guard isPlaying else { return }
        let now = Date(); let dt = now.timeIntervalSince(lastTick); lastTick = now
        playhead += dt
        if playhead >= duration { playhead = duration; stopPlayback(); return }
        syncAudio()
    }
    private func syncAudio() {
        guard let p = project else { return }
        for c in ZFlat.leaves(p.clips) where (c.kind == .audio || c.kind == .video) && c.file != nil && !c.muted {
            guard let f = c.file else { continue }
            let on = playhead >= c.start && playhead < c.end
            if on {
                let pl = clipPlayers[c.id] ?? AVPlayer(url: media.url(f))
                clipPlayers[c.id] = pl
                let want = c.srcIn + (playhead - c.start) * c.speed
                let lt = playhead - c.start
                var fade = 1.0
                if c.fadeIn > 0 { fade = min(fade, lt / c.fadeIn) }
                if c.fadeOut > 0 { fade = min(fade, (c.duration - lt) / c.fadeOut) }
                pl.volume = Float(c.volume * min(max(fade, 0), 1))
                if pl.rate == 0 {
                    pl.seek(to: CMTime(seconds: want, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
                    pl.rate = Float(c.speed)
                } else if abs(pl.currentTime().seconds - want) > 0.35 {
                    pl.seek(to: CMTime(seconds: want, preferredTimescale: 600))
                }
            } else if let pl = clipPlayers[c.id], pl.rate != 0 { pl.pause() }
        }
    }

    // MARK: music
    func importSongs(_ urls: [URL]) {
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            let file = UUID().uuidString + "-" + url.lastPathComponent
            do { try FileManager.default.copyItem(at: url, to: media.url(file)) } catch { message = error.localizedDescription; continue }
            songs.append(ZSong(name: url.deletingPathExtension().lastPathComponent, file: file))
        }
    }
    func renameSong(_ id: UUID, _ name: String) { if let i = songs.firstIndex(where: { $0.id == id }), !name.isEmpty { songs[i].name = name } }
    func setCover(_ id: UUID, data: Data) {
        guard let i = songs.firstIndex(where: { $0.id == id }), let ui = UIImage(data: data), let jpg = ui.jpegData(compressionQuality: 0.8) else { return }
        let f = "cover-\(UUID().uuidString).jpg"
        try? jpg.write(to: media.url(f))
        songs[i].cover = f
    }
    func removeSong(_ id: UUID) {
        if nowPlaying == id { musicPlayer?.pause(); musicPlayer = nil; nowPlaying = nil; musicPlaying = false }
        songs.removeAll { $0.id == id }
        for i in playlists.indices { playlists[i].songs.removeAll { $0 == id } }
    }
    func play(song id: UUID, in list: [UUID]? = nil) {
        guard let s = songs.first(where: { $0.id == id }) else { return }
        queue = list ?? songs.map { $0.id }
        musicPlayer = AVPlayer(playerItem: AVPlayerItem(url: media.url(s.file)))
        musicPlayer?.play(); nowPlaying = id; musicPlaying = true; resumeMusic = false
    }
    func toggleMusic() {
        if musicPlaying { musicPlayer?.pause(); musicPlaying = false }
        else if musicPlayer != nil { musicPlayer?.play(); musicPlaying = true }
        else if let first = songs.first { play(song: first.id) }
    }
    func nextSong(_ d: Int) {
        guard let cur = nowPlaying, let i = queue.firstIndex(of: cur) else { return }
        let n = i + d
        if n >= 0 && n < queue.count { play(song: queue[n], in: queue) } else { musicPlayer?.pause(); musicPlaying = false }
    }
    private func itemEnded(_ n: Notification) {
        guard let item = n.object as? AVPlayerItem, item === musicPlayer?.currentItem else { return }
        nextSong(1)
    }
    var listening: ZSong? { musicPlaying ? songs.first { $0.id == nowPlaying } : nil }

    // MARK: profile
    func saveProfileImage(_ data: Data, banner: Bool) {
        if data.count > 3, data[0] == 0x47, data[1] == 0x49, data[2] == 0x46 {
            let f = "profile-\(UUID().uuidString).gif"
            try? data.write(to: media.url(f))
            if banner { settings.bannerFile = f } else { settings.avatarFile = f }
            return
        }
        guard let ui = UIImage(data: data) else { return }
        let maxW: CGFloat = banner ? 1400 : 600
        let scale = min(1, maxW / ui.size.width)
        let size = CGSize(width: ui.size.width * scale, height: ui.size.height * scale)
        let img = UIGraphicsImageRenderer(size: size).image { _ in ui.draw(in: CGRect(origin: .zero, size: size)) }
        guard let jpg = img.jpegData(compressionQuality: 0.85) else { return }
        let f = "profile-\(UUID().uuidString).jpg"
        try? jpg.write(to: media.url(f))
        if banner { settings.bannerFile = f } else { settings.avatarFile = f }
    }

    // MARK: export
    func startExport() {
        guard let p = topProject, !exporting else { return }
        stopPlayback(); exporting = true; exportProgress = 0; exportURL = nil
        Task { @MainActor in
            do {
                let url = try await Exporter.export(project: p, media: media) { v in self.exportProgress = v }
                exportURL = url; message = "Export finished. Use Share to save it to Photos or Files."
            } catch { message = "Export failed: \(error.localizedDescription)" }
            exporting = false
        }
    }

    func deleteEverything() {
        stopPlayback(); musicPlayer?.pause(); musicPlayer = nil
        projects = []; currentID = nil; songs = []; playlists = []; nowPlaying = nil; musicPlaying = false
        try? FileManager.default.removeItem(at: MediaCache.dir)
        try? FileManager.default.createDirectory(at: MediaCache.dir, withIntermediateDirectories: true)
        saveProjects(); section = .base
    }
}
